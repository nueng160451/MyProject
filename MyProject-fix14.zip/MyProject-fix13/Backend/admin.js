// ==========================================
// ระบบจัดการของแอดมิน (Admin System)
// ==========================================
function generateAdminCode(customCode = null) {
    const code = customCode || Math.random().toString(36).substring(2, 8).toUpperCase();
    const now = Date.now();
    const threeDaysInMs = 3 * 24 * 60 * 60 * 1000;

    const codeData = { code, createdAt: now, expiresAt: now + threeDaysInMs };
    saveTable(DB_KEYS.ADMIN_CODE, codeData);
    return codeData;
}

function adminGetAllStudentsDetail() {
    const students = getTable(DB_KEYS.STUDENT);
    return students.map(std => {
        const learnSummary = getStudentDashboardData(std.email);
        return {
            name: std.name,
            email: std.email,
            idNumber: std.idNumber,
            phone: std.phone,
            roleLabel: std.roleLabel || "นักเรียน",
            totalEnrolled: learnSummary.totalEnrolled,
            studyingCount: learnSummary.studyingCount,
            completedCount: learnSummary.completedCount,
            studyingCourses: learnSummary.studyingCourses,
            completedCourses: learnSummary.completedCourses
        };
    });
}

function adminGetAllTutorsDetail() {
    const tutors = getTable(DB_KEYS.TUTOR);
    const allCourses = getTable(DB_KEYS.COURSE_TUTOR);

    return tutors.map(tut => {
        const createdCourses = allCourses.filter(c => c.tutorEmail === tut.email).map(c => ({
            courseId: c.courseId,
            title: c.title,
            docLink: c.docLink,
            videoUrl: c.videoUrl,
            price: c.price,
            status: c.status,
            enrolledCount: c.enrolledStudents.length,
            enrolledStudents: c.enrolledStudents
        }));

        return {
            name: tut.name,
            email: tut.email,
            idNumber: tut.idNumber,
            phone: tut.phone,
            roleLabel: tut.roleLabel || "อาจารย์",
            totalCourses: createdCourses.length,
            courses: createdCourses
        };
    });
}

function adminSwitchUserRole(email, targetRole) {
    if (targetRole === 'tutor') {
        const students = getTable(DB_KEYS.STUDENT);
        const idx = students.findIndex(u => u.email === email);
        if (idx === -1) return { success: false, message: "ไม่พบข้อมูลนักเรียน" };

        const user = { ...students[idx], role: 'tutor', roleLabel: 'อาจารย์' };
        students.splice(idx, 1);

        const tutors = getTable(DB_KEYS.TUTOR);
        tutors.push(user);

        saveTable(DB_KEYS.STUDENT, students);
        saveTable(DB_KEYS.TUTOR, tutors);
        return { success: true, message: "เปลี่ยนสถานะเป็น อาจารย์ เรียบร้อยแล้ว" };

    } else if (targetRole === 'student') {
        const tutors = getTable(DB_KEYS.TUTOR);
        const idx = tutors.findIndex(u => u.email === email);
        if (idx === -1) return { success: false, message: "ไม่พบข้อมูลอาจารย์" };

        const user = { ...tutors[idx], role: 'student', roleLabel: 'นักเรียน' };
        tutors.splice(idx, 1);

        const students = getTable(DB_KEYS.STUDENT);
        students.push(user);

        saveTable(DB_KEYS.TUTOR, tutors);
        saveTable(DB_KEYS.STUDENT, students);
        return { success: true, message: "เปลี่ยนสถานะเป็น นักเรียน เรียบร้อยแล้ว" };
    }
    return { success: false, message: "ประเภทสถานะไม่ถูกต้อง" };
}

function adminGetPendingTutors() {
    return getTable(DB_KEYS.PENDING_TUTOR);
}

function adminReviewTutor(email, isApproved, rejectReason = "") {
    const pending = getTable(DB_KEYS.PENDING_TUTOR);
    const idx = pending.findIndex(u => u.email === email);
    if (idx === -1) return { success: false, message: "ไม่พบรายการรออนุมัติ" };

    const applicant = pending[idx];
    pending.splice(idx, 1);
    saveTable(DB_KEYS.PENDING_TUTOR, pending);

    if (isApproved) {
        const tutors = getTable(DB_KEYS.TUTOR);
        applicant.roleLabel = "อาจารย์";
        tutors.push(applicant);
        saveTable(DB_KEYS.TUTOR, tutors);
        return { success: true, message: "อนุมัติการเป็นติวเตอร์เรียบร้อย" };
    } else {
        const rejected = getTable(DB_KEYS.TUTOR_REJECTED);
        rejected.push({
            ...applicant,
            rejectReason: rejectReason || "ไม่ผ่านเกณฑ์การพิจารณา",
            rejectedAt: Date.now()
        });
        saveTable(DB_KEYS.TUTOR_REJECTED, rejected);
        return { success: true, message: "ปฏิเสธคำขอและบันทึกเหตุผลแล้ว" };
    }
}

function adminGetPendingCourses() {
    return getTable(DB_KEYS.COURSE_TUTOR).filter(c => c.status === 'pending');
}

function adminReviewCourse(courseId, isApproved, rejectReason = "") {
    const courses = getTable(DB_KEYS.COURSE_TUTOR);
    const idx = courses.findIndex(c => c.courseId === courseId);
    if (idx === -1) return { success: false, message: "ไม่พบคอร์สเรียน" };

    courses[idx].status = isApproved ? 'approved' : 'rejected';
    courses[idx].rejectReason = isApproved ? '' : (rejectReason || "ข้อมูลคอร์สไม่ครบถ้วน");
    saveTable(DB_KEYS.COURSE_TUTOR, courses);

    return { success: true, message: isApproved ? "อนุมัติคอร์สเรียนแล้ว" : "ไม่อนุมัติคอร์สและบันทึกเหตุผลแล้ว" };
}