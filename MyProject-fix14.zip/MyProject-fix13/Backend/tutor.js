// ==========================================
// ระบบจัดการคอร์สฝั่งอาจารย์ (Course Tutor)
// ==========================================
function createTutorCourse(tutorEmail, title, docLink, videoUrl, price, category = "ทั่วไป", duration = "ไม่จำกัด") {
    const courses = getTable(DB_KEYS.COURSE_TUTOR);
    const newCourse = {
        courseId: 'CRS-' + Date.now(),
        tutorEmail: tutorEmail,
        title: title,
        category: category,
        docLink: docLink,
        videoUrl: videoUrl,
        price: Number(price),
        duration: duration,
        status: 'pending',
        rejectReason: '',
        enrolledStudents: [],
        createdAt: Date.now()
    };

    courses.push(newCourse);
    saveTable(DB_KEYS.COURSE_TUTOR, courses);
    return { success: true, message: "สร้างคอร์สสำเร็จ รอแอดมินตรวจสอบ", course: newCourse };
}

function updateTutorCourse(courseId, title, docLink, videoUrl, price, category, duration) {
    const courses = getTable(DB_KEYS.COURSE_TUTOR);
    const idx = courses.findIndex(c => c.courseId === courseId);
    if (idx === -1) return { success: false, message: "ไม่พบคอร์สเรียน" };

    courses[idx].title = title;
    courses[idx].docLink = docLink;
    courses[idx].videoUrl = videoUrl;
    courses[idx].price = Number(price);
    if (category) courses[idx].category = category;
    if (duration) courses[idx].duration = duration;

    courses[idx].status = 'pending';
    courses[idx].rejectReason = '';

    saveTable(DB_KEYS.COURSE_TUTOR, courses);
    return { success: true, message: "อัปเดตคอร์สและส่งให้แอดมินตรวจสอบใหม่เรียบร้อย", course: courses[idx] };
}

function getCourseById(courseId) {
    return getTable(DB_KEYS.COURSE_TUTOR).find(c => c.courseId === courseId) || null;
}

function getTutorDashboardData(tutorEmail) {
    const myCourses = getTable(DB_KEYS.COURSE_TUTOR).filter(c => c.tutorEmail === tutorEmail);
    const approvedCourses = myCourses.filter(c => c.status === 'approved');
    const pendingCourses = myCourses.filter(c => c.status === 'pending');
    const totalStudents = myCourses.reduce((sum, c) => sum + c.enrolledStudents.length, 0);
    const bestSeller = [...myCourses].sort((a, b) => b.enrolledStudents.length - a.enrolledStudents.length)[0] || null;

    return {
        totalStudents,
        approvedCount: approvedCourses.length,
        pendingCount: pendingCourses.length,
        bestSeller,
        courses: myCourses
    };
}

function getAllApprovedCourses(category = null) {
    const courses = getTable(DB_KEYS.COURSE_TUTOR).filter(c => c.status === 'approved');
    return category ? courses.filter(c => c.category === category) : courses;
}