// ==========================================
// ฐานข้อมูลกลาง (Database Keys & Helpers)
// ==========================================
const DB_KEYS = {
    STUDENT: 'student_user',
    TUTOR: 'tutor_user',
    TUTOR_REJECTED: 'rejected_tutors',
    ADMIN: 'admin_user',
    PENDING_TUTOR: 'pending_tutors',
    ADMIN_CODE: 'admin_code_system',
    CURRENT_USER: 'currentUser',
    COURSE_TUTOR: 'course_tutor',
    COURSE_STUDENT: 'course_student'
};

const getTable = (key) => JSON.parse(localStorage.getItem(key)) || [];
const saveTable = (key, data) => localStorage.setItem(key, JSON.stringify(data));

function initDB() {
    if (!localStorage.getItem(DB_KEYS.STUDENT)) localStorage.setItem(DB_KEYS.STUDENT, JSON.stringify([]));
    if (!localStorage.getItem(DB_KEYS.TUTOR)) localStorage.setItem(DB_KEYS.TUTOR, JSON.stringify([]));
    if (!localStorage.getItem(DB_KEYS.TUTOR_REJECTED)) localStorage.setItem(DB_KEYS.TUTOR_REJECTED, JSON.stringify([]));
    if (!localStorage.getItem(DB_KEYS.ADMIN)) localStorage.setItem(DB_KEYS.ADMIN, JSON.stringify([]));
    if (!localStorage.getItem(DB_KEYS.PENDING_TUTOR)) localStorage.setItem(DB_KEYS.PENDING_TUTOR, JSON.stringify([]));
    if (!localStorage.getItem(DB_KEYS.COURSE_TUTOR)) localStorage.setItem(DB_KEYS.COURSE_TUTOR, JSON.stringify([]));
    if (!localStorage.getItem(DB_KEYS.COURSE_STUDENT)) localStorage.setItem(DB_KEYS.COURSE_STUDENT, JSON.stringify([]));

    // สร้างโค้ดแอดมินเริ่มต้น (อายุ 3 วัน)
    if (!localStorage.getItem(DB_KEYS.ADMIN_CODE)) {
        const now = Date.now();
        saveTable(DB_KEYS.ADMIN_CODE, {
            code: 'ADMIN123',
            createdAt: now,
            expiresAt: now + (3 * 24 * 60 * 60 * 1000)
        });
    }
}

initDB();