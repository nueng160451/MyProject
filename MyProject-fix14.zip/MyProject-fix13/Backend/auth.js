// ==========================================
// ระบบสมาชิกและการยืนยันตัวตน (Auth System)
// ==========================================
function validateAdminCode(inputCode) {
    const systemCode = JSON.parse(localStorage.getItem(DB_KEYS.ADMIN_CODE));
    if (!systemCode) return false;
    return systemCode.code === inputCode && Date.now() < systemCode.expiresAt;
}

function registerStudent(name, email, password, phone, idNumber) {
    const students = getTable(DB_KEYS.STUDENT);
    if (students.some(u => u.email === email || u.idNumber === idNumber)) {
        return { success: false, message: "อีเมลหรือเลขบัตรประชาชนนี้ถูกใช้งานไปแล้ว" };
    }
    students.push({
        name, email, password, phone, idNumber,
        role: "student",
        roleLabel: "นักเรียน"
    });
    saveTable(DB_KEYS.STUDENT, students);
    return { success: true, message: "สมัครสมาชิกนักเรียนสำเร็จ" };
}

function registerTutor(name, email, password, phone, idNumber, resume = "", idCardImage = "") {
    const tutors = getTable(DB_KEYS.TUTOR);
    const pendingTutors = getTable(DB_KEYS.PENDING_TUTOR);

    const isDup = tutors.some(u => u.email === email || u.idNumber === idNumber) ||
                  pendingTutors.some(u => u.email === email || u.idNumber === idNumber);
    if (isDup) {
        return { success: false, message: "อีเมลหรือเลขบัตรประชาชนนี้ถูกใช้งานไปแล้ว" };
    }

    pendingTutors.push({
        name, email, password, phone, idNumber, resume, idCardImage,
        role: "tutor",
        roleLabel: "อาจารย์",
        appliedAt: Date.now()
    });
    saveTable(DB_KEYS.PENDING_TUTOR, pendingTutors);
    return { success: true, message: "ส่งข้อมูลสมัครติวเตอร์สำเร็จ กรุณารอแอดมินอนุมัติ" };
}

function registerAdmin(name, email, password, phone, idNumber, adminCode) {
    const admins = getTable(DB_KEYS.ADMIN);
    if (admins.some(u => u.email === email || u.idNumber === idNumber)) {
        return { success: false, message: "อีเมลหรือเลขบัตรประชาชนนี้ถูกใช้งานไปแล้ว" };
    }
    if (!validateAdminCode(adminCode)) {
        return { success: false, message: "โค้ดแอดมินไม่ถูกต้องหรือหมดอายุแล้ว" };
    }

    const systemCode = JSON.parse(localStorage.getItem(DB_KEYS.ADMIN_CODE));
    admins.push({
        name, email, password, phone, idNumber,
        adminCode, codeExpiresAt: systemCode.expiresAt,
        role: "admin",
        roleLabel: "แอดมิน"
    });
    saveTable(DB_KEYS.ADMIN, admins);
    return { success: true, message: "สมัครสมาชิกแอดมินสำเร็จ" };
}

function loginUser(email, password) {
    const student = getTable(DB_KEYS.STUDENT).find(u => u.email === email && u.password === password);
    if (student) {
        saveTable(DB_KEYS.CURRENT_USER, student);
        return { success: true, role: 'student', redirect: 'learner.html', user: student };
    }

    const tutor = getTable(DB_KEYS.TUTOR).find(u => u.email === email && u.password === password);
    if (tutor) {
        saveTable(DB_KEYS.CURRENT_USER, tutor);
        return { success: true, role: 'tutor', redirect: 'tutor.html', user: tutor };
    }

    const pendingTutor = getTable(DB_KEYS.PENDING_TUTOR).find(u => u.email === email && u.password === password);
    if (pendingTutor) {
        return { success: false, message: "บัญชีติวเตอร์ของคุณอยู่ระหว่างรอแอดมินอนุมัติ" };
    }

    const rejectedTutor = getTable(DB_KEYS.TUTOR_REJECTED).find(u => u.email === email && u.password === password);
    if (rejectedTutor) {
        return { success: false, message: `บัญชีติวเตอร์ไม่ผ่านการอนุมัติ เหตุผล: ${rejectedTutor.rejectReason}` };
    }

    const admin = getTable(DB_KEYS.ADMIN).find(u => u.email === email && u.password === password);
    if (admin) {
        if (Date.now() > admin.codeExpiresAt) {
            return { success: false, requireRenew: true, message: "โค้ดแอดมินหมดอายุ กรุณาต่ออายุ" };
        }
        saveTable(DB_KEYS.CURRENT_USER, admin);
        return { success: true, role: 'admin', redirect: 'admin.html', user: admin };
    }

    return { success: false, message: "อีเมลหรือรหัสผ่านไม่ถูกต้อง" };
}

function renewAdminAccess(email, newCode) {
    if (!validateAdminCode(newCode)) {
        return { success: false, message: "โค้ดแอดมินไม่ถูกต้องหรือหมดอายุแล้ว" };
    }

    const admins = getTable(DB_KEYS.ADMIN);
    const systemCode = JSON.parse(localStorage.getItem(DB_KEYS.ADMIN_CODE));
    const adminIndex = admins.findIndex(u => u.email === email);

    if (adminIndex !== -1) {
        admins[adminIndex].adminCode = newCode;
        admins[adminIndex].codeExpiresAt = systemCode.expiresAt;
        saveTable(DB_KEYS.ADMIN, admins);
        saveTable(DB_KEYS.CURRENT_USER, admins[adminIndex]);
        return { success: true, message: "ต่ออายุสำเร็จ กำลังเข้าสู่ระบบ...", redirect: "admin.html" };
    }
    return { success: false, message: "ไม่พบบัญชีแอดมิน" };
}

function updateUserProfile(email, role, newName, newPhone) {
    const targetKey = role === 'student' ? DB_KEYS.STUDENT : role === 'tutor' ? DB_KEYS.TUTOR : DB_KEYS.ADMIN;
    const users = getTable(targetKey);
    const idx = users.findIndex(u => u.email === email);
    if (idx === -1) return { success: false, message: "ไม่พบข้อมูลผู้ใช้" };

    users[idx].name = newName || users[idx].name;
    users[idx].phone = newPhone || users[idx].phone;
    saveTable(targetKey, users);
    saveTable(DB_KEYS.CURRENT_USER, users[idx]);

    return { success: true, message: "อัปเดตข้อมูลส่วนตัวสำเร็จ", user: users[idx] };
}

function resetPassword(role, email, idNumber, phone, newPassword) {
    let targetKey = role === 'student' ? DB_KEYS.STUDENT : role === 'tutor' ? DB_KEYS.TUTOR : role === 'admin' ? DB_KEYS.ADMIN : '';
    if (!targetKey) return { success: false, message: "กรุณาเลือกประเภทผู้ใช้งานให้ถูกต้อง" };

    const users = getTable(targetKey);
    const userIndex = users.findIndex(u => u.email === email && u.idNumber === idNumber && u.phone === phone);

    if (userIndex === -1 && role === 'tutor') {
        const pendingTutors = getTable(DB_KEYS.PENDING_TUTOR);
        const pendingIndex = pendingTutors.findIndex(u => u.email === email && u.idNumber === idNumber && u.phone === phone);
        if (pendingIndex !== -1) {
            pendingTutors[pendingIndex].password = newPassword;
            saveTable(DB_KEYS.PENDING_TUTOR, pendingTutors);
            return { success: true, message: "เปลี่ยนรหัสผ่านสำเร็จ (บัญชีอยู่ระหว่างรอแอดมินอนุมัติ)" };
        }
    }

    if (userIndex === -1) return { success: false, message: "ข้อมูลไม่ตรงกับในระบบ" };

    users[userIndex].password = newPassword;
    saveTable(targetKey, users);
    return { success: true, message: "ตั้งรหัสผ่านใหม่สำเร็จ" };
}

function getCurrentUser() {
    return JSON.parse(localStorage.getItem(DB_KEYS.CURRENT_USER));
}

function logout() {
    localStorage.removeItem(DB_KEYS.CURRENT_USER);
    window.location.href = "login.html";
}