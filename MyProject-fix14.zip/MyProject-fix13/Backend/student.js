// ==========================================
// ระบบติดตามการเรียนฝั่งนักศึกษา (Course Student)
// ==========================================
function enrollCourse(studentEmail, courseId) {
    const studentCourses = getTable(DB_KEYS.COURSE_STUDENT);
    const tutorCourses = getTable(DB_KEYS.COURSE_TUTOR);

    if (studentCourses.some(sc => sc.studentEmail === studentEmail && sc.courseId === courseId)) {
        return { success: false, message: "คุณได้ลงทะเบียนคอร์สนี้ไปแล้ว" };
    }

    const courseIndex = tutorCourses.findIndex(c => c.courseId === courseId);
    if (courseIndex === -1) return { success: false, message: "ไม่พบคอร์สเรียน" };

    studentCourses.push({
        enrollId: 'ENR-' + Date.now(),
        studentEmail: studentEmail,
        courseId: courseId,
        isVideoWatched: false,
        isDocRead: false,
        progress: 0,
        status: 'studying',
        enrolledAt: Date.now(),
        completedAt: null
    });
    saveTable(DB_KEYS.COURSE_STUDENT, studentCourses);

    tutorCourses[courseIndex].enrolledStudents.push(studentEmail);
    saveTable(DB_KEYS.COURSE_TUTOR, tutorCourses);

    return { success: true, message: "ลงทะเบียนเรียนสำเร็จ" };
}

function toggleCourseChecklist(studentEmail, courseId, isVideoWatched, isDocRead) {
    const studentCourses = getTable(DB_KEYS.COURSE_STUDENT);
    const index = studentCourses.findIndex(sc => sc.studentEmail === studentEmail && sc.courseId === courseId);

    if (index === -1) return { success: false, message: "ไม่พบประวัติการลงเรียนคอร์สนี้" };

    studentCourses[index].isVideoWatched = Boolean(isVideoWatched);
    studentCourses[index].isDocRead = Boolean(isDocRead);

    let percent = 0;
    if (studentCourses[index].isVideoWatched) percent += 50;
    if (studentCourses[index].isDocRead) percent += 50;
    studentCourses[index].progress = percent;

    if (percent === 100) {
        studentCourses[index].status = 'completed';
        if (!studentCourses[index].completedAt) studentCourses[index].completedAt = Date.now();
    } else {
        studentCourses[index].status = 'studying';
        studentCourses[index].completedAt = null;
    }

    saveTable(DB_KEYS.COURSE_STUDENT, studentCourses);
    return { success: true, message: "บันทึกความคืบหน้าแล้ว", data: studentCourses[index] };
}

function getStudentDashboardData(studentEmail) {
    const studentCourses = getTable(DB_KEYS.COURSE_STUDENT).filter(sc => sc.studentEmail === studentEmail);
    const allCourses = getTable(DB_KEYS.COURSE_TUTOR);

    const enrichedCourses = studentCourses.map(sc => {
        const detail = allCourses.find(c => c.courseId === sc.courseId) || {};
        return {
            ...sc,
            courseTitle: detail.title || "ไม่ระบุชื่อคอร์ส",
            docLink: detail.docLink || "",
            videoUrl: detail.videoUrl || "",
            tutorEmail: detail.tutorEmail || ""
        };
    });

    const studyingCourses = enrichedCourses.filter(c => c.status === 'studying');
    const completedCourses = enrichedCourses.filter(c => c.status === 'completed');

    return {
        totalEnrolled: enrichedCourses.length,
        studyingCount: studyingCourses.length,
        completedCount: completedCourses.length,
        studyingCourses,
        completedCourses
    };
}