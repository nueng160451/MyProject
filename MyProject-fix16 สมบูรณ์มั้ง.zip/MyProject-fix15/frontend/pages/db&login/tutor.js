function getTutorCourses(tutorEmail) {
    const email = normalizeEmail(tutorEmail);
    return [
        ...getTable(DB_KEYS.COURSE_TUTOR),
        ...getTable(DB_KEYS.PENDING_COURSE)
    ].filter(course => normalizeEmail(course.tutorEmail) === email);
}

function getTutorDashboardData(tutorEmail) {
    const courses = getTutorCourses(tutorEmail);
    const enrollments = getTable(DB_KEYS.COURSE_STUDENT)
        .filter(enrollment => courses.some(course => course.courseId === enrollment.courseId));
    const activeCourses = courses.filter(course => course.status === 'approved');
    return {
        courses,
        totalStudents: new Set(enrollments.map(enrollment => enrollment.studentEmail)).size,
        approvedCount: activeCourses.length,
        pendingCount: courses.filter(course => course.status === 'pending').length,
        bestSeller: activeCourses.reduce((best, course) =>
            !best || (course.enrolledStudents || []).length > (best.enrolledStudents || []).length
                ? course
                : best, null
        )
    };
}

function createTutorCourse(tutorEmail, titleOrCourse, docLink = '', videoUrl = '', price = 0, category = '', lessons = [], template = 'classic', coverImage = null) {
    const email = normalizeEmail(tutorEmail);
    const tutor = getTable(DB_KEYS.TUTOR).find(user => normalizeEmail(user.email) === email);
    if (!tutor) return { success: false, message: 'ไม่พบบัญชีติวเตอร์ที่ได้รับอนุมัติ' };

    const course = typeof titleOrCourse === 'object' && titleOrCourse !== null
        ? { ...titleOrCourse }
        : { title: titleOrCourse, docLink, videoUrl, price, category, lessons, template, coverImage };
    const normalized = normalizeCourseSubmission(course, tutor);
    if (normalized.error) return { success: false, message: normalized.error };
    const pending = getTable(DB_KEYS.PENDING_COURSE);
    pending.push(normalized.course);
    saveTable(DB_KEYS.PENDING_COURSE, pending);
    return { success: true, message: 'ส่งคอร์สให้แอดมินตรวจสอบแล้ว', course: normalized.course };
}

function updateTutorCourse(courseId, titleOrCourse, docLink = '', videoUrl = '', price = 0, category = '', lessons = [], template = 'classic', coverImage = null) {
    const user = getCurrentUser();
    const existing = getTutorCourses(user.email).find(course => course.courseId === courseId);
    if (!existing) return { success: false, message: 'ไม่พบคอร์สของคุณ' };
    const tutor = getTable(DB_KEYS.TUTOR).find(item => normalizeEmail(item.email) === normalizeEmail(user.email));
    if (!tutor) return { success: false, message: 'ไม่พบบัญชีติวเตอร์ที่ได้รับอนุมัติ' };

    const values = typeof titleOrCourse === 'object' && titleOrCourse !== null
        ? { ...titleOrCourse }
        : { title: titleOrCourse, docLink, videoUrl, price, category, lessons, template, coverImage };
    const pending = getTable(DB_KEYS.PENDING_COURSE);
    const pendingIndex = pending.findIndex(course => course.courseId === courseId);
    const normalized = normalizeCourseSubmission(values, tutor, pendingIndex === -1 ? undefined : existing.courseId);
    if (normalized.error) return { success: false, message: normalized.error };
    if (pendingIndex !== -1) pending.splice(pendingIndex, 1);
    pending.push(normalized.course);
    saveTable(DB_KEYS.PENDING_COURSE, pending);
    return { success: true, message: 'บันทึกการเปลี่ยนแปลงและส่งตรวจสอบแล้ว', course: normalized.course };
}

function normalizeCourseSubmission(input, tutor, courseId = `CRS-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`) {
    const title = String(input.title || '').trim();
    const normalizedLessons = Array.isArray(input.lessons) ? input.lessons : [];
    if (!title) return { error: 'กรุณาระบุชื่อคอร์ส' };
    if (normalizedLessons.length < 1 || normalizedLessons.length > 5) {
        return { error: 'คอร์สต้องมีบทเรียนตั้งแต่ 1 ถึง 5 บท' };
    }
    if (normalizedLessons.some(lesson => !String(lesson.title || '').trim())) {
        return { error: 'กรุณาระบุชื่อให้ครบทุกบทเรียน' };
    }
    if (!['classic', 'focus', 'playful'].includes(input.template)) {
        return { error: 'กรุณาเลือกเทมเพลตที่ถูกต้อง' };
    }
    const amount = Number(input.price || 0);
    if (!Number.isFinite(amount) || amount < 0) return { error: 'ราคาคอร์สไม่ถูกต้อง' };

    const old = [
        ...getTable(DB_KEYS.COURSE_TUTOR),
        ...getTable(DB_KEYS.PENDING_COURSE)
    ].find(course => course.courseId === courseId);
    const course = {
        ...(old || {}),
        courseId,
        tutorEmail: normalizeEmail(tutor.email),
        tutorName: tutor.name,
        title,
        category: String(input.category || '').trim(),
        description: String(input.description || '').trim(),
        price: amount,
        template: input.template,
        coverImage: input.coverImage || null,
        lessons: normalizedLessons.map((lesson, index) => ({
            lessonId: lesson.lessonId || `${courseId}-L${index + 1}`,
            title: String(lesson.title).trim(),
            description: String(lesson.description || '').trim(),
            media: lesson.media || null
        })),
        docLink: '',
        videoUrl: '',
        status: 'pending',
        rejectReason: '',
        enrolledStudents: old && Array.isArray(old.enrolledStudents) ? old.enrolledStudents : [],
        submittedAt: Date.now()
    };
    return { course };
}
