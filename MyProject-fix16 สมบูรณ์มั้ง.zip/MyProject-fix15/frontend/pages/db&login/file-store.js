const courseFileStore = (() => {
    const databaseName = 'how-to-learn-course-files';
    const storeName = 'uploads';

    function openDatabase() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(databaseName, 1);
            request.onupgradeneeded = () => {
                if (!request.result.objectStoreNames.contains(storeName)) {
                    request.result.createObjectStore(storeName, { keyPath: 'id' });
                }
            };
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error || new Error('เปิดที่เก็บไฟล์ไม่สำเร็จ'));
        });
    }

    async function save(file) {
        const db = await openDatabase();
        const id = `file-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
        await new Promise((resolve, reject) => {
            const transaction = db.transaction(storeName, 'readwrite');
            transaction.objectStore(storeName).put({
                id,
                name: file.name,
                type: file.type,
                size: file.size,
                blob: file
            });
            transaction.oncomplete = resolve;
            transaction.onerror = () => reject(transaction.error || new Error('บันทึกไฟล์ไม่สำเร็จ'));
            transaction.onabort = () => reject(transaction.error || new Error('ยกเลิกการบันทึกไฟล์'));
        });
        db.close();
        return { id, name: file.name, type: file.type, size: file.size };
    }

    async function get(id) {
        if (!id) return null;
        const db = await openDatabase();
        const record = await new Promise((resolve, reject) => {
            const request = db.transaction(storeName, 'readonly').objectStore(storeName).get(id);
            request.onsuccess = () => resolve(request.result || null);
            request.onerror = () => reject(request.error || new Error('อ่านไฟล์ไม่สำเร็จ'));
        });
        db.close();
        return record;
    }

    async function remove(id) {
        if (!id) return;
        const db = await openDatabase();
        await new Promise((resolve, reject) => {
            const transaction = db.transaction(storeName, 'readwrite');
            transaction.objectStore(storeName).delete(id);
            transaction.oncomplete = resolve;
            transaction.onerror = () => reject(transaction.error || new Error('ลบไฟล์ไม่สำเร็จ'));
        });
        db.close();
    }

    async function open(id) {
        const record = await get(id);
        if (!record) throw new Error('ไม่พบไฟล์ที่แนบไว้ในอุปกรณ์นี้');
        const url = URL.createObjectURL(record.blob);
        window.open(url, '_blank', 'noopener');
        window.setTimeout(() => URL.revokeObjectURL(url), 60000);
    }

    return { save, get, remove, open };
})();
