function generateAdminCode(customCode = null) {
    const now = Date.now();
    const codes = getAdminCodeData().filter(code => !code.used && code.expiresAt > now);
    if (codes.length >= 2) {
        return { success: false, message: 'มีโค้ดที่ยังใช้งานได้ครบ 2 โค้ดแล้ว กรุณารอหมดอายุหรือใช้โค้ดก่อน' };
    }

    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = customCode ? String(customCode).trim().toUpperCase() : '';
    if (!code) {
        do {
            code = Array.from({ length: 8 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
        } while (getAdminCodeData().some(item => item.code === code));
    }
    if (getAdminCodeData().some(item => item.code === code && item.expiresAt > now)) {
        return { success: false, message: 'โค้ดนี้มีอยู่ในระบบแล้ว' };
    }

    const codeData = { code, createdAt: now, expiresAt: now + 3 * 24 * 60 * 60 * 1000, used: false };
    saveAdminCodeData([...getAdminCodeData(), codeData]);
    return { success: true, ...codeData };
}

function adminGetAllStudentsDetail() {
    const enrollments = getTable(DB_KEYS.COURSE_STUDENT);
    return getTable(DB_KEYS.STUDENT).map(student => {
        const summary = getStudentDashboardData(student.email);
        return {
            name: student.name,
            email: student.email,
            idNumber: student.idNumber,
            phone: student.phone,
            totalEnrolled: summary.totalEnrolled,
            studyingCount: summary.studyingCount,
            completedCount: summary.completedCount,
            courses: enrollments
                .filter(item => normalizeEmail(item.studentEmail) === normalizeEmail(student.email))
                .map(item => {
                    const course = getTable(DB_KEYS.COURSE_TUTOR).find(entry => entry.courseId === item.courseId);
                    return { title: course ? course.title : 'คอร์สที่ถูกนำออกจากระบบ', progress: item.progress || 0 };
                })
        };
    });
}

function adminGetAllTutorsDetail() {
    const courses = [...getTable(DB_KEYS.COURSE_TUTOR), ...getTable(DB_KEYS.PENDING_COURSE)];
    return getTable(DB_KEYS.TUTOR).map(tutor => {
        const tutorCourses = courses.filter(course => normalizeEmail(course.tutorEmail) === normalizeEmail(tutor.email));
        return {
            name: tutor.name,
            email: tutor.email,
            idNumber: tutor.idNumber,
            phone: tutor.phone,
            totalCourses: tutorCourses.filter(course => course.status === 'approved').length,
            totalLearners: new Set(getTable(DB_KEYS.COURSE_STUDENT)
                .filter(enrollment => tutorCourses.some(course => course.courseId === enrollment.courseId))
                .map(enrollment => normalizeEmail(enrollment.studentEmail))).size,
            courses: tutorCourses.map(course => ({
                courseId: course.courseId,
                title: course.title,
                category: course.category,
                price: course.price,
                status: course.status,
                rejectReason: course.rejectReason || '',
                enrolledCount: (course.enrolledStudents || []).length,
                lessons: course.lessons || []
            }))
        };
    });
}

function adminGetStats() {
    return {
        students: getTable(DB_KEYS.STUDENT).length,
        tutors: getTable(DB_KEYS.TUTOR).length,
        pendingTutors: getTable(DB_KEYS.PENDING_TUTOR).length,
        pendingCourses: getTable(DB_KEYS.PENDING_COURSE).length,
        approvedCourses: getAllApprovedCourses().length
    };
}

function adminSwitchUserRole(email, targetRole) {
    if (targetRole === 'tutor') {
        return { success: false, message: 'ติวเตอร์ต้องผ่านขั้นตอนตรวจสอบและอนุมัติก่อน' };
    }
    const normalizedEmail = normalizeEmail(email);
    const fromKey = targetRole === 'student' ? DB_KEYS.TUTOR : null;
    const toKey = targetRole === 'student' ? DB_KEYS.STUDENT : null;
    if (!fromKey) return { success: false, message: 'ประเภทสถานะไม่ถูกต้อง' };
    const from = getTable(fromKey);
    const index = from.findIndex(user => normalizeEmail(user.email) === normalizedEmail);
    if (index === -1) return { success: false, message: 'ไม่พบข้อมูลผู้ใช้' };
    const user = { ...from[index], role: targetRole, roleLabel: targetRole === 'tutor' ? 'ติวเตอร์' : 'นักเรียน' };
    from.splice(index, 1);
    const to = getTable(toKey);
    to.push(user);
    saveTable(fromKey, from);
    saveTable(toKey, to);
    return { success: true, message: 'เปลี่ยนสถานะผู้ใช้เรียบร้อยแล้ว' };
}

function adminGetPendingTutors() {
    return getTable(DB_KEYS.PENDING_TUTOR);
}

function adminReviewTutor(email, isApproved, rejectReason = '') {
    const normalizedEmail = normalizeEmail(email);
    const pending = getTable(DB_KEYS.PENDING_TUTOR);
    const index = pending.findIndex(user => normalizeEmail(user.email) === normalizedEmail);
    if (index === -1) return { success: false, message: 'ไม่พบรายการรออนุมัติ' };
    if (!isApproved && !String(rejectReason).trim()) {
        return { success: false, message: 'กรุณาระบุเหตุผลที่ไม่อนุมัติ' };
    }

    const applicant = pending[index];
    if (isApproved) {
        const tutors = getTable(DB_KEYS.TUTOR);
        if (tutors.some(user => normalizeEmail(user.email) === normalizedEmail)) {
            return { success: false, message: 'บัญชีติวเตอร์นี้มีอยู่แล้ว' };
        }
        pending.splice(index, 1);
        saveTable(DB_KEYS.PENDING_TUTOR, pending);
        applicant.role = 'tutor';
        applicant.roleLabel = 'ติวเตอร์';
        applicant.approvedAt = Date.now();
        tutors.push(applicant);
        saveTable(DB_KEYS.TUTOR, tutors);
        return { success: true, message: 'อนุมัติการเป็นติวเตอร์เรียบร้อย', applicant };
    }

    pending.splice(index, 1);
    saveTable(DB_KEYS.PENDING_TUTOR, pending);
    const rejected = getTable(DB_KEYS.TUTOR_REJECTED);
    const rejectedApplicant = {
        ...applicant,
        role: 'rejected_tutor',
        rejectReason: String(rejectReason).trim(),
        rejectedAt: Date.now()
    };
    rejected.push(rejectedApplicant);
    saveTable(DB_KEYS.TUTOR_REJECTED, rejected);
    return {
        success: true,
        message: 'ไม่อนุมัติคำขอและบันทึกเหตุผลแล้ว',
        applicant: rejectedApplicant
    };
}

function adminGetPendingCourses() {
    return getTable(DB_KEYS.PENDING_COURSE);
}

function addUserNotification(email, type, title, message, courseId = '') {
    const notifications = getTable(DB_KEYS.NOTIFICATIONS);
    notifications.unshift({
        id: `NTF-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        userEmail: normalizeEmail(email),
        type,
        title,
        message,
        courseId,
        createdAt: Date.now(),
        read: false
    });
    saveTable(DB_KEYS.NOTIFICATIONS, notifications);
}

function getUserNotifications(email) {
    return getTable(DB_KEYS.NOTIFICATIONS)
        .filter(item => normalizeEmail(item.userEmail) === normalizeEmail(email));
}

function markNotificationRead(notificationId) {
    const notifications = getTable(DB_KEYS.NOTIFICATIONS);
    const notification = notifications.find(item => item.id === notificationId);
    if (!notification) return { success: false, message: 'ไม่พบการแจ้งเตือน' };
    notification.read = true;
    saveTable(DB_KEYS.NOTIFICATIONS, notifications);
    return { success: true };
}

function adminReviewCourse(courseId, isApproved, rejectReason = '') {
    const pending = getTable(DB_KEYS.PENDING_COURSE);
    const index = pending.findIndex(course => course.courseId === courseId);
    if (index === -1) return { success: false, message: 'ไม่พบคอร์สที่รอตรวจสอบ' };
    if (!isApproved && !String(rejectReason).trim()) {
        return { success: false, message: 'กรุณาระบุเหตุผลที่ไม่อนุมัติ' };
    }

    const course = pending.splice(index, 1)[0];
    course.status = isApproved ? 'approved' : 'rejected';
    course.rejectReason = isApproved ? '' : String(rejectReason).trim();
    course.reviewedAt = Date.now();
    const resolved = getTable(DB_KEYS.COURSE_TUTOR);
    resolved.push(course);
    saveTable(DB_KEYS.PENDING_COURSE, pending);
    saveTable(DB_KEYS.COURSE_TUTOR, resolved);
    addUserNotification(
        course.tutorEmail,
        isApproved ? 'course-approved' : 'course-rejected',
        isApproved ? 'อนุมัติคอร์สแล้ว' : 'คอร์สยังไม่ผ่านการอนุมัติ',
        isApproved ? `คอร์ส "${course.title}" เปิดให้นักเรียนลงทะเบียนแล้ว` : `คอร์ส "${course.title}": ${course.rejectReason}`,
        course.courseId
    );
    return { success: true, message: isApproved ? 'อนุมัติคอร์สเรียนแล้ว' : 'ไม่อนุมัติคอร์สและแจ้งเหตุผลให้ติวเตอร์แล้ว' };
}

function adminDeleteTutorCourse(courseId) {
    const courses = getTable(DB_KEYS.COURSE_TUTOR);
    const pending = getTable(DB_KEYS.PENDING_COURSE);
    const exists = courses.some(course => course.courseId === courseId) ||
        pending.some(course => course.courseId === courseId);
    if (!exists) return { success: false, message: 'ไม่พบคอร์สที่ต้องการลบ' };
    saveTable(DB_KEYS.COURSE_TUTOR, courses.filter(course => course.courseId !== courseId));
    saveTable(DB_KEYS.PENDING_COURSE, pending.filter(course => course.courseId !== courseId));
    saveTable(DB_KEYS.COURSE_STUDENT, getTable(DB_KEYS.COURSE_STUDENT)
        .filter(enrollment => enrollment.courseId !== courseId));
    return { success: true, message: 'ลบคอร์สและข้อมูลการลงทะเบียนแล้ว' };
}
