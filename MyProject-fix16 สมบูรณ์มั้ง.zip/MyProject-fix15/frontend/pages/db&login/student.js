function getAllApprovedCourses() {
    return getTable(DB_KEYS.COURSE_TUTOR).filter(course => course.status === 'approved');
}

function getCourseById(courseId) {
    return getAllApprovedCourses().find(course => course.courseId === courseId) || null;
}

function enrollCourse(studentEmail, courseId) {
    const email = normalizeEmail(studentEmail);
    const student = getTable(DB_KEYS.STUDENT).find(user => normalizeEmail(user.email) === email);
    if (!student) return { success: false, message: 'ไม่พบบัญชีนักเรียน' };

    const enrollments = getTable(DB_KEYS.COURSE_STUDENT);
    if (enrollments.some(item => normalizeEmail(item.studentEmail) === email && item.courseId === courseId)) {
        return { success: false, message: 'คุณได้ลงทะเบียนคอร์สนี้ไปแล้ว' };
    }

    const courses = getTable(DB_KEYS.COURSE_TUTOR);
    const course = courses.find(item => item.courseId === courseId && item.status === 'approved');
    if (!course) return { success: false, message: 'ไม่พบคอร์สที่เปิดสอน' };
    if (!Array.isArray(course.enrolledStudents)) course.enrolledStudents = [];
    if (!course.enrolledStudents.some(item => normalizeEmail(item) === email)) {
        course.enrolledStudents.push(email);
    }
    enrollments.push({
        enrollId: `ENR-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        studentEmail: email,
        courseId,
        completedLessonIds: [],
        progress: 0,
        status: 'studying',
        enrolledAt: Date.now(),
        completedAt: null
    });
    saveTable(DB_KEYS.COURSE_TUTOR, courses);
    saveTable(DB_KEYS.COURSE_STUDENT, enrollments);
    return { success: true, message: 'ลงทะเบียนเรียนสำเร็จ' };
}

function toggleLessonCompletion(studentEmail, courseId, lessonId, completed) {
    const email = normalizeEmail(studentEmail);
    const enrollments = getTable(DB_KEYS.COURSE_STUDENT);
    const enrollment = enrollments.find(item =>
        normalizeEmail(item.studentEmail) === email && item.courseId === courseId
    );
    if (!enrollment) return { success: false, message: 'ไม่พบประวัติการลงเรียนคอร์สนี้' };

    const course = getCourseById(courseId);
    if (!course) return { success: false, message: 'ไม่พบคอร์สเรียน' };
    if (!(course.lessons || []).some(lesson => lesson.lessonId === lessonId)) {
        return { success: false, message: 'ไม่พบบทเรียนนี้ในคอร์ส' };
    }
    const completedIds = new Set(enrollment.completedLessonIds || []);
    if (completed) completedIds.add(lessonId);
    else completedIds.delete(lessonId);
    enrollment.completedLessonIds = Array.from(completedIds);
    enrollment.progress = course.lessons.length
        ? Math.round((enrollment.completedLessonIds.length / course.lessons.length) * 100)
        : 0;
    enrollment.status = enrollment.progress === 100 ? 'completed' : 'studying';
    enrollment.completedAt = enrollment.progress === 100 ? (enrollment.completedAt || Date.now()) : null;
    saveTable(DB_KEYS.COURSE_STUDENT, enrollments);
    return { success: true, message: 'บันทึกความคืบหน้าแล้ว', data: enrollment };
}

function toggleCourseChecklist(studentEmail, courseId, isVideoWatched, isDocRead) {
    const enrollments = getTable(DB_KEYS.COURSE_STUDENT);
    const enrollment = enrollments.find(item =>
        normalizeEmail(item.studentEmail) === normalizeEmail(studentEmail) && item.courseId === courseId
    );
    if (!enrollment) return { success: false, message: 'ไม่พบประวัติการลงเรียนคอร์สนี้' };

    enrollment.isVideoWatched = Boolean(isVideoWatched);
    enrollment.isDocRead = Boolean(isDocRead);
    enrollment.progress = (enrollment.isVideoWatched ? 50 : 0) + (enrollment.isDocRead ? 50 : 0);
    enrollment.status = enrollment.progress === 100 ? 'completed' : 'studying';
    enrollment.completedAt = enrollment.progress === 100 ? (enrollment.completedAt || Date.now()) : null;
    saveTable(DB_KEYS.COURSE_STUDENT, enrollments);
    return { success: true, message: 'บันทึกความคืบหน้าแล้ว', data: enrollment };
}

function getStudentDashboardData(studentEmail) {
    const email = normalizeEmail(studentEmail);
    const enrollments = getTable(DB_KEYS.COURSE_STUDENT)
        .filter(item => normalizeEmail(item.studentEmail) === email);
    const courses = getTable(DB_KEYS.COURSE_TUTOR);
    const enriched = enrollments.map(enrollment => {
        const course = courses.find(item => item.courseId === enrollment.courseId) || {};
        const lessons = Array.isArray(course.lessons) ? course.lessons : [];
        const completedLessonIds = enrollment.completedLessonIds || [];
        const progress = lessons.length
            ? Math.round((completedLessonIds.length / lessons.length) * 100)
            : Number(enrollment.progress || 0);
        return {
            ...enrollment,
            progress,
            status: progress === 100 ? 'completed' : 'studying',
            completedLessonIds,
            courseTitle: course.title || 'คอร์สที่ถูกนำออกจากระบบ',
            course,
            tutorEmail: course.tutorEmail || ''
        };
    });
    const studyingCourses = enriched.filter(course => course.status !== 'completed');
    const completedCourses = enriched.filter(course => course.status === 'completed');
    return {
        totalEnrolled: enriched.length,
        studyingCount: studyingCourses.length,
        completedCount: completedCourses.length,
        studyingCourses,
        completedCourses,
        courses: enriched
    };
}
