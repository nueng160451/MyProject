const DB_KEYS = {
    STUDENT: 'student_user',
    TUTOR: 'tutor_user',
    TUTOR_REJECTED: 'rejected_tutors',
    ADMIN: 'admin_user',
    PENDING_TUTOR: 'pending_tutors',
    PENDING_COURSE: 'pendingcourse_tutors',
    ADMIN_CODE: 'admin_code_system',
    CURRENT_USER: 'currentUser',
    COURSE_TUTOR: 'course_tutor',
    COURSE_STUDENT: 'course_student',
    NOTIFICATIONS: 'user_notifications'
};

function getTable(key) {
    const stored = localStorage.getItem(key);
    if (!stored) return [];
    const value = JSON.parse(stored);
    return Array.isArray(value) ? value : [];
}

function saveTable(key, data) {
    localStorage.setItem(key, JSON.stringify(data));
}

function getAdminCodeData() {
    const stored = localStorage.getItem(DB_KEYS.ADMIN_CODE);
    if (!stored) return [];
    const value = JSON.parse(stored);
    if (Array.isArray(value)) return value;
    return value && value.code ? [value] : [];
}

function saveAdminCodeData(codes) {
    localStorage.setItem(DB_KEYS.ADMIN_CODE, JSON.stringify(codes));
}

function initDB() {
    [
        DB_KEYS.STUDENT,
        DB_KEYS.TUTOR,
        DB_KEYS.TUTOR_REJECTED,
        DB_KEYS.ADMIN,
        DB_KEYS.PENDING_TUTOR,
        DB_KEYS.PENDING_COURSE,
        DB_KEYS.COURSE_TUTOR,
        DB_KEYS.COURSE_STUDENT,
        DB_KEYS.NOTIFICATIONS
    ].forEach(key => {
        if (!localStorage.getItem(key)) saveTable(key, []);
    });

    if (!localStorage.getItem(DB_KEYS.CURRENT_USER)) {
        saveTable(DB_KEYS.CURRENT_USER, {
            name: 'ผู้เยี่ยมชม',
            email: '',
            role: 'guest',
            roleLabel: 'ผู้เยี่ยมชมทั่วไป',
            isLoggedIn: false
        });
    }

    const permanentAdmin = {
        name: 'Super Admin',
        email: 'admin@gmail.com',
        password: 'admin1234',
        phone: '0800000000',
        idNumber: '0000000000000',
        role: 'admin',
        roleLabel: 'แอดมินหลัก',
        isPermanent: true
    };
    const admins = getTable(DB_KEYS.ADMIN);
    if (!admins.some(user => user.email === permanentAdmin.email)) {
        admins.push(permanentAdmin);
        saveTable(DB_KEYS.ADMIN, admins);
    }
}

initDB();
