function normalizeEmail(email) {
    return String(email || '').trim().toLowerCase();
}

function validateAdminCode(inputCode) {
    const entered = String(inputCode || '').trim().toUpperCase();
    return getAdminCodeData().some(code =>
        code.code === entered && !code.used && Date.now() < code.expiresAt
    );
}

function registerStudent(name, email, password, phone, idNumber) {
    const students = getTable(DB_KEYS.STUDENT);
    const normalizedEmail = normalizeEmail(email);
    if (students.some(user => normalizeEmail(user.email) === normalizedEmail || user.idNumber === idNumber)) {
        return { success: false, message: 'อีเมลหรือเลขบัตรประชาชนนี้ถูกใช้งานไปแล้ว' };
    }

    students.push({
        name: name.trim(),
        email: normalizedEmail,
        password,
        phone,
        idNumber,
        role: 'student',
        roleLabel: 'นักเรียน'
    });
    saveTable(DB_KEYS.STUDENT, students);
    return { success: true, message: 'สมัครสมาชิกนักเรียนสำเร็จ' };
}

function registerTutor(name, email, password, phone, idNumber, resume = '', idCardImage = '') {
    const normalizedEmail = normalizeEmail(email);
    const tutors = getTable(DB_KEYS.TUTOR);
    const pending = getTable(DB_KEYS.PENDING_TUTOR);
    const rejected = getTable(DB_KEYS.TUTOR_REJECTED);
    if (tutors.some(user => normalizeEmail(user.email) === normalizedEmail || user.idNumber === idNumber) ||
        pending.some(user => normalizeEmail(user.email) === normalizedEmail || user.idNumber === idNumber)) {
        return { success: false, message: 'อีเมลหรือเลขบัตรประชาชนนี้ถูกใช้งานไปแล้ว' };
    }

    const previousRejection = rejected.find(user =>
        normalizeEmail(user.email) === normalizedEmail && user.idNumber === idNumber
    );
    if (rejected.some(user => normalizeEmail(user.email) === normalizedEmail && !previousRejection)) {
        return { success: false, message: 'อีเมลนี้มีคำขอเดิม กรุณาใช้ลิงก์ส่งเอกสารใหม่จากอีเมลที่แอดมินส่งให้' };
    }

    const applicant = {
        name: name.trim(),
        email: normalizedEmail,
        password,
        phone,
        idNumber,
        resume: String(resume || '').trim(),
        idCardImage,
        role: 'pending_tutor',
        roleLabel: 'รออนุมัติ',
        appliedAt: Date.now()
    };
    pending.push(applicant);
    saveTable(DB_KEYS.PENDING_TUTOR, pending);
    if (previousRejection) {
        saveTable(DB_KEYS.TUTOR_REJECTED, rejected.filter(user => user !== previousRejection));
    }
    return { success: true, message: 'ส่งข้อมูลสมัครติวเตอร์สำเร็จ กรุณารอแอดมินอนุมัติ' };
}

function resubmitTutorApplication(email, idNumber, resume, idCardImage = '') {
    const user = getCurrentUser();
    const normalizedEmail = normalizeEmail(email);
    if (user.role !== 'rejected_tutor' || normalizeEmail(user.email) !== normalizedEmail) {
        return { success: false, message: 'กรุณาเข้าสู่ระบบด้วยบัญชีติวเตอร์ที่ถูกปฏิเสธก่อน' };
    }
    if (!/^\d{13}$/.test(String(idNumber || ''))) {
        return { success: false, message: 'เลขบัตรประชาชนต้องมี 13 หลัก' };
    }
    const rejected = getTable(DB_KEYS.TUTOR_REJECTED);
    const index = rejected.findIndex(item => normalizeEmail(item.email) === normalizedEmail);
    if (index === -1) return { success: false, message: 'ไม่พบคำขอเดิมของบัญชีนี้' };
    if (getTable(DB_KEYS.TUTOR).some(item => item.idNumber === idNumber && normalizeEmail(item.email) !== normalizedEmail) ||
        getTable(DB_KEYS.PENDING_TUTOR).some(item => item.idNumber === idNumber || normalizeEmail(item.email) === normalizedEmail)) {
        return { success: false, message: 'เลขบัตรประชาชนหรืออีเมลนี้ถูกใช้งานในคำขออื่นแล้ว' };
    }

    const applicant = {
        ...rejected[index],
        idNumber,
        resume: String(resume || '').trim(),
        idCardImage: idCardImage || rejected[index].idCardImage || '',
        role: 'pending_tutor',
        roleLabel: 'รออนุมัติ',
        appliedAt: Date.now()
    };
    delete applicant.rejectReason;
    delete applicant.rejectedAt;
    rejected.splice(index, 1);
    const pending = getTable(DB_KEYS.PENDING_TUTOR);
    pending.push(applicant);
    saveTable(DB_KEYS.TUTOR_REJECTED, rejected);
    saveTable(DB_KEYS.PENDING_TUTOR, pending);
    saveTable(DB_KEYS.CURRENT_USER, applicant);
    return { success: true, message: 'ส่งเอกสารใหม่แล้ว กรุณารอแอดมินตรวจสอบ' };
}

function registerAdmin(name, email, password, phone, idNumber, adminCode) {
    const admins = getTable(DB_KEYS.ADMIN);
    const normalizedEmail = normalizeEmail(email);
    if (admins.some(user => normalizeEmail(user.email) === normalizedEmail || user.idNumber === idNumber)) {
        return { success: false, message: 'อีเมลหรือเลขบัตรประชาชนนี้ถูกใช้งานไปแล้ว' };
    }
    const entered = String(adminCode || '').trim().toUpperCase();
    const codes = getAdminCodeData();
    const code = codes.find(item => item.code === entered && !item.used && Date.now() < item.expiresAt);
    if (!code) return { success: false, message: 'โค้ดแอดมินไม่ถูกต้อง หมดอายุ หรือถูกใช้แล้ว' };

    code.used = true;
    code.usedAt = Date.now();
    saveAdminCodeData(codes);
    admins.push({
        name: name.trim(),
        email: normalizedEmail,
        password,
        phone,
        idNumber,
        adminCode: entered,
        codeExpiresAt: code.expiresAt,
        role: 'admin',
        roleLabel: 'แอดมิน',
        isPermanent: false
    });
    saveTable(DB_KEYS.ADMIN, admins);
    return { success: true, message: 'สมัครสมาชิกแอดมินสำเร็จ' };
}

function loginUser(role, email, password) {
    const normalizedEmail = normalizeEmail(email);
    if (role === 'student') {
        const student = getTable(DB_KEYS.STUDENT).find(user =>
            normalizeEmail(user.email) === normalizedEmail && user.password === password
        );
        if (!student) return { success: false, message: 'อีเมลหรือรหัสผ่านของนักเรียนไม่ถูกต้อง' };
        saveTable(DB_KEYS.CURRENT_USER, student);
        return { success: true, role: 'student', redirect: 'learner.html', user: student };
    }

    if (role === 'tutor') {
        const pending = getTable(DB_KEYS.PENDING_TUTOR).find(user =>
            normalizeEmail(user.email) === normalizedEmail
        );
        if (pending) return { success: false, message: 'บัญชีติวเตอร์ของคุณอยู่ระหว่างรอแอดมินอนุมัติ' };

        const tutor = getTable(DB_KEYS.TUTOR).find(user =>
            normalizeEmail(user.email) === normalizedEmail && user.password === password
        );
        if (tutor) {
            saveTable(DB_KEYS.CURRENT_USER, tutor);
            return { success: true, role: 'tutor', redirect: 'tutor.html', user: tutor };
        }

        const rejected = getTable(DB_KEYS.TUTOR_REJECTED).find(user =>
            normalizeEmail(user.email) === normalizedEmail && user.password === password
        );
        if (rejected) {
            const user = { ...rejected, role: 'rejected_tutor', roleLabel: 'รอส่งเอกสารใหม่' };
            saveTable(DB_KEYS.CURRENT_USER, user);
            return { success: true, role: 'rejected_tutor', redirect: 'tutor-resubmit.html', user };
        }
        return { success: false, message: 'อีเมลหรือรหัสผ่านของติวเตอร์ไม่ถูกต้อง' };
    }

    if (role === 'admin') {
        const admin = getTable(DB_KEYS.ADMIN).find(user =>
            normalizeEmail(user.email) === normalizedEmail && user.password === password
        );
        if (!admin) return { success: false, message: 'อีเมลหรือรหัสผ่านของแอดมินไม่ถูกต้อง' };
        if (!admin.isPermanent && (!admin.codeExpiresAt || Date.now() >= admin.codeExpiresAt)) {
            return { success: false, requireRenew: true, message: 'สิทธิ์แอดมินหมดอายุ กรุณาใช้โค้ดใหม่' };
        }
        saveTable(DB_KEYS.CURRENT_USER, admin);
        return { success: true, role: 'admin', redirect: 'admin.html', user: admin };
    }

    return { success: false, message: 'กรุณาเลือกประเภทผู้ใช้งาน' };
}

function renewAdminAccess(email, newCode) {
    const normalizedEmail = normalizeEmail(email);
    const admins = getTable(DB_KEYS.ADMIN);
    const admin = admins.find(user => normalizeEmail(user.email) === normalizedEmail);
    if (!admin || admin.isPermanent) {
        return { success: false, message: 'ไม่พบบัญชีแอดมินที่ต้องต่ออายุ' };
    }
    const entered = String(newCode || '').trim().toUpperCase();
    const codes = getAdminCodeData();
    const code = codes.find(item => item.code === entered && !item.used && Date.now() < item.expiresAt);
    if (!code) return { success: false, message: 'โค้ดแอดมินไม่ถูกต้อง หมดอายุ หรือถูกใช้แล้ว' };

    code.used = true;
    code.usedAt = Date.now();
    admin.adminCode = entered;
    admin.codeExpiresAt = code.expiresAt;
    saveAdminCodeData(codes);
    saveTable(DB_KEYS.ADMIN, admins);
    saveTable(DB_KEYS.CURRENT_USER, admin);
    return { success: true, message: 'ต่ออายุสำเร็จ กำลังเข้าสู่ระบบ...', redirect: 'admin.html' };
}

function resetPassword(role, email, idNumber, phone, newPassword) {
    const tableKey = role === 'student' ? DB_KEYS.STUDENT :
        role === 'tutor' ? DB_KEYS.TUTOR :
        role === 'admin' ? DB_KEYS.ADMIN : null;
    if (!tableKey) return { success: false, message: 'กรุณาเลือกประเภทผู้ใช้งานให้ถูกต้อง' };
    const users = getTable(tableKey);
    const user = users.find(item =>
        normalizeEmail(item.email) === normalizeEmail(email) &&
        item.idNumber === idNumber && item.phone === phone
    );
    if (!user) return { success: false, message: 'ข้อมูลไม่ตรงกับในระบบ' };
    user.password = newPassword;
    saveTable(tableKey, users);
    return { success: true, message: 'ตั้งรหัสผ่านใหม่สำเร็จ' };
}

function resetToGuest() {
    const guest = {
        name: 'ผู้เยี่ยมชม',
        email: '',
        role: 'guest',
        roleLabel: 'ผู้เยี่ยมชมทั่วไป',
        isLoggedIn: false
    };
    saveTable(DB_KEYS.CURRENT_USER, guest);
    return guest;
}

function getCurrentUser() {
    const user = JSON.parse(localStorage.getItem(DB_KEYS.CURRENT_USER) || 'null');
    return user && user.role ? user : resetToGuest();
}

function logout() {
    resetToGuest();
    window.location.href = 'login.html';
}

function requireRoles(allowedRoles = []) {
    const user = getCurrentUser();
    if (allowedRoles.includes(user.role)) return user;

    if (user.role === 'guest') {
        alert('กรุณาเข้าสู่ระบบก่อนเข้าใช้งานหน้านี้');
        window.location.href = 'login.html';
        return null;
    }
    alert('คุณไม่มีสิทธิ์เข้าถึงหน้านี้');
    const homePages = {
        student: 'learner.html',
        tutor: 'tutor.html',
        admin: 'admin.html',
        pending_tutor: 'index.html',
        rejected_tutor: 'tutor-resubmit.html'
    };
    window.location.href = homePages[user.role] || 'index.html';
    return null;
}
