function portalText(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, character => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    })[character]);
}

function portalDate(timestamp) {
    if (!timestamp) return '-';
    return new Date(timestamp).toLocaleString('th-TH', { dateStyle: 'medium', timeStyle: 'short' });
}

function portalShowMessage(element, message, isSuccess) {
    element.textContent = message;
    element.className = `portal-alert show ${isSuccess ? 'success' : 'error'}`;
}

function portalStatusLabel(status) {
    const labels = { approved: 'อนุมัติแล้ว', pending: 'รอตรวจสอบ', rejected: 'ไม่อนุมัติ' };
    return labels[status] || status || 'ไม่ระบุสถานะ';
}

function portalSafeExternalUrl(value) {
    try {
        const url = new URL(String(value || ''));
        return ['http:', 'https:'].includes(url.protocol) ? url.href : '';
    } catch {
        return '';
    }
}

function portalCurrentUser() {
    const user = getCurrentUser();
    const name = document.getElementById('portalUserName');
    const role = document.getElementById('portalUserRole');
    if (name) name.textContent = user.name || user.email;
    if (role) role.textContent = user.roleLabel || user.role;
    return user;
}
