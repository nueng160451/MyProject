requireRoles(['student']);
const learnerUser = portalCurrentUser();
const learnerHost = document.getElementById('learnerCourses');
const learnerSummary = getStudentDashboardData(learnerUser.email);

document.querySelector('[data-stat="enrolled"]').textContent = learnerSummary.totalEnrolled;
document.querySelector('[data-stat="studying"]').textContent = learnerSummary.studyingCount;
document.querySelector('[data-stat="completed"]').textContent = learnerSummary.completedCount;

function renderLearnerCourses() {
    const data = getStudentDashboardData(learnerUser.email);
    learnerHost.replaceChildren();
    if (!data.courses.length) {
        learnerHost.innerHTML = '<div class="portal-empty">ยังไม่มีคอร์สที่ลงทะเบียน <a href="course-select.html">เลือกคอร์สที่ต้องการเรียน</a></div>';
        return;
    }
    data.courses.forEach(item => {
        const card = document.createElement('article');
        card.className = 'portal-card';
        const total = item.course.lessons ? item.course.lessons.length : 0;
        const completed = item.completedLessonIds.length;
        card.innerHTML = `<div class="portal-section-head"><div><h3>${portalText(item.courseTitle)}</h3><div class="portal-meta"><span>${completed}/${total} บทเรียน</span><span>${item.progress}%</span><span>${portalText(item.course.category || '')}</span></div></div><span class="portal-badge ${item.status === 'completed' ? 'approved' : 'pending'}">${item.status === 'completed' ? 'เรียนครบแล้ว' : 'กำลังเรียน'}</span></div><div class="portal-progress" aria-label="ความคืบหน้า ${item.progress}%"><span style="width:${item.progress}%"></span></div>`;
        const actions = document.createElement('div');
        actions.className = 'portal-actions';
        const link = document.createElement('a');
        link.className = 'portal-btn primary';
        link.href = `lesson.html?courseId=${encodeURIComponent(item.courseId)}`;
        link.textContent = item.status === 'completed' ? 'ทบทวนบทเรียน' : 'เรียนต่อ';
        actions.append(link);
        card.append(actions);
        learnerHost.append(card);
    });
}

document.getElementById('learnerLogout').addEventListener('click', logout);
renderLearnerCourses();
