requireRoles(['student']);
const lessonUser = portalCurrentUser();
const courseId = new URLSearchParams(location.search).get('courseId');
const lessonHost = document.getElementById('courseLessons');
const lessonAlert = document.getElementById('lessonMessage');
const fileDialog = document.getElementById('mediaDialog');
let mediaUrl = '';

function renderLessonPage() {
    const course = getCourseById(courseId);
    const enrollment = getStudentDashboardData(lessonUser.email).courses
        .find(item => item.courseId === courseId);
    if (!course || !enrollment) {
        window.location.replace('course-select.html');
        return;
    }
    document.getElementById('courseTitle').textContent = course.title;
    document.getElementById('courseDescription').textContent = course.description || 'คอร์สเรียนออนไลน์';
    document.getElementById('lessonTutor').textContent = course.tutorName || course.tutorEmail;
    document.getElementById('lessonProgressText').textContent =
        `${enrollment.completedLessonIds.length}/${course.lessons.length} บท · ${enrollment.progress}%`;
    document.getElementById('lessonProgressBar').style.width = `${enrollment.progress}%`;
    document.getElementById('lessonPanel').className =
        `portal-card template-preview${course.template === 'focus' ? ' focus' : course.template === 'playful' ? ' playful' : ''}`;
    lessonHost.replaceChildren();

    course.lessons.forEach((lesson, index) => {
        const item = document.createElement('article');
        item.className = 'lesson-editor';
        const done = enrollment.completedLessonIds.includes(lesson.lessonId);
        item.innerHTML = `<div class="portal-section-head"><div><h3>${index + 1}. ${portalText(lesson.title)}</h3><p>${portalText(lesson.description || '')}</p></div><span class="portal-badge ${done ? 'approved' : ''}">${done ? 'เรียนแล้ว' : 'ยังไม่เรียน'}</span></div>`;
        if (lesson.media) {
            const mediaButton = document.createElement('button');
            mediaButton.className = 'portal-btn small';
            mediaButton.textContent = `เปิดไฟล์: ${lesson.media.name}`;
            mediaButton.addEventListener('click', () => showCourseMedia(lesson.media));
            item.append(mediaButton);
        }
        const label = document.createElement('label');
        label.className = 'portal-field';
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.checked = done;
        checkbox.addEventListener('change', () => {
            const result = toggleLessonCompletion(lessonUser.email, courseId, lesson.lessonId, checkbox.checked);
            if (!result.success) {
                portalShowMessage(lessonAlert, result.message, false);
                return;
            }
            portalShowMessage(lessonAlert, result.message, true);
            renderLessonPage();
        });
        const text = document.createElement('span');
        text.textContent = 'เรียนบทนี้จบแล้ว';
        label.append(checkbox, text);
        item.append(label);
        lessonHost.append(item);
    });
}

async function showCourseMedia(media) {
    try {
        const record = await courseFileStore.get(media.id);
        if (!record) throw new Error('ไม่พบไฟล์ในอุปกรณ์นี้');
        if (mediaUrl) URL.revokeObjectURL(mediaUrl);
        mediaUrl = URL.createObjectURL(record.blob);
        const body = document.getElementById('mediaDialogBody');
        body.replaceChildren();
        if (record.type.startsWith('video/')) {
            const video = document.createElement('video');
            video.controls = true;
            video.src = mediaUrl;
            video.className = 'media-preview';
            body.append(video);
        } else {
            const frame = document.createElement('iframe');
            frame.src = mediaUrl;
            frame.title = media.name;
            frame.className = 'media-preview';
            body.append(frame);
        }
        fileDialog.showModal();
    } catch (error) {
        portalShowMessage(lessonAlert, error.message || 'เปิดไฟล์ไม่สำเร็จ', false);
    }
}

document.getElementById('closeMediaDialog').addEventListener('click', () => fileDialog.close());
fileDialog.addEventListener('close', () => {
    if (mediaUrl) URL.revokeObjectURL(mediaUrl);
    mediaUrl = '';
});
document.getElementById('lessonLogout').addEventListener('click', logout);
renderLessonPage();
