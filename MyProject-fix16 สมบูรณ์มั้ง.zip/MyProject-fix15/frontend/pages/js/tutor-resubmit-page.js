requireRoles(['rejected_tutor']);
const rejectedUser = portalCurrentUser();
const resubmitForm = document.getElementById('resubmitForm');
const resubmitMessage = document.getElementById('resubmitMessage');
document.getElementById('resubmitEmail').textContent = rejectedUser.email;
document.getElementById('resubmitIdNumber').value = rejectedUser.idNumber || '';
document.getElementById('rejectReason').textContent = rejectedUser.rejectReason || 'กรุณาส่งข้อมูลเพิ่มเติม';

function readResubmitImage(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(new Error('อ่านภาพบัตรไม่สำเร็จ'));
        reader.readAsDataURL(file);
    });
}

resubmitForm.addEventListener('submit', async event => {
    event.preventDefault();
    const file = resubmitForm.elements.idCardImage.files[0];
    let image = '';
    try {
        if (file) {
            if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type) || file.size > 1024 * 1024) {
                throw new Error('ภาพบัตรต้องเป็น JPG, PNG หรือ WebP และไม่เกิน 1 MB');
            }
            image = await readResubmitImage(file);
        }
        const result = resubmitTutorApplication(
            rejectedUser.email,
            resubmitForm.elements.idNumber.value.trim(),
            resubmitForm.elements.resume.value.trim(),
            image
        );
        portalShowMessage(resubmitMessage, result.message, result.success);
        if (result.success) {
            resubmitForm.querySelector('button[type="submit"]').disabled = true;
        }
    } catch (error) {
        portalShowMessage(resubmitMessage, error.message, false);
    }
});

document.getElementById('resubmitLogout').addEventListener('click', logout);
