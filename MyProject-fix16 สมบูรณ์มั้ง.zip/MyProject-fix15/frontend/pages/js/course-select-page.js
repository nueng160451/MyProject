requireRoles(['student']);
const catalogUser = portalCurrentUser();
const catalogHost = document.getElementById('courseCatalog');
const catalogMessage = document.getElementById('catalogMessage');

async function renderCatalog() {
    const enrolled = new Set(getTable(DB_KEYS.COURSE_STUDENT)
        .filter(item => normalizeEmail(item.studentEmail) === normalizeEmail(catalogUser.email))
        .map(item => item.courseId));
    const courses = getAllApprovedCourses();
    catalogHost.replaceChildren();
    if (!courses.length) {
        catalogHost.innerHTML = '<div class="portal-empty">ยังไม่มีคอร์สที่เปิดสอน</div>';
        return;
    }
    for (const course of courses) {
        const card = document.createElement('article');
        card.className = 'portal-card';
        card.innerHTML = `<span class="portal-badge approved">${portalText(course.category || 'คอร์สเรียน')}</span><h3>${portalText(course.title)}</h3><p>${portalText(course.description || 'คอร์สเรียนออนไลน์')}</p><div class="portal-meta"><span>ติวเตอร์ ${portalText(course.tutorName || course.tutorEmail)}</span><span>${(course.lessons || []).length} บทเรียน</span><span>${Number(course.price || 0)} บาท</span></div>`;
        if (course.coverImage && course.coverImage.id) {
            try {
                const file = await courseFileStore.get(course.coverImage.id);
                if (file) {
                    const image = document.createElement('img');
                    image.className = 'course-cover';
                    image.alt = `ภาพประกอบ ${course.title}`;
                    image.src = URL.createObjectURL(file.blob);
                    card.prepend(image);
                }
            } catch (error) {
                console.error('อ่านภาพคอร์สไม่สำเร็จ', error);
            }
        }
        const action = document.createElement('div');
        action.className = 'portal-actions';
        const button = document.createElement('a');
        button.className = enrolled.has(course.courseId) ? 'portal-link-btn' : 'portal-btn primary';
        button.textContent = enrolled.has(course.courseId) ? 'ไปที่คอร์สของฉัน' : 'ลงทะเบียนเรียน';
        button.href = enrolled.has(course.courseId)
            ? `lesson.html?courseId=${encodeURIComponent(course.courseId)}`
            : '#';
        if (!enrolled.has(course.courseId)) {
            button.addEventListener('click', event => {
                event.preventDefault();
                const result = enrollCourse(catalogUser.email, course.courseId);
                portalShowMessage(catalogMessage, result.message, result.success);
                if (result.success) renderCatalog();
            });
        }
        action.append(button);
        card.append(action);
        catalogHost.append(card);
    }
}

document.getElementById('catalogLogout').addEventListener('click', logout);
renderCatalog();
