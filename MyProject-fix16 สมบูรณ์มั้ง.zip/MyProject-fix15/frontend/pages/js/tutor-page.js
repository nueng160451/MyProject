requireRoles(['tutor']);
const tutorUser = portalCurrentUser();
const tutorCoursesHost = document.getElementById('tutorCourses');
const tutorNoticeHost = document.getElementById('tutorNotifications');
const tutorMessage = document.getElementById('tutorMessage');
const courseForm = document.getElementById('courseForm');
const lessonFields = document.getElementById('lessonFields');
let editingCourseId = '';
let retainedCover = null;

function renderTutorDashboard() {
    const data = getTutorDashboardData(tutorUser.email);
    document.querySelector('[data-stat="students"]').textContent = data.totalStudents;
    document.querySelector('[data-stat="approved"]').textContent = data.approvedCount;
    document.querySelector('[data-stat="pending"]').textContent = data.pendingCount;
    document.querySelector('[data-stat="courses"]').textContent = data.courses.length;

    tutorCoursesHost.replaceChildren();
    if (!data.courses.length) {
        tutorCoursesHost.innerHTML = '<div class="portal-empty">ยังไม่มีคอร์ส ลองสร้างคอร์สแรกของคุณ</div>';
    }
    data.courses.slice().sort((a, b) => (b.submittedAt || b.reviewedAt || 0) - (a.submittedAt || a.reviewedAt || 0))
        .forEach(course => {
            const card = document.createElement('article');
            card.className = 'portal-card';
            const enrolledCount = (course.enrolledStudents || []).length;
            card.innerHTML = `<div class="portal-section-head"><div><h3>${portalText(course.title)}</h3><div class="portal-meta"><span>${portalText(course.category || 'ไม่ระบุหมวดหมู่')}</span><span>${(course.lessons || []).length} บทเรียน</span><span>${enrolledCount} ผู้เรียน</span></div></div><span class="portal-badge ${portalText(course.status)}">${portalText(portalStatusLabel(course.status))}</span></div><p>${portalText(course.description || '')}</p>${course.rejectReason ? `<div class="portal-alert show error">เหตุผล: ${portalText(course.rejectReason)}</div>` : ''}<p class="portal-hint">${course.status === 'pending' ? `ส่งตรวจเมื่อ ${portalDate(course.submittedAt)}` : `อัปเดต ${portalDate(course.reviewedAt || course.submittedAt)}`}</p>`;
            const actions = document.createElement('div');
            actions.className = 'portal-actions';
            if (course.status !== 'approved') {
                const edit = document.createElement('button');
                edit.className = 'portal-btn small';
                edit.textContent = 'แก้ไขและส่งตรวจใหม่';
                edit.addEventListener('click', () => openCourseForm(course));
                actions.append(edit);
            }
            card.append(actions);
            tutorCoursesHost.append(card);
        });
}

function renderTutorNotifications() {
    const notifications = getUserNotifications(tutorUser.email);
    tutorNoticeHost.replaceChildren();
    if (!notifications.length) {
        tutorNoticeHost.innerHTML = '<div class="portal-empty">ยังไม่มีการแจ้งเตือน</div>';
        return;
    }
    notifications.forEach(notification => {
        const item = document.createElement('article');
        item.className = `notice-item${notification.read ? '' : ' unread'}`;
        item.innerHTML = `<div class="portal-section-head"><strong>${portalText(notification.title)}</strong><small>${portalDate(notification.createdAt)}</small></div><p>${portalText(notification.message)}</p>`;
        if (!notification.read) {
            const mark = document.createElement('button');
            mark.className = 'portal-btn small';
            mark.textContent = 'อ่านแล้ว';
            mark.addEventListener('click', () => {
                markNotificationRead(notification.id);
                renderTutorNotifications();
            });
            item.append(mark);
        }
        tutorNoticeHost.append(item);
    });
}

function createLessonEditor(index, lesson = {}) {
    const editor = document.createElement('fieldset');
    editor.className = 'lesson-editor';
    editor.dataset.lesson = String(index);
    const mediaName = lesson.media ? `<p class="portal-hint">ไฟล์ปัจจุบัน: ${portalText(lesson.media.name)}</p>` : '';
    editor.innerHTML = `<legend>บทเรียนที่ ${index + 1}</legend><label class="portal-field">ชื่อบทเรียน<input name="lessonTitle" maxlength="100" required value="${portalText(lesson.title || '')}"></label><label class="portal-field">รายละเอียด (ไม่บังคับ)<textarea name="lessonDescription" maxlength="500">${portalText(lesson.description || '')}</textarea></label><label class="portal-field">ไฟล์สื่อ 1 ไฟล์ (PDF หรือวิดีโอ)<input name="lessonFile" type="file" accept="application/pdf,video/*"></label>${mediaName}<input name="retainedMedia" type="hidden" value="${portalText(lesson.media ? JSON.stringify(lesson.media) : '')}"><p class="portal-hint">PDF ไม่เกิน 10 MB หรือวิดีโอไม่เกิน 50 MB</p>`;
    return editor;
}

function resetCourseForm() {
    courseForm.reset();
    editingCourseId = '';
    retainedCover = null;
    lessonFields.replaceChildren(createLessonEditor(0));
    document.getElementById('courseFormTitle').textContent = 'สร้างคอร์สใหม่';
    document.getElementById('coverFileName').textContent = 'ยังไม่ได้เลือกภาพ';
    document.getElementById('courseFormPanel').hidden = true;
}

function openCourseForm(course = null) {
    resetCourseForm();
    document.getElementById('courseFormPanel').hidden = false;
    if (!course) return;
    editingCourseId = course.courseId;
    retainedCover = course.coverImage || null;
    document.getElementById('courseFormTitle').textContent = 'แก้ไขคอร์สและส่งตรวจใหม่';
    courseForm.elements.title.value = course.title || '';
    courseForm.elements.category.value = course.category || '';
    courseForm.elements.description.value = course.description || '';
    courseForm.elements.price.value = Number(course.price || 0);
    courseForm.elements.template.value = course.template || 'classic';
    lessonFields.replaceChildren(...(course.lessons || []).map((lesson, index) => createLessonEditor(index, lesson)));
    document.getElementById('coverFileName').textContent = retainedCover ? retainedCover.name : 'ยังไม่ได้เลือกภาพ';
    updateTemplatePreview();
    window.scrollTo({ top: document.getElementById('courseFormPanel').offsetTop, behavior: 'smooth' });
}

function updateTemplatePreview() {
    const template = courseForm.elements.template.value;
    const preview = document.getElementById('templatePreview');
    preview.className = `template-preview${template === 'focus' ? ' focus' : template === 'playful' ? ' playful' : ''}`;
    preview.innerHTML = `<strong>${template === 'focus' ? 'Focus — เรียบเข้ม' : template === 'playful' ? 'Playful — สดใส' : 'Classic — เรียบสะอาด'}</strong><p>ตัวอย่างหน้าบทเรียนของนักเรียน</p>`;
}

document.getElementById('addLesson').addEventListener('click', () => {
    if (lessonFields.children.length >= 5) {
        portalShowMessage(tutorMessage, 'เพิ่มบทเรียนได้ไม่เกิน 5 บท', false);
        return;
    }
    lessonFields.append(createLessonEditor(lessonFields.children.length));
});

document.getElementById('newCourse').addEventListener('click', () => openCourseForm());
document.getElementById('cancelCourse').addEventListener('click', resetCourseForm);
courseForm.elements.template.addEventListener('change', updateTemplatePreview);
courseForm.elements.cover.addEventListener('change', () => {
    const file = courseForm.elements.cover.files[0];
    document.getElementById('coverFileName').textContent = file ? file.name : (retainedCover ? retainedCover.name : 'ยังไม่ได้เลือกภาพ');
});

async function saveCourse() {
    const data = {
        title: courseForm.elements.title.value.trim(),
        category: courseForm.elements.category.value.trim(),
        description: courseForm.elements.description.value.trim(),
        price: Number(courseForm.elements.price.value),
        template: courseForm.elements.template.value,
        coverImage: retainedCover,
        lessons: []
    };
    const newFileIds = [];
    try {
        const cover = courseForm.elements.cover.files[0];
        if (cover) {
            if (!['image/jpeg', 'image/png', 'image/webp'].includes(cover.type) || cover.size > 2 * 1024 * 1024) {
                throw new Error('ภาพประกอบต้องเป็น JPG, PNG หรือ WebP และไม่เกิน 2 MB');
            }
            data.coverImage = await courseFileStore.save(cover);
            newFileIds.push(data.coverImage.id);
        }
        for (const [index, editor] of Array.from(lessonFields.children).entries()) {
            const file = editor.querySelector('[name="lessonFile"]').files[0];
            const retainedValue = editor.querySelector('[name="retainedMedia"]').value;
            let media = retainedValue ? JSON.parse(retainedValue) : null;
            if (file) {
                const isPdf = file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf');
                const isVideo = file.type.startsWith('video/');
                if (!isPdf && !isVideo) throw new Error(`บทเรียนที่ ${index + 1}: รองรับเฉพาะไฟล์ PDF หรือวิดีโอ`);
                if (file.size > (isPdf ? 10 : 50) * 1024 * 1024) {
                    throw new Error(`บทเรียนที่ ${index + 1}: ไฟล์มีขนาดใหญ่เกินกำหนด`);
                }
                media = await courseFileStore.save(file);
                newFileIds.push(media.id);
            }
            data.lessons.push({
                title: editor.querySelector('[name="lessonTitle"]').value.trim(),
                description: editor.querySelector('[name="lessonDescription"]').value.trim(),
                media
            });
        }
        const result = editingCourseId
            ? updateTutorCourse(editingCourseId, data)
            : createTutorCourse(tutorUser.email, data);
        if (!result.success) throw new Error(result.message);
        portalShowMessage(tutorMessage, result.message, true);
        resetCourseForm();
        renderTutorDashboard();
    } catch (error) {
        await Promise.all(newFileIds.map(id => courseFileStore.remove(id)));
        portalShowMessage(tutorMessage, error.message || 'บันทึกคอร์สไม่สำเร็จ', false);
    }
}

courseForm.addEventListener('submit', event => {
    event.preventDefault();
    saveCourse();
});
document.getElementById('tutorLogout').addEventListener('click', logout);
lessonFields.append(createLessonEditor(0));
updateTemplatePreview();
renderTutorDashboard();
renderTutorNotifications();
