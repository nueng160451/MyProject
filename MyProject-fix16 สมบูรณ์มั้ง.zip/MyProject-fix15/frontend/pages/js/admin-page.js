requireRoles(['admin']);
const adminUser = portalCurrentUser();
const tutorQueue = document.getElementById('pendingTutors');
const courseQueue = document.getElementById('pendingCourses');
const studentRows = document.getElementById('studentRows');
const tutorRows = document.getElementById('tutorRows');
const adminMessage = document.getElementById('adminMessage');
const adminMediaDialog = document.getElementById('adminMediaDialog');
let adminMediaUrl = '';

function renderAdminStats() {
    const stats = adminGetStats();
    Object.keys(stats).forEach(key => {
        const target = document.querySelector(`[data-stat="${key}"]`);
        if (target) target.textContent = stats[key];
    });
}

function renderTutorQueue() {
    const pending = adminGetPendingTutors();
    tutorQueue.replaceChildren();
    if (!pending.length) {
        tutorQueue.innerHTML = '<div class="portal-empty">ไม่มีคำขอติวเตอร์ที่รอตรวจสอบ</div>';
        return;
    }
    pending.forEach(applicant => {
        const card = document.createElement('article');
        card.className = 'portal-card';
        const links = [];
        const resumeHref = portalSafeExternalUrl(applicant.resume);
        if (resumeHref) {
            const resume = document.createElement('a');
            resume.href = resumeHref;
            resume.target = '_blank';
            resume.rel = 'noopener noreferrer';
            resume.textContent = 'เปิด Resume';
            resume.className = 'portal-link-btn';
            links.push(resume);
        }
        if (/^data:image\/(?:jpeg|png|webp);base64,/i.test(applicant.idCardImage || '')) {
            const idPhoto = document.createElement('a');
            idPhoto.href = applicant.idCardImage;
            idPhoto.target = '_blank';
            idPhoto.rel = 'noopener noreferrer';
            idPhoto.textContent = 'ดูภาพบัตร';
            idPhoto.className = 'portal-link-btn';
            links.push(idPhoto);
        }
        card.innerHTML = `<div class="portal-section-head"><div><h3>${portalText(applicant.name)}</h3><div class="portal-meta"><span>${portalText(applicant.email)}</span><span>โทร ${portalText(applicant.phone)}</span><span>เลขบัตร ${portalText(applicant.idNumber)}</span></div></div><span class="portal-badge pending">รอตรวจสอบ</span></div><p>ส่งคำขอเมื่อ ${portalDate(applicant.appliedAt)}</p>`;
        if (links.length) {
            const linkRow = document.createElement('div');
            linkRow.className = 'portal-actions';
            links.forEach(link => linkRow.append(link));
            card.append(linkRow);
        }
        const actions = document.createElement('div');
        actions.className = 'portal-actions';
        const approve = document.createElement('button');
        approve.className = 'portal-btn primary';
        approve.textContent = 'อนุมัติ';
        approve.addEventListener('click', () => reviewTutor(applicant, true));
        const reject = document.createElement('button');
        reject.className = 'portal-btn danger';
        reject.textContent = 'ไม่อนุมัติ';
        reject.addEventListener('click', () => reviewTutor(applicant, false));
        actions.append(approve, reject);
        card.append(actions);
        tutorQueue.append(card);
    });
}

function createTutorEmailDraft(applicant, approved, reason) {
    const result = approved ? 'อนุมัติคำขอสมัครเป็นติวเตอร์แล้ว' : 'ยังไม่อนุมัติคำขอสมัครเป็นติวเตอร์';
    const retryLink = new URL('tutor-resubmit.html', window.location.href).href;
    const lines = [
        `เรียนคุณ ${applicant.name}`,
        '',
        result,
        reason ? `เหตุผล: ${reason}` : '',
        !approved ? `กรุณาเข้าสู่ระบบและส่งเลขบัตรประชาชน/Resume ใหม่ที่: ${retryLink}` : '',
        '',
        'แอดมิน How to Learn'
    ].filter(Boolean);
    const subject = approved ? 'ผลการสมัครติวเตอร์: อนุมัติ' : 'ผลการสมัครติวเตอร์: ขอเอกสารเพิ่มเติม';
    return `mailto:${encodeURIComponent(applicant.email)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(lines.join('\n'))}`;
}

function reviewTutor(applicant, approved) {
    const reason = approved ? '' : prompt('กรุณาระบุเหตุผลที่ไม่อนุมัติ');
    if (!approved && !String(reason || '').trim()) return;
    const result = adminReviewTutor(applicant.email, approved, reason || '');
    if (!result.success) {
        portalShowMessage(adminMessage, result.message, false);
        return;
    }
    const reviewed = result.applicant || applicant;
    const mail = document.getElementById('tutorEmailDraft');
    mail.href = createTutorEmailDraft(reviewed, approved, reason || '');
    mail.textContent = `เปิดอีเมลแจ้ง${approved ? 'อนุมัติ' : 'ผลการพิจารณา'}ถึง ${reviewed.email}`;
    mail.hidden = false;
    portalShowMessage(adminMessage, `${result.message} — เปิดอีเมลด้านบนเพื่อส่งผลด้วยตนเอง`, true);
    refreshAdmin();
}

function renderCourseQueue() {
    const pending = adminGetPendingCourses();
    courseQueue.replaceChildren();
    if (!pending.length) {
        courseQueue.innerHTML = '<div class="portal-empty">ไม่มีคอร์สที่รอตรวจสอบ</div>';
        return;
    }
    pending.forEach(course => {
        const card = document.createElement('article');
        card.className = 'portal-card';
        card.innerHTML = `<div class="portal-section-head"><div><h3>${portalText(course.title)}</h3><div class="portal-meta"><span>ติวเตอร์ ${portalText(course.tutorName || course.tutorEmail)}</span><span>${portalText(course.category || 'ไม่ระบุหมวดหมู่')}</span><span>${Number(course.price || 0)} บาท</span></div></div><span class="portal-badge pending">รอตรวจสอบ</span></div><p>${portalText(course.description)}</p><p>ส่งเมื่อ ${portalDate(course.submittedAt)}</p>`;
        const lessonList = document.createElement('ol');
        (course.lessons || []).forEach((lesson, index) => {
            const entry = document.createElement('li');
            entry.textContent = `${index + 1}. ${lesson.title || ''}`;
            if (lesson.media) {
                const fileButton = document.createElement('button');
                fileButton.className = 'portal-btn small';
                fileButton.textContent = `ตรวจไฟล์ ${lesson.media.name}`;
                fileButton.addEventListener('click', () => showAdminMedia(lesson.media));
                entry.append(' ', fileButton);
            }
            lessonList.append(entry);
        });
        card.append(lessonList);
        const actions = document.createElement('div');
        actions.className = 'portal-actions';
        const approve = document.createElement('button');
        approve.className = 'portal-btn primary';
        approve.textContent = 'อนุมัติคอร์ส';
        approve.addEventListener('click', () => reviewCourse(course, true));
        const reject = document.createElement('button');
        reject.className = 'portal-btn danger';
        reject.textContent = 'ไม่อนุมัติ';
        reject.addEventListener('click', () => reviewCourse(course, false));
        actions.append(approve, reject);
        card.append(actions);
        courseQueue.append(card);
    });
}

async function showAdminMedia(media) {
    try {
        const record = await courseFileStore.get(media.id);
        if (!record) throw new Error('ไม่พบไฟล์ในอุปกรณ์นี้');
        if (adminMediaUrl) URL.revokeObjectURL(adminMediaUrl);
        adminMediaUrl = URL.createObjectURL(record.blob);
        const body = document.getElementById('adminMediaBody');
        body.replaceChildren();
        if (record.type.startsWith('video/')) {
            const video = document.createElement('video');
            video.controls = true;
            video.src = adminMediaUrl;
            video.className = 'media-preview';
            body.append(video);
        } else {
            const frame = document.createElement('iframe');
            frame.src = adminMediaUrl;
            frame.title = media.name;
            frame.className = 'media-preview';
            body.append(frame);
        }
        adminMediaDialog.showModal();
    } catch (error) {
        portalShowMessage(adminMessage, error.message || 'เปิดไฟล์ไม่สำเร็จ', false);
    }
}

function reviewCourse(course, approved) {
    const reason = approved ? '' : prompt('กรุณาระบุเหตุผลที่ไม่อนุมัติคอร์ส');
    if (!approved && !String(reason || '').trim()) return;
    const result = adminReviewCourse(course.courseId, approved, reason || '');
    portalShowMessage(adminMessage, result.message, result.success);
    refreshAdmin();
}

function renderStudents() {
    const students = adminGetAllStudentsDetail();
    studentRows.replaceChildren();
    if (!students.length) {
        studentRows.innerHTML = '<tr><td colspan="4" class="portal-empty">ยังไม่มีนักเรียน</td></tr>';
        return;
    }
    students.forEach(student => {
        const row = document.createElement('tr');
        row.innerHTML = `<td>${portalText(student.name)}</td><td>${portalText(student.email)}</td><td>${student.totalEnrolled}</td><td>${student.courses.map(course => `${portalText(course.title)} (${course.progress}%)`).join('<br>') || '-'}</td>`;
        studentRows.append(row);
    });
}

function renderTutors() {
    const tutors = adminGetAllTutorsDetail();
    tutorRows.replaceChildren();
    if (!tutors.length) {
        tutorRows.innerHTML = '<div class="portal-empty">ยังไม่มีติวเตอร์ที่ได้รับอนุมัติ</div>';
        return;
    }
    tutors.forEach(tutor => {
        const card = document.createElement('article');
        card.className = 'portal-card';
        const courses = document.createElement('div');
        courses.className = 'portal-list';
        tutor.courses.forEach(course => {
            const row = document.createElement('div');
            row.className = 'portal-row';
            const detail = document.createElement('div');
            detail.innerHTML = `<h3>${portalText(course.title)}</h3><div class="portal-meta"><span class="portal-badge ${portalText(course.status)}">${portalText(portalStatusLabel(course.status))}</span><span>${course.enrolledCount} ผู้เรียน</span><span>${course.lessons.length} บท</span></div>${course.rejectReason ? `<p>${portalText(course.rejectReason)}</p>` : ''}`;
            const remove = document.createElement('button');
            remove.className = 'portal-btn danger small';
            remove.textContent = 'ลบคอร์ส';
            remove.addEventListener('click', () => {
                if (!confirm(`ลบคอร์ส "${course.title}" และข้อมูลการลงทะเบียนหรือไม่?`)) return;
                const result = adminDeleteTutorCourse(course.courseId);
                portalShowMessage(adminMessage, result.message, result.success);
                refreshAdmin();
            });
            row.append(detail, remove);
            courses.append(row);
        });
        card.innerHTML = `<div class="portal-section-head"><div><h3>${portalText(tutor.name)}</h3><div class="portal-meta"><span>${portalText(tutor.email)}</span><span>เลขบัตร ${portalText(tutor.idNumber)}</span><span>โทร ${portalText(tutor.phone)}</span></div></div></div><div class="portal-meta"><span>${tutor.totalCourses} คอร์สที่อนุมัติ</span><span>${tutor.totalLearners} ผู้เรียนทั้งหมด</span></div>`;
        if (tutor.courses.length) card.append(courses);
        else card.insertAdjacentHTML('beforeend', '<p>ยังไม่มีประวัติการส่งคอร์ส</p>');
        tutorRows.append(card);
    });
}

function refreshAdmin() {
    renderAdminStats();
    renderTutorQueue();
    renderCourseQueue();
    renderStudents();
    renderTutors();
}

document.getElementById('generateAdminCode').addEventListener('click', () => {
    const result = generateAdminCode();
    portalShowMessage(adminMessage, result.success
        ? `สร้างโค้ด ${result.code} แล้ว ใช้ได้ถึง ${portalDate(result.expiresAt)}`
        : result.message, result.success);
    renderCodeList();
});

function renderCodeList() {
    const list = document.getElementById('codeList');
    const codes = getAdminCodeData().filter(code => !code.used && code.expiresAt > Date.now());
    list.innerHTML = codes.length
        ? codes.map(code => `<div class="portal-row"><div><strong>${portalText(code.code)}</strong><p>หมดอายุ ${portalDate(code.expiresAt)}</p></div><span class="portal-badge pending">ใช้งานได้</span></div>`).join('')
        : '<div class="portal-empty">ไม่มีโค้ดที่ใช้งานได้</div>';
}

document.getElementById('adminLogout').addEventListener('click', logout);
document.getElementById('closeAdminMedia').addEventListener('click', () => adminMediaDialog.close());
adminMediaDialog.addEventListener('close', () => {
    if (adminMediaUrl) URL.revokeObjectURL(adminMediaUrl);
    adminMediaUrl = '';
});
refreshAdmin();
renderCodeList();
