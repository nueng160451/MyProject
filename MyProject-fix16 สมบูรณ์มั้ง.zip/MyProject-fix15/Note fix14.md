# Note Fix14 - ไฟล์หน้า learner, mycourse และไฟล์ CSS ที่เกี่ยวข้อง

สิ่งที่เพื่อนต้องทำ เราทำหลังบ้านให้แล้วเพื่อนเอาไปปรับกับFrontend ได้เลย

ระบบจะแยกเป็น 5 ไฟล์ ของbacked
1.admin.js (เป็นระบบแอดมิน, สุ่มโค้ด, อนุมัติคำขอ, สลับสถานะ)

2.auth.js (ระบบบัญชีผู้ใช้, สมัคร, ล็อกอิน, ลืมรหัสผ่าน)

3.db.js (หัวใจหลัก เป็นตัวกำหนดค่าไฟล์ กำหนดสตอเรจ )

4.student.js (ระบบลงทะเบียนเรียนและติ๊กถูกคำนวณเปอร์เซ็นต์)

5.tutor.js (ระบบสร้าง แก้ไข และดูสถิติคอร์สของอาจารย์)
---

## อัปเดตระบบหลังบ้าน (แยกเป็น 5 แฟ้ม JS) & คู่มือส่งไม้ต่อตามหน้าที่

ระบบหลังบ้านถูกจัดเรียงแยกเป็น 5 ไฟล์ย่อยในโฟลเดอร์ `js/` เพื่อให้อ่านง่ายและไม่ตีกัน ทุกคนนำไฟล์ไปวางในโฟลเดอร์ `js/` แล้วเรียกใช้งานตามส่วนรับผิดชอบด้านล่างนี้ได้เลยครับ

### 1. โครงสร้างแฟ้มระบบหลังบ้าน (`js/`)
* `js/db.js` : ฐานข้อมูลกลาง `localStorage` (`DB_KEYS`) และฟังก์ชันอ่าน/เขียนข้อมูล **(ต้องโหลดไฟล์นี้เป็นอันดับแรกสุดในทุกหน้า)**
* `js/auth.js` : ระบบสมัครสมาชิก, ล็อกอิน, ลืมรหัสผ่าน, แก้ไขโปรไฟล์ และต่ออายุโค้ดแอดมิน
* `js/tutor.js` : ระบบสร้าง แก้ไข และดึงสถิติคอร์สเรียนฝั่งอาจารย์
* `js/student.js` : ระบบลงทะเบียนเรียน และระบบติ๊กถูกคำนวณเปอร์เซ็นต์ (`0% / 50% / 100%`) ฝั่งนักศึกษา
* `js/admin.js` : ระบบจัดการของแอดมิน (สุ่มโค้ด, ดูข้อมูลนักเรียน/อาจารย์, สลับสถานะ, อนุมัติคำขอพร้อมเหตุผล)

---

### 2. วิธีนำเข้าไฟล์ `<script>` ในแต่ละหน้า HTML (สำคัญมาก: ต้องเรียงตามลำดับนี้)

หน้า tutor.html / course-form.html   HTML<script src="js/db.js"></script>
<script src="js/auth.js"></script>
<script src="js/tutor.js"></script>

หน้า learner.html / mycourse.html / lesson.html / edit-profile.html   
HTML
<script src="js/db.js"></script>
<script src="js/auth.js"></script>
<script src="js/tutor.js"></script>
<script src="js/student.js"></script>

หน้า admin.html 
(ในไฟล์เดิมมี <script src="js/admin.js"></script> อยู่แล้ว ให้เพิ่ม 3 ไฟล์บนไว้ข้างหน้า)   
HTML
<script src="js/db.js"></script>
<script src="js/auth.js"></script>
<script src="js/student.js"></script>
<script src="js/admin.js"></script>

3. คู่มือเชื่อมต่อฟังก์ชันแยกตามหน้าที่
กฎกลางสำหรับทุกหน้า
เช็กผู้ใช้งานปัจจุบันด้วย const user = getCurrentUser();
มุมขวาบนของเว็บ ให้ดึง user.name และ user.roleLabel มาแสดง (ระบบจะแสดงคำว่า "นักเรียน" หรือ "อาจารย์" ให้อัตโนมัติ)


หน้าที่ 1: ระบบสมัครสมาชิก & ล็อกอิน (register.html, login.html)
หน้า register.html   เพิ่มช่องกรอก เบอร์โทร, เลขบัตร ปชช., ตัวเลือก Role (นักเรียน / อาจารย์ / แอดมิน) และช่องใส่ โค้ดแอดมิน / ลิงก์ Resumeเรียกใช้: registerStudent(...), registerTutor(...), หรือ registerAdmin(...)หน้า login.html   เอา action="/login.html" ออกจาก <form> แล้วใช้ JS ดัก Submit เรียก const res = loginUser(email, password);   ถ้า res.success === true ให้สั่ง location.href = res.redirect; (ระบบจะแยกทางไปหน้าของแต่ละ Role ให้อัตโนมัติ) 

หน้าที่ 2: ฝั่งนักศึกษา (learner.html, mycourse.html + สร้างหน้า lesson.html เพิ่ม)หน้า learner.html (หน้ารวมคอร์ส)   เรียก getAllApprovedCourses() เพื่อดึงเฉพาะคอร์สที่แอดมินอนุมัติแล้วมาสร้างการ์ดเมื่อกดลงทะเบียนเรียน ให้เรียก enrollCourse(user.email, courseId)หน้า mycourse.html (หน้าคอร์สของฉัน)   เรียก const data = getStudentDashboardData(user.email);นำ data.completedCount ไปแสดงจำนวนคอร์สที่เรียนจบ และวนลูป data.studyingCourses เพื่อแสดงหลอดเปอร์เซ็นต์ (course.progress + "%")   หน้า lesson.html (หน้าเข้าเรียน — สร้างไฟล์นี้เพิ่ม)   ดึงรายละเอียดคอร์สด้วย getCourseById(courseId) นำ videoUrl มาแปลงเป็นลิงก์ Embed ใส่ใน <iframe> และทำปุ่มเปิดลิงก์เอกสาร (docLink)ทำ Checkbox 2 ช่อง: [ ] ดูคลิปวิดีโอจบแล้ว และ [ ] อ่านไฟล์เอกสารจบแล้วทุกครั้งที่กดติ๊ก ให้เรียก toggleCourseChecklist(user.email, courseId, isVideoChecked, isDocChecked) ระบบจะคำนวณเปอร์เซ็นต์ (0%, 50%, 100%) และเปลี่ยนสถานะเป็นเรียนจบให้อัตโนมัติ

หน้าที่ 3: ฝั่งอาจารย์ / ติวเตอร์ (tutor.html + สร้างหน้า course-form.html เพิ่ม)หน้า tutor.html (หน้าภาพรวมของอาจารย์)   เรียก const data = getTutorDashboardData(user.email);นำ data.totalStudents (ผู้ซื้อทั้งหมด), data.approvedCount (เปิดสอนอยู่), data.pendingCount (รอตรวจสอบ) และ data.bestSeller (คอร์สขายดี) ไปแสดงในการ์ดสรุปผล   วนลูป data.courses เพื่อแสดงรายการคอร์ส สถานะอนุมัติ เหตุผลกรณีถูกตีกลับ (rejectReason) และรายชื่อนักเรียนที่มาลงคอร์ส (enrolledStudents)   หน้า course-form.html (หน้าสร้าง/แก้ไขคอร์สเรียน — สร้างไฟล์นี้เพิ่ม)   ทำฟอร์มกรอก: ชื่อคอร์ส, หมวดหมู่, ลิงก์เอกสาร (Google Drive/PDF), ลิงก์วิดีโอ YouTube, ราคาสร้างคอร์สใหม่เรียก: createTutorCourse(user.email, title, docLink, videoUrl, price, category)แก้ไขคอร์สเดิมเรียก: updateTutorCourse(courseId, title, docLink, videoUrl, price, category) (จะส่งกลับไปรอแอดมินตรวจใหม่ให้อัตโนมัติ)

หน้าที่ 4: ฝั่งแอดมิน (admin.html / admin.js)   สุ่มโค้ดแอดมิน: เรียก const newCode = generateAdminCode(); แล้วนำ newCode.code มาแสดงดูข้อมูลนักเรียนทั้งหมด: เรียก adminGetAllStudentsDetail() (ได้ข้อมูลครบทั้ง อีเมล, บัตร ปชช., เบอร์โทร, คอร์สที่กำลังเรียน, จำนวนที่เรียนเสร็จ, เปอร์เซ็นต์รายวิชา)ดูข้อมูลอาจารย์และคอร์สทั้งหมด: เรียก adminGetAllTutorsDetail() (ได้ข้อมูลครบทั้ง อีเมล, บัตร ปชช., เบอร์โทร, ลิงก์เอกสาร, ลิงก์ YouTube, ราคา, รายชื่อนักเรียนที่ลงคอร์ส)สลับสถานะ (นักเรียน / อาจารย์): เรียก adminSwitchUserRole(email, 'tutor') หรือ adminSwitchUserRole(email, 'student')อนุมัติอาจารย์: ดึงรายการจาก adminGetPendingTutors() และกดตัดสินด้วย adminReviewTutor(email, true/false, rejectReason)อนุมัติคอร์สเรียน: ดึงรายการจาก adminGetPendingCourses() และกดตัดสินด้วย adminReviewCourse(courseId, true/false, rejectReason)