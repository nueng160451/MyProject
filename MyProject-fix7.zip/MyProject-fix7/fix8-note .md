# fix8 note - เพิ่มเนื้อหา Eng PPrai ทำมินิเกม Eng ทุกอันเพิ่ม 
-- ซันซัน --

fixเพิ่มminigame ของEng ทุกอัน และวางโครงquiz กับlesson ของEng ทุกระดับชั้น
#เขียนต่อจากfix7