"use strict";

const cases = [
  {
    topic: "School Library Hours",
    claim: "The school library opens at 8:00 a.m. on weekdays.",
    excerpt: "The school timetable lists library hours as 8:00 a.m.–4:00 p.m., Monday through Friday.",
    classification: "Fact",
    mood: "Calm / Reassuring",
    tone: "Neutral / Informative",
    evidence: "Strong: the official timetable directly verifies the opening time and weekdays.",
    evidenceStrength: "Strong and directly relevant",
    stages: [
      {
        prompt: "Is the claim a fact or an opinion?",
        hint: "A fact can be checked against reliable records or observation.",
        choices: ["Fact — ตรวจสอบได้จากตารางเวลา", "Opinion — เป็นการตัดสินคุณค่าหรือความชอบ"],
        answer: 0
      },
      {
        prompt: "What mood might this factual school timetable create for readers?",
        hint: "ดูภาษาที่ผู้เขียนเลือกใช้: เป็นกลาง หรือแสดงอารมณ์และการโน้มน้าว?",
        choices: ["Calm / Reassuring — สงบและให้ความมั่นใจ", "Anxious / Worried — กังวล", "Excited / Thrilled — ตื่นเต้นมาก"],
        answer: 0
      },
      {
        prompt: "What is the tone of the excerpt?",
        hint: "Tone คือท่าทีของผู้เขียนที่สะท้อนจากภาษาในข้อความ",
        choices: ["Neutral / Informative — เป็นกลางและให้ข้อมูล", "Enthusiastic / Persuasive — กระตือรือร้นและโน้มน้าว", "Critical / Skeptical — วิพากษ์หรือสงสัย"],
        answer: 0
      },
      {
        prompt: "How strong is the evidence for the claim?",
        hint: "หลักฐานจากเอกสารทางการที่ระบุเวลาโดยตรงเกี่ยวข้องกับคำกล่าวอ้างเพียงใด?",
        choices: ["Strong and directly relevant", "Limited — กล่าวถึงเรื่องใกล้เคียงแต่ไม่ยืนยันเวลา", "No evidence is provided"],
        answer: 0
      }
    ]
  },
  {
    topic: "Electric Cars",
    claim: "Electric cars are the greatest invention of this century.",
    excerpt: "The article enthusiastically praises electric cars as “the greatest invention,” and says they produce no tailpipe emissions while driving. It does not compare them with every other invention.",
    classification: "Opinion",
    mood: "Inspired / Optimistic",
    tone: "Enthusiastic / Persuasive",
    evidence: "Limited: lower tailpipe emissions support one benefit, but do not prove that electric cars are the greatest invention.",
    evidenceStrength: "Limited — one benefit does not prove a superlative judgement",
    stages: [
      {
        prompt: "Is the claim a fact or an opinion?",
        hint: "คำว่า greatest เป็นการประเมินหรือจัดอันดับ ซึ่งขึ้นอยู่กับมุมมองหรือไม่?",
        choices: ["Fact — ยืนยันได้โดยตรงว่าเป็นอันดับหนึ่ง", "Opinion — เป็นการตัดสินคุณค่าและไม่มีเกณฑ์วัดชัดเจน"],
        answer: 1
      },
      {
        prompt: "What mood might this enthusiastic article create for readers?",
        hint: "Mood คือความรู้สึกที่ข้อความอาจสร้างให้ผู้อ่าน",
        choices: ["Inspired / Optimistic — ได้แรงบันดาลใจและมองในแง่ดี", "Uneasy / Worried — ไม่สบายใจและกังวล", "Bored / Uninterested — เบื่อและไม่สนใจ"],
        answer: 0
      },
      {
        prompt: "What is the tone of the excerpt?",
        hint: "สังเกตคำ praise และ greatest ซึ่งแสดงท่าทีของผู้เขียน",
        choices: ["Neutral / Informative — เป็นกลาง", "Enthusiastic / Persuasive — ชื่นชมและพยายามโน้มน้าว", "Concerned / Urgent — กังวลและเร่งด่วน"],
        answer: 1
      },
      {
        prompt: "Does the evidence prove that electric cars are the greatest invention?",
        hint: "หลักฐานสนับสนุนประโยชน์เฉพาะด้าน ไม่จำเป็นต้องพิสูจน์คำกล่าวอ้างที่เป็นการจัดอันดับ",
        choices: ["Yes. One environmental benefit proves they are the greatest.", "No. It supports one benefit, but does not prove the ranking.", "Yes. The word greatest is a measurable fact."],
        answer: 1
      }
    ]
  },
  {
    topic: "River Safety",
    claim: "The river level rose 20 centimeters after heavy rain.",
    excerpt: "A water gauge at Riverside Station recorded a 20-centimeter rise between 2:00 and 6:00 p.m. Officials warned residents near the river to prepare for possible flooding.",
    classification: "Fact",
    mood: "Concerned / Uneasy",
    tone: "Concerned / Urgent",
    evidence: "Strong: a measured gauge reading confirms the rise; the warning gives relevant safety context.",
    evidenceStrength: "Strong — measured data directly confirms the rise",
    stages: [
      {
        prompt: "Is the claim a fact or an opinion?",
        hint: "ตัวเลขจากเครื่องวัดสามารถตรวจสอบกับข้อมูลบันทึกได้หรือไม่?",
        choices: ["Fact — ตรวจสอบได้จากค่าที่เครื่องวัดบันทึก", "Opinion — เป็นความรู้สึกส่วนตัวเกี่ยวกับระดับน้ำ"],
        answer: 0
      },
      {
        prompt: "What mood might the flood warning create for readers?",
        hint: "พิจารณาความรู้สึกของผู้อ่านเมื่อเห็นข้อมูลเตือนภัยน้ำท่วม",
        choices: ["Concerned / Uneasy — กังวลและไม่สบายใจ", "Carefree / Amused — สบายใจและขบขัน", "Proud / Triumphant — ภูมิใจและมีชัย"],
        answer: 0
      },
      {
        prompt: "What is the tone of the excerpt?",
        hint: "คำเตือนให้เตรียมรับมือน้ำท่วมทำให้ท่าทีของข้อความเป็นอย่างไร?",
        choices: ["Humorous / Playful — ขบขัน", "Concerned / Urgent — กังวลและเตือนให้รีบระวัง", "Celebratory — เฉลิมฉลอง"],
        answer: 1
      },
      {
        prompt: "Which evidence best supports the 20-centimeter rise?",
        hint: "เลือกหลักฐานที่วัดปริมาณการเปลี่ยนแปลงโดยตรง",
        choices: ["A gauge recorded a 20-centimeter rise.", "Officials gave a flood warning.", "Residents live near the river."],
        answer: 0
      }
    ]
  },
  {
    topic: "The New Cafeteria",
    claim: "Our new cafeteria is a wonderful place to eat.",
    excerpt: "A student survey found that 70 percent of respondents liked the new lunch menu. The writer calls the cafeteria “wonderful.”",
    classification: "Opinion",
    mood: "Cheerful / Welcoming",
    tone: "Positive / Approving",
    evidence: "Limited: the survey shows many respondents liked the menu, but wonderful is a personal judgement.",
    evidenceStrength: "Limited — survey supports popularity, not everyone's judgement",
    stages: [
      {
        prompt: "Is the claim a fact or an opinion?",
        hint: "คำว่า wonderful เป็นสิ่งที่วัดและตรวจสอบได้เหมือนตัวเลขหรือไม่?",
        choices: ["Fact — ทุกคนต้องเห็นตรงกัน", "Opinion — เป็นการประเมินจากความรู้สึก"],
        answer: 1
      },
      {
        prompt: "What mood might the writer's praise of the cafeteria create?",
        hint: "คิดถึงบรรยากาศที่คำว่า wonderful อาจสร้างให้ผู้อ่าน",
        choices: ["Cheerful / Welcoming — ร่าเริงและรู้สึกต้อนรับ", "Alarmed / Frightened — ตื่นตระหนกและกลัว", "Gloomy / Hopeless — หม่นหมองและสิ้นหวัง"],
        answer: 0
      },
      {
        prompt: "What is the tone of the excerpt?",
        hint: "คำว่า wonderful แสดงการชื่นชมหรือการตำหนิ?",
        choices: ["Positive / Approving — ชื่นชมและเห็นด้วย", "Critical / Disapproving — ตำหนิ", "Neutral / Informative — เป็นกลางทั้งหมด"],
        answer: 0
      },
      {
        prompt: "What does the survey evidence support?",
        hint: "แยกสิ่งที่ตัวเลขยืนยันได้ออกจากความเห็นว่า wonderful",
        choices: ["Every student thinks the cafeteria is wonderful.", "Many respondents liked the menu, but the survey cannot prove it is wonderful for everyone.", "The cafeteria serves the best food in the city."],
        answer: 1
      }
    ]
  },
  {
    topic: "City Tree Planting",
    claim: "The city planted 500 trees in public parks last year.",
    excerpt: "The city parks department’s annual report lists 500 trees planted in public parks last year.",
    classification: "Fact",
    mood: "Calm / Informative",
    tone: "Neutral / Informative",
    evidence: "Strong: the department report gives the same number, place, and time period as the claim.",
    evidenceStrength: "Strong — an official report directly matches the claim",
    stages: [
      {
        prompt: "Is the claim a fact or an opinion?",
        hint: "จำนวนต้นไม้และช่วงเวลาสามารถตรวจสอบจากรายงานได้หรือไม่?",
        choices: ["Fact — ตรวจสอบกับรายงานของหน่วยงานได้", "Opinion — เป็นคำชมเชิงคุณค่า"],
        answer: 0
      },
      {
        prompt: "What mood might this neutral report create?",
        hint: "รายงานข้อมูลโดยไม่ใช้ภาษาทางอารมณ์มักสร้างความรู้สึกแบบใด?",
        choices: ["Calm / Informative — สงบและรับรู้ข้อมูล", "Angry / Upset — โกรธและไม่พอใจ", "Panicked / Alarmed — ตื่นตระหนก"],
        answer: 0
      },
      {
        prompt: "What is the tone of the excerpt?",
        hint: "ข้อความรายงานจำนวนและแหล่งข้อมูลโดยไม่มีคำแสดงอารมณ์มี tone แบบใด?",
        choices: ["Neutral / Informative — เป็นกลางและให้ข้อมูล", "Angry / Accusatory — โกรธและกล่าวหา", "Enthusiastic / Persuasive — ชื่นชมและโน้มน้าว"],
        answer: 0
      },
      {
        prompt: "How well does the evidence support the claim?",
        hint: "พิจารณาว่ารายงานทางการตรงกับจำนวน สถานที่ และช่วงเวลาหรือไม่",
        choices: ["Strong — ข้อมูลตรงกับจำนวน สถานที่ และเวลา", "Weak — รายงานพูดถึงต้นไม้แต่ไม่มีตัวเลข", "No evidence is provided"],
        answer: 0
      }
    ]
  }
];

const STAGES_PER_CASE = 4;
const MAX_HEALTH = 5;
const TRANSITION_DELAY = 1200;

let caseIndex = 0;
let stageIndex = 0;
let score = 0;
let health = MAX_HEALTH;
let isAnswerLocked = false;
let transitionTimeout = null;
let verdicts = [];

const elements = {
  caseProgress: document.getElementById("caseProgress"),
  score: document.getElementById("scoreText"),
  health: document.getElementById("healthText"),
  caseType: document.getElementById("caseType"),
  stageProgress: document.getElementById("stageProgress"),
  stageTitle: document.getElementById("stageTitle"),
  caseTopic: document.getElementById("caseTopic"),
  claim: document.getElementById("claimText"),
  evidence: document.getElementById("evidenceText"),
  prompt: document.getElementById("questionPrompt"),
  hint: document.getElementById("stageHint"),
  options: document.getElementById("optionsGrid"),
  feedback: document.getElementById("feedbackBanner"),
  verdictSummary: document.getElementById("verdictSummary"),
  restart: document.getElementById("restartButton"),
  modal: document.getElementById("resultModal"),
  modalIcon: document.getElementById("modalIcon"),
  modalTitle: document.getElementById("modalTitle"),
  modalDescription: document.getElementById("modalDesc"),
  modalScore: document.getElementById("modalScoreText"),
  verdictList: document.getElementById("verdictList"),
  playAgain: document.getElementById("playAgainButton"),
  nextPage: document.getElementById("nextPageButton")
};

function renderHealth() {
  elements.health.textContent = `${"♥ ".repeat(health)}${"♡ ".repeat(MAX_HEALTH - health)}`.trim();
  elements.health.setAttribute("aria-label", `พลังใจ ${health} จาก ${MAX_HEALTH} ดวง`);
}

function stageHeading(index) {
  return ["จำแนก Fact หรือ Opinion", "วิเคราะห์ Mood", "วิเคราะห์ Tone", "ประเมินหลักฐานและตัดสิน"][index];
}

function caseVerdict(caseItem) {
  return `${caseItem.classification} · Mood: ${caseItem.mood} · Tone: ${caseItem.tone} · ${caseItem.evidenceStrength}`;
}

function renderStage() {
  if (caseIndex >= cases.length) {
    finishGame(true);
    return;
  }

  const caseItem = cases[caseIndex];
  const stage = caseItem.stages[stageIndex];
  isAnswerLocked = false;
  elements.caseProgress.textContent = `คดี ${caseIndex + 1} / ${cases.length}`;
  elements.score.textContent = String(score);
  elements.caseType.textContent = `COURT CASE ${caseIndex + 1}`;
  elements.stageProgress.textContent = `ขั้นที่ ${caseIndex * STAGES_PER_CASE + stageIndex + 1} / ${cases.length * STAGES_PER_CASE}`;
  elements.stageTitle.textContent = stageHeading(stageIndex);
  elements.caseTopic.textContent = caseItem.topic;
  elements.claim.textContent = `“${caseItem.claim}”`;
  elements.evidence.textContent = caseItem.excerpt;
  elements.prompt.textContent = stage.prompt;
  elements.hint.textContent = stage.hint;
  elements.feedback.textContent = "";
  elements.feedback.className = "feedback";
  elements.verdictSummary.textContent = stageIndex >= 1
    ? `${caseItem.classification} · Mood: ${caseItem.mood} · Tone: ${caseItem.tone}`
    : "กำลังพิจารณาหลักฐาน";
  elements.options.replaceChildren();

  stage.choices.forEach((choice, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "answer-option";
    button.textContent = choice;
    button.addEventListener("click", () => selectAnswer(button, index, stage, caseItem));
    elements.options.append(button);
  });
}

function selectAnswer(selectedButton, selectedIndex, stage, caseItem) {
  if (isAnswerLocked) return;
  isAnswerLocked = true;
  const isCorrect = selectedIndex === stage.answer;
  const buttons = Array.from(elements.options.children);
  buttons.forEach((button, index) => {
    button.disabled = true;
    if (index === stage.answer) button.classList.add("correct");
  });

  if (isCorrect) {
    score += 10;
    elements.score.textContent = String(score);
    elements.feedback.textContent = "ถูกต้อง! คำตอบสอดคล้องกับข้อความและหลักฐาน";
    elements.feedback.className = "feedback success";
  } else {
    selectedButton.classList.add("incorrect");
    health -= 1;
    renderHealth();
    elements.feedback.textContent = `คำตอบที่เหมาะสมคือ “${stage.choices[stage.answer]}”`;
    elements.feedback.className = "feedback error";
  }

  if (stageIndex === 3) {
    verdicts[caseIndex] = {
      topic: caseItem.topic,
      verdict: caseVerdict(caseItem),
      explanation: caseItem.evidence
    };
  }

  transitionTimeout = window.setTimeout(() => {
    transitionTimeout = null;
    if (health <= 0) {
      finishGame(false);
      return;
    }

    stageIndex += 1;
    if (stageIndex >= STAGES_PER_CASE) {
      caseIndex += 1;
      stageIndex = 0;
    }
    renderStage();
  }, TRANSITION_DELAY);
}

function renderVerdicts() {
  elements.verdictList.replaceChildren();
  verdicts.filter(Boolean).forEach((verdict) => {
    const article = document.createElement("article");
    const heading = document.createElement("h3");
    heading.textContent = verdict.topic;
    const decision = document.createElement("p");
    decision.textContent = verdict.verdict;
    const explanation = document.createElement("p");
    explanation.textContent = verdict.explanation;
    article.append(heading, decision, explanation);
    elements.verdictList.append(article);
  });
}

function finishGame(won) {
  isAnswerLocked = true;
  elements.modal.classList.add("visible");
  elements.modal.setAttribute("aria-hidden", "false");
  elements.modalIcon.textContent = won ? "⚖️" : "📚";
  elements.modalTitle.textContent = won ? "ศาลตัดสินครบทุกคดี!" : "การพิจารณาหยุดลง";
  elements.modalDescription.textContent = won
    ? "เยี่ยมมาก! คุณแยกข้อเท็จจริงจากข้อคิดเห็น วิเคราะห์ Mood และ Tone แยกกัน พร้อมตรวจหลักฐานครบแล้ว"
    : "พลังใจหมดแล้ว ลองทบทวนความต่างระหว่าง Fact, Opinion, Mood และ Tone แล้วเริ่มใหม่อีกครั้ง";
  elements.modalScore.textContent = `คะแนน ${score} / ${cases.length * STAGES_PER_CASE * 10} · พลังใจเหลือ ${health} ดวง`;
  elements.nextPage.style.display = won ? "inline-flex" : "none";
  renderVerdicts();
}

function restartGame() {
  if (transitionTimeout !== null) {
    window.clearTimeout(transitionTimeout);
    transitionTimeout = null;
  }
  caseIndex = 0;
  stageIndex = 0;
  score = 0;
  health = MAX_HEALTH;
  verdicts = [];
  elements.modal.classList.remove("visible");
  elements.modal.setAttribute("aria-hidden", "true");
  renderHealth();
  renderStage();
}

elements.restart.addEventListener("click", restartGame);
elements.playAgain.addEventListener("click", restartGame);
renderHealth();
renderStage();
