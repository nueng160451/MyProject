"use strict";

const questions = [
  {
    question: "Which best describes a fact?",
    options: [
      "A statement that can be checked against reliable information.",
      "A personal feeling that everyone must share.",
      "A sentence that always contains an adjective."
    ],
    answer: 0
  },
  {
    question: "Which statement is an opinion?",
    options: [
      "The school library opens at 8:00 a.m.",
      "The school library is the best place in the building.",
      "The library is on the second floor."
    ],
    answer: 1
  },
  {
    question: "The word “greatest” in “Electric cars are the greatest invention” is a clue that the claim is...",
    options: ["an opinion or value judgement", "a measured fact by itself", "a source citation"],
    answer: 0
  },
  {
    question: "What does Tone describe?",
    options: [
      "The writer's attitude shown through word choice and presentation.",
      "The reader's exact age.",
      "The number of facts in a paragraph."
    ],
    answer: 0
  },
  {
    question: "What does Mood describe?",
    options: [
      "The feeling or atmosphere a text creates for the reader.",
      "The writer's spelling style only.",
      "A list of sources at the end of a text."
    ],
    answer: 0
  },
  {
    question: "An article praises a new invention as “amazing” and “the greatest ever.” What is its likely tone?",
    options: ["Enthusiastic / Persuasive", "Neutral / Informative", "Concerned / Urgent"],
    answer: 0
  },
  {
    question: "A notice says, “Residents near the river should prepare for possible flooding.” What tone is most likely?",
    options: ["Concerned / Urgent", "Humorous / Playful", "Celebratory"],
    answer: 0
  },
  {
    question: "A report lists a measurement and cites an official timetable without emotional language. What is its likely tone?",
    options: ["Neutral / Informative", "Angry / Accusatory", "Enthusiastic / Persuasive"],
    answer: 0
  },
  {
    question: "A text has a concerned tone and describes a flood warning. What mood might it create for readers?",
    options: ["Worried or cautious", "Carefree and amused", "Confused about a joke"],
    answer: 0
  },
  {
    question: "A reliable water gauge recorded a 20-centimeter rise. What kind of evidence is this?",
    options: ["Measured evidence that can be checked", "A personal opinion", "An unsupported prediction"],
    answer: 0
  },
  {
    question: "A survey shows that 70% of students liked a menu. What does this evidence support?",
    options: [
      "Many survey respondents liked the menu.",
      "Every student thinks the cafeteria is wonderful.",
      "The menu is objectively the best in the city."
    ],
    answer: 0
  },
  {
    question: "A report confirms 500 trees were planted, but the writer says this proves the city is the best in the country. What is the best analysis?",
    options: [
      "The report supports the number of trees, but not the broad value judgement.",
      "The report proves every opinion in the article.",
      "A number can never be evidence."
    ],
    answer: 0
  },
  {
    question: "Which evidence best supports the claim “The library opens at 8:00 a.m. on weekdays”?",
    options: [
      "An official schedule listing the library's hours.",
      "A student's opinion that the library is nice.",
      "A photo of a book."
    ],
    answer: 0
  },
  {
    question: "Why should readers check the source of evidence?",
    options: [
      "To judge whether the information is reliable and relevant.",
      "To make every claim sound like an opinion.",
      "To avoid reading the claim."
    ],
    answer: 0
  },
  {
    question: "Which statement correctly distinguishes Fact, Opinion, Tone, and Mood?",
    options: [
      "A fact can be verified; an opinion is a judgement; tone is the writer's attitude; mood is the feeling created for readers.",
      "Fact and opinion mean the same thing; tone and mood are both sources.",
      "Tone is the reader's feeling, and mood is always a proven fact."
    ],
    answer: 0
  }
];

let currentQuestion = 0;
let score = 0;
let canAnswer = true;
let nextQuestionTimeout = null;

const questionNumberEl = document.getElementById("question-number");
const scoreCountEl = document.getElementById("score-count");
const questionTextEl = document.getElementById("question-text");
const optionsContainerEl = document.getElementById("options-container");
const quizBox = document.getElementById("quiz-box");
const resultBox = document.getElementById("result-box");
const finalScoreEl = document.getElementById("final-score");

function loadQuestion() {
  canAnswer = true;
  const question = questions[currentQuestion];
  questionNumberEl.textContent = `ข้อที่ ${currentQuestion + 1} / ${questions.length}`;
  scoreCountEl.textContent = `คะแนน: ${score}`;
  questionTextEl.textContent = question.question;
  optionsContainerEl.replaceChildren();

  question.options.forEach((option, index) => {
    const button = document.createElement("button");
    button.className = "option-btn";
    button.type = "button";
    button.textContent = option;
    button.addEventListener("click", () => selectOption(index, button));
    optionsContainerEl.append(button);
  });
}

function selectOption(selectedIndex, selectedButton) {
  if (!canAnswer) return;
  canAnswer = false;
  const correctIndex = questions[currentQuestion].answer;
  const optionButtons = optionsContainerEl.querySelectorAll(".option-btn");

  if (selectedIndex === correctIndex) {
    selectedButton.classList.add("correct");
    score += 1;
    scoreCountEl.textContent = `คะแนน: ${score}`;
  } else {
    selectedButton.classList.add("incorrect");
    optionButtons[correctIndex].classList.add("correct");
  }
  optionButtons.forEach((button) => {
    button.disabled = true;
  });

  nextQuestionTimeout = window.setTimeout(() => {
    nextQuestionTimeout = null;
    currentQuestion += 1;
    if (currentQuestion < questions.length) {
      loadQuestion();
    } else {
      showResult();
    }
  }, 1000);
}

function showResult() {
  quizBox.classList.add("hidden");
  resultBox.classList.remove("hidden");
  finalScoreEl.textContent = `คุณได้คะแนน ${score} จาก ${questions.length} คะแนน`;
}

function restartQuiz() {
  if (nextQuestionTimeout !== null) {
    window.clearTimeout(nextQuestionTimeout);
    nextQuestionTimeout = null;
  }
  currentQuestion = 0;
  score = 0;
  resultBox.classList.add("hidden");
  quizBox.classList.remove("hidden");
  loadQuestion();
}

loadQuestion();
