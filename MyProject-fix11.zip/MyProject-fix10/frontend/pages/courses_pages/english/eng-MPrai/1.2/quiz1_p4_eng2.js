"use strict";

const questions = [
  {
    question: "In “The witness said that the building was empty,” what is the noun clause?",
    options: ["that the building was empty", "The witness said", "was empty"],
    answer: 0
  },
  {
    question: "Complete the indirect question: We do not know where the meeting ___.",
    options: ["is", "is the meeting", "does the meeting"],
    answer: 0
  },
  {
    question: "Which sentence uses correct word order in a noun clause?",
    options: [
      "The reporter asked where the event was.",
      "The reporter asked where was the event.",
      "The reporter asked where did the event."
    ],
    answer: 0
  },
  {
    question: "Which word can introduce an embedded Yes-No question?",
    options: ["whether", "because", "although"],
    answer: 0
  },
  {
    question: "Choose the noun clause that works as the subject.",
    options: [
      "What the reporter discovered surprised the editor.",
      "The reporter discovered what?",
      "The editor surprised the reporter."
    ],
    answer: 0
  },
  {
    question: "In “I believe that the interview will begin at noon,” the that-clause is...",
    options: ["the object of believe", "the subject of begin", "an adjective modifying noon"],
    answer: 0
  },
  {
    question: "Which is the correct reduced form of “students who are participating in the competition”?",
    options: [
      "students participating in the competition",
      "students participated in the competition",
      "students to participating in the competition"
    ],
    answer: 0
  },
  {
    question: "The reporter ___ the mayor is from our school.",
    options: ["interviewing", "interviewed by", "interview"],
    answer: 0
  },
  {
    question: "Choose the correct reduction of “the article which was published this morning.”",
    options: [
      "the article published this morning",
      "the article publishing this morning",
      "the article publish this morning"
    ],
    answer: 0
  },
  {
    question: "The evidence ___ by the journalists was checked carefully.",
    options: ["collected", "collecting", "collect"],
    answer: 0
  },
  {
    question: "When is a present participle (V-ing) generally used in a reduced relative clause?",
    options: [
      "When the noun being described performs the action (active meaning).",
      "When the noun being described receives the action (passive meaning).",
      "Only when the sentence is a question."
    ],
    answer: 0
  },
  {
    question: "When is a past participle (V.3) generally used in a reduced relative clause?",
    options: [
      "When the noun being described receives the action (passive meaning).",
      "When the noun being described performs the action (active meaning).",
      "Only with future actions."
    ],
    answer: 0
  },
  {
    question: "What is the full relative clause behind “the students participating in the competition”?",
    options: [
      "the students who are participating in the competition",
      "the students which participating in the competition",
      "the students who participated are competition"
    ],
    answer: 0
  },
  {
    question: "Choose the correct reduced form of “anyone who is interested in joining the school newspaper.”",
    options: [
      "anyone interested in joining the school newspaper",
      "anyone interesting in joining the school newspaper",
      "anyone interest joining the school newspaper"
    ],
    answer: 0
  },
  {
    question: "Which sentence is correctly formed?",
    options: [
      "The editor asked whether the source had confirmed the story.",
      "The editor asked whether had the source confirmed the story.",
      "The editor asked whether the source did confirmed the story."
    ],
    answer: 0
  }
];

let currentQuestion = 0;
let score = 0;
let canAnswer = true;
let nextQuestionTimeout = null;

const questionNumberEl = document.getElementById("question-number");
const scoreCountEl = document.getElementById("score-count");
const questionTextEl = document.getElementById("question-text");
const optionsContainerEl = document.getElementById("options-container");
const quizBox = document.getElementById("quiz-box");
const resultBox = document.getElementById("result-box");
const finalScoreEl = document.getElementById("final-score");

function loadQuestion() {
  canAnswer = true;
  const question = questions[currentQuestion];
  questionNumberEl.textContent = `ข้อที่ ${currentQuestion + 1} / ${questions.length}`;
  scoreCountEl.textContent = `คะแนน: ${score}`;
  questionTextEl.textContent = question.question;
  optionsContainerEl.replaceChildren();

  question.options.forEach((option, index) => {
    const button = document.createElement("button");
    button.className = "option-btn";
    button.type = "button";
    button.textContent = option;
    button.addEventListener("click", () => selectOption(index, button));
    optionsContainerEl.append(button);
  });
}

function selectOption(selectedIndex, selectedButton) {
  if (!canAnswer) return;
  canAnswer = false;
  const correctIndex = questions[currentQuestion].answer;
  const optionButtons = optionsContainerEl.querySelectorAll(".option-btn");

  if (selectedIndex === correctIndex) {
    selectedButton.classList.add("correct");
    score += 1;
    scoreCountEl.textContent = `คะแนน: ${score}`;
  } else {
    selectedButton.classList.add("incorrect");
    optionButtons[correctIndex].classList.add("correct");
  }
  optionButtons.forEach((button) => {
    button.disabled = true;
  });

  nextQuestionTimeout = window.setTimeout(() => {
    nextQuestionTimeout = null;
    currentQuestion += 1;
    if (currentQuestion < questions.length) {
      loadQuestion();
    } else {
      showResult();
    }
  }, 1000);
}

function showResult() {
  quizBox.classList.add("hidden");
  resultBox.classList.remove("hidden");
  finalScoreEl.textContent = `คุณได้คะแนน ${score} จาก ${questions.length} คะแนน`;
}

function restartQuiz() {
  if (nextQuestionTimeout !== null) {
    window.clearTimeout(nextQuestionTimeout);
    nextQuestionTimeout = null;
  }
  currentQuestion = 0;
  score = 0;
  resultBox.classList.add("hidden");
  quizBox.classList.remove("hidden");
  loadQuestion();
}

loadQuestion();
