"use strict";

const questions = [
  {
    category: "Noun Clause · reported information",
    prompt: "พยานให้ข้อมูลว่าอาคารว่างเปล่า",
    hint: "Noun clause ทำหน้าที่เป็นกรรมของ said; ใช้ that + subject + verb",
    answer: ["The", "witness", "said", "that", "the", "building", "was", "empty", "."]
  },
  {
    category: "Noun Clause · indirect question",
    prompt: "นักข่าวไม่รู้ว่าการประชุมเริ่มเมื่อไร",
    hint: "หลัง know ใช้ indirect question แบบบอกเล่า: question word + subject + verb",
    answer: ["The", "reporter", "does", "not", "know", "when", "the", "meeting", "starts", "."]
  },
  {
    category: "Noun Clause · wh-clause as subject",
    prompt: "สิ่งที่นักข่าวค้นพบทำให้บรรณาธิการประหลาดใจ",
    hint: "Wh-clause สามารถทำหน้าที่เป็นประธานของประโยคหลัก",
    answer: ["What", "the", "reporter", "discovered", "surprised", "the", "editor", "."]
  },
  {
    category: "Noun Clause · embedded yes/no question",
    prompt: "บรรณาธิการถามว่าแหล่งข่าวยืนยันเรื่องนี้แล้วหรือยัง",
    hint: "ใช้ whether/if ใน indirect yes/no question และเรียงแบบ subject + verb",
    answer: ["The", "editor", "asked", "whether", "the", "source", "had", "confirmed", "the", "story", "."]
  },
  {
    category: "Noun Clause · belief",
    prompt: "ฉันเชื่อว่าการสัมภาษณ์จะเริ่มตอนเที่ยง",
    hint: "that-clause ทำหน้าที่เป็นกรรมของ believe",
    answer: ["I", "believe", "that", "the", "interview", "will", "begin", "at", "noon", "."]
  },
  {
    category: "Reduced Relative Clause · active",
    prompt: "นักเรียนที่เข้าร่วมการแข่งขันรู้สึกตื่นเต้น",
    hint: "Active relative clause ที่มี who/that + be สามารถย่อเป็น V-ing",
    answer: ["The", "students", "participating", "in", "the", "competition", "are", "excited", "."]
  },
  {
    category: "Reduced Relative Clause · passive",
    prompt: "บทความที่ตีพิมพ์เมื่อเช้านี้แก้ข่าวลือดังกล่าว",
    hint: "Passive relative clause ที่มี which/that + be สามารถย่อเป็น V.3",
    answer: ["The", "article", "published", "this", "morning", "corrected", "the", "rumor", "."]
  },
  {
    category: "Reduced Relative Clause · active",
    prompt: "นักข่าวที่กำลังสัมภาษณ์นายกเทศมนตรีมาจากโรงเรียนของเรา",
    hint: "ย่อ who is interviewing เป็น interviewing เพื่อขยาย reporter",
    answer: ["The", "reporter", "interviewing", "the", "mayor", "is", "from", "our", "school", "."]
  },
  {
    category: "Reduced Relative Clause · passive",
    prompt: "หลักฐานที่นักข่าวรวบรวมมาถูกตรวจสอบอย่างละเอียด",
    hint: "ย่อ which was collected เป็น collected เพราะเป็นความหมาย passive",
    answer: ["The", "evidence", "collected", "by", "the", "journalists", "was", "checked", "carefully", "."]
  },
  {
    category: "Reduced Relative Clause · participle phrase",
    prompt: "ทุกคนที่สนใจเข้าร่วมหนังสือพิมพ์โรงเรียนควรติดต่อบรรณาธิการ",
    hint: "ลด who are interested เป็น interested เพื่อขยาย anyone",
    answer: ["Anyone", "interested", "in", "joining", "the", "school", "newspaper", "should", "contact", "the", "editor", "."]
  }
];

const MAX_HEALTH = 3;
const RETRY_DELAY = 1600;
const NEXT_QUESTION_DELAY = 1100;

let currentQuestion = 0;
let score = 0;
let health = MAX_HEALTH;
let selectedTokenIds = [];
let isLocked = false;
let transitionTimeout = null;
let ignoreClickUntil = 0;

const elements = {
  progress: document.getElementById("questionProgress"),
  score: document.getElementById("scoreText"),
  health: document.getElementById("healthText"),
  tag: document.getElementById("grammarTag"),
  number: document.getElementById("questionNumber"),
  prompt: document.getElementById("thaiPrompt"),
  hint: document.getElementById("grammarHint"),
  answerArea: document.getElementById("answerArea"),
  wordBank: document.getElementById("wordBank"),
  feedback: document.getElementById("feedbackBanner"),
  check: document.getElementById("checkButton"),
  undo: document.getElementById("undoButton"),
  clear: document.getElementById("clearButton"),
  restart: document.getElementById("restartButton"),
  modal: document.getElementById("resultModal"),
  modalIcon: document.getElementById("modalIcon"),
  modalTitle: document.getElementById("modalTitle"),
  modalDescription: document.getElementById("modalDesc"),
  modalScore: document.getElementById("modalScoreText"),
  playAgain: document.getElementById("playAgainButton"),
  nextPage: document.getElementById("nextPageButton")
};

function shuffle(items) {
  const shuffled = items.slice();
  for (let index = shuffled.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [shuffled[index], shuffled[swapIndex]] = [shuffled[swapIndex], shuffled[index]];
  }
  return shuffled;
}

function renderHealth() {
  elements.health.textContent = `${"♥ ".repeat(health)}${"♡ ".repeat(MAX_HEALTH - health)}`.trim();
  elements.health.setAttribute("aria-label", `พลังใจ ${health} จาก ${MAX_HEALTH} ดวง`);
}

function renderToken(token, location) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = `word-tile ${location === "answer" ? "placed-tile" : ""}`;
  button.textContent = token.text;
  button.draggable = location === "bank" && !isLocked;
  button.disabled = isLocked;
  button.dataset.tokenId = String(token.id);

  if (location === "bank") {
    button.addEventListener("click", () => {
      if (Date.now() < ignoreClickUntil || isLocked) return;
      selectedTokenIds.push(token.id);
      renderSentence();
    });
    button.addEventListener("dragstart", (event) => {
      event.dataTransfer.setData("text/plain", String(token.id));
      event.dataTransfer.effectAllowed = "move";
    });
    button.addEventListener("dragend", () => {
      ignoreClickUntil = Date.now() + 250;
    });
  } else {
    button.addEventListener("click", () => {
      if (isLocked) return;
      selectedTokenIds = selectedTokenIds.filter((id) => id !== token.id);
      renderSentence();
    });
  }
  return button;
}

function renderSentence() {
  const question = questions[currentQuestion];
  const tokens = question.answer.map((text, id) => ({ id, text }));
  const selectedIds = new Set(selectedTokenIds);
  elements.answerArea.replaceChildren();
  elements.wordBank.replaceChildren();

  selectedTokenIds.forEach((id) => {
    elements.answerArea.append(renderToken(tokens[id], "answer"));
  });
  shuffle(tokens.filter((token) => !selectedIds.has(token.id)))
    .forEach((token) => elements.wordBank.append(renderToken(token, "bank")));

  elements.answerArea.classList.toggle("empty", selectedTokenIds.length === 0);
  elements.check.disabled = isLocked;
  elements.undo.disabled = isLocked || selectedTokenIds.length === 0;
  elements.clear.disabled = isLocked || selectedTokenIds.length === 0;
}

function renderQuestion() {
  const question = questions[currentQuestion];
  isLocked = false;
  selectedTokenIds = [];
  elements.progress.textContent = `${currentQuestion + 1} / ${questions.length}`;
  elements.score.textContent = String(score);
  elements.tag.textContent = question.category;
  elements.number.textContent = `ข่าว ${currentQuestion + 1}`;
  elements.prompt.textContent = question.prompt;
  elements.hint.textContent = question.hint;
  elements.feedback.textContent = "";
  elements.feedback.className = "feedback";
  renderSentence();
}

function sentenceFromTokens(tokenTexts) {
  return tokenTexts.reduce((sentence, token) => {
    if ([",", ".", "?", "!"].includes(token)) return `${sentence.trimEnd()}${token}`;
    return sentence ? `${sentence} ${token}` : token;
  }, "");
}

function checkSentence() {
  if (isLocked) return;
  if (selectedTokenIds.length === 0) {
    elements.feedback.textContent = "เลือกคำจากคลังก่อน แล้วเรียงลงในพื้นที่สร้างประโยค";
    elements.feedback.className = "feedback";
    return;
  }

  const question = questions[currentQuestion];
  const tokens = question.answer.map((text, id) => ({ id, text }));
  const actual = selectedTokenIds.map((id) => tokens[id].text);
  const isCorrect = actual.length === question.answer.length
    && actual.every((word, index) => word === question.answer[index]);

  if (isCorrect) {
    isLocked = true;
    score += 10;
    elements.score.textContent = String(score);
    elements.feedback.textContent = "เยี่ยมมาก! เรียบเรียงประโยคข่าวได้ถูกต้อง";
    elements.feedback.className = "feedback correct";
    renderSentence();
    transitionTimeout = window.setTimeout(() => {
      transitionTimeout = null;
      currentQuestion += 1;
      if (currentQuestion < questions.length) {
        renderQuestion();
      } else {
        finishGame(true);
      }
    }, NEXT_QUESTION_DELAY);
    return;
  }

  health -= 1;
  renderHealth();
  elements.feedback.textContent = `ลำดับยังไม่ถูก ลองอีกครั้ง: ${sentenceFromTokens(question.answer)}`;
  elements.feedback.className = "feedback wrong";

  if (health === 0) {
    isLocked = true;
    renderSentence();
    transitionTimeout = window.setTimeout(() => {
      transitionTimeout = null;
      finishGame(false);
    }, RETRY_DELAY);
    return;
  }

  isLocked = true;
  renderSentence();
  transitionTimeout = window.setTimeout(() => {
    transitionTimeout = null;
    isLocked = false;
    selectedTokenIds = [];
    elements.feedback.textContent = "ลองประกอบประโยคอีกครั้งจากคลังคำ";
    elements.feedback.className = "feedback";
    renderSentence();
  }, RETRY_DELAY);
}

function finishGame(won) {
  isLocked = true;
  elements.modal.classList.add("active");
  elements.modal.setAttribute("aria-hidden", "false");
  elements.modalIcon.textContent = won ? "📰" : "📝";
  elements.modalTitle.textContent = won ? "ข่าวพร้อมเผยแพร่!" : "ภารกิจห้องข่าวหยุดชั่วคราว";
  elements.modalDescription.textContent = won
    ? "เยี่ยมมาก! คุณตรวจสอบข้อมูลและเรียบเรียง Noun Clauses กับ Reduced Relative Clauses ครบแล้ว"
    : "ทบทวนลำดับประโยคและคำใบ้ไวยากรณ์ แล้วเริ่มภารกิจห้องข่าวอีกครั้ง";
  elements.modalScore.textContent = `คะแนนรวม ${score} / ${questions.length * 10} · พลังใจเหลือ ${health} ดวง`;
  elements.nextPage.style.display = won ? "inline-flex" : "none";
}

function restartGame() {
  if (transitionTimeout !== null) {
    window.clearTimeout(transitionTimeout);
    transitionTimeout = null;
  }
  currentQuestion = 0;
  score = 0;
  health = MAX_HEALTH;
  selectedTokenIds = [];
  isLocked = false;
  elements.modal.classList.remove("active");
  elements.modal.setAttribute("aria-hidden", "true");
  renderHealth();
  renderQuestion();
}

elements.answerArea.addEventListener("dragover", (event) => {
  event.preventDefault();
  elements.answerArea.classList.add("drag-over");
  event.dataTransfer.dropEffect = "move";
});
elements.answerArea.addEventListener("dragleave", (event) => {
  if (!elements.answerArea.contains(event.relatedTarget)) {
    elements.answerArea.classList.remove("drag-over");
  }
});
elements.answerArea.addEventListener("drop", (event) => {
  event.preventDefault();
  elements.answerArea.classList.remove("drag-over");
  if (isLocked) return;
  const tokenId = Number(event.dataTransfer.getData("text/plain"));
  const question = questions[currentQuestion];
  if (Number.isInteger(tokenId) && tokenId >= 0 && tokenId < question.answer.length
      && !selectedTokenIds.includes(tokenId)) {
    selectedTokenIds.push(tokenId);
    renderSentence();
  }
});
elements.check.addEventListener("click", checkSentence);
elements.undo.addEventListener("click", () => {
  selectedTokenIds.pop();
  renderSentence();
});
elements.clear.addEventListener("click", () => {
  selectedTokenIds = [];
  renderSentence();
});
elements.restart.addEventListener("click", restartGame);
elements.playAgain.addEventListener("click", restartGame);

renderHealth();
renderQuestion();
