"use strict";

const questions = [
  {
    question: "Which is the usual order of the main parts of an essay?",
    options: [
      "Conclusion, introduction, body paragraphs",
      "Introduction, body paragraphs, conclusion",
      "Body paragraphs, conclusion, introduction"
    ],
    answer: 1
  },
  {
    question: "What is the main purpose of an Introduction?",
    options: [
      "To list every detail from the body paragraphs.",
      "To add a new argument after the essay is finished.",
      "To introduce the topic and lead to the essay's main idea."
    ],
    answer: 2
  },
  {
    question: "What does a Thesis Statement do?",
    options: [
      "Provides an unrelated example.",
      "Signals that a single sentence is a question.",
      "States the essay's main idea or position."
    ],
    answer: 2
  },
  {
    question: "Which sentence is the best Topic Sentence for a paragraph about education?",
    options: [
      "For example, one website has many pages.",
      "First, English gives students access to a wider range of learning resources.",
      "In conclusion, English is useful."
    ],
    answer: 1
  },
  {
    question: "What is the role of Supporting Details in a Body Paragraph?",
    options: [
      "Change the essay to a completely unrelated topic.",
      "Explain, develop, or give evidence for the paragraph's main point.",
      "Repeat the title without explaining it."
    ],
    answer: 1
  },
  {
    question: "Which phrase most clearly signals that another point is being added?",
    options: ["On the other hand", "In conclusion", "Moreover"],
    answer: 2
  },
  {
    question: "Which transition is commonly used to introduce an example?",
    options: ["Therefore", "For instance", "In contrast"],
    answer: 1
  },
  {
    question: "Choose the transition that best completes the sentence: “Many research articles are published in English. ___, students can find more learning resources.”",
    options: ["As a result", "On the other hand", "Similarly"],
    answer: 0
  },
  {
    question: "What relationship does “On the other hand” usually signal?",
    options: ["A summary of the essay", "An example that supports the same point", "Contrast or a different viewpoint"],
    answer: 2
  },
  {
    question: "Which transition best shows a similar idea?",
    options: ["However", "To sum up", "Similarly"],
    answer: 2
  },
  {
    question: "Which transition is most appropriate for starting a conclusion?",
    options: ["For instance", "First", "In conclusion"],
    answer: 2
  },
  {
    question: "What is the best order for a clear Body Paragraph?",
    options: [
      "Example, conclusion, unrelated topic, title",
      "Thesis, new introduction, title, source list",
      "Topic Sentence, supporting explanation, example, result or link"
    ],
    answer: 2
  },
  {
    question: "Why should a writer use transitional phrases?",
    options: [
      "To make every sentence longer, regardless of meaning.",
      "To replace supporting details with linking words.",
      "To show how ideas relate and help the essay flow."
    ],
    answer: 2
  },
  {
    question: "Which transition best completes this sentence? “Many employers value English communication. ___, employees may need it when working with international clients.”",
    options: ["In conclusion", "On the other hand", "For example"],
    answer: 2
  },
  {
    question: "What should a writer generally avoid in the Conclusion?",
    options: [
      "Restating the thesis in fresh words.",
      "Briefly summarizing the main supporting points.",
      "Introducing a major new reason that the essay has not explained."
    ],
    answer: 2
  }
];

let currentQuestion = 0;
let score = 0;
let canAnswer = true;
let nextQuestionTimeout = null;

const questionNumberEl = document.getElementById("question-number");
const scoreCountEl = document.getElementById("score-count");
const questionTextEl = document.getElementById("question-text");
const optionsContainerEl = document.getElementById("options-container");
const quizBox = document.getElementById("quiz-box");
const resultBox = document.getElementById("result-box");
const finalScoreEl = document.getElementById("final-score");

function loadQuestion() {
  canAnswer = true;
  const question = questions[currentQuestion];
  questionNumberEl.textContent = `ข้อที่ ${currentQuestion + 1} / ${questions.length}`;
  scoreCountEl.textContent = `คะแนน: ${score}`;
  questionTextEl.textContent = question.question;
  optionsContainerEl.replaceChildren();

  question.options.forEach((option, index) => {
    const button = document.createElement("button");
    button.className = "option-btn";
    button.type = "button";
    button.textContent = option;
    button.addEventListener("click", () => selectOption(index, button));
    optionsContainerEl.append(button);
  });
}

function selectOption(selectedIndex, selectedButton) {
  if (!canAnswer) return;
  canAnswer = false;
  const correctIndex = questions[currentQuestion].answer;
  const optionButtons = optionsContainerEl.querySelectorAll(".option-btn");

  if (selectedIndex === correctIndex) {
    selectedButton.classList.add("correct");
    score += 1;
    scoreCountEl.textContent = `คะแนน: ${score}`;
  } else {
    selectedButton.classList.add("incorrect");
    optionButtons[correctIndex].classList.add("correct");
  }
  optionButtons.forEach((button) => {
    button.disabled = true;
  });

  nextQuestionTimeout = window.setTimeout(() => {
    nextQuestionTimeout = null;
    currentQuestion += 1;
    if (currentQuestion < questions.length) {
      loadQuestion();
    } else {
      showResult();
    }
  }, 850);
}

function showResult() {
  quizBox.classList.add("hidden");
  resultBox.classList.remove("hidden");
  finalScoreEl.textContent = `คุณได้คะแนน ${score} จาก ${questions.length} คะแนน`;
}

function restartQuiz() {
  if (nextQuestionTimeout !== null) {
    window.clearTimeout(nextQuestionTimeout);
    nextQuestionTimeout = null;
  }
  currentQuestion = 0;
  score = 0;
  resultBox.classList.add("hidden");
  quizBox.classList.remove("hidden");
  loadQuestion();
}

loadQuestion();
