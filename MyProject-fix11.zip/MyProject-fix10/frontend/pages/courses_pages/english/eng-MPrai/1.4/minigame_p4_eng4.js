"use strict";

const puzzles = [
  {
    title: "ภารกิจ 1: วางโครงสร้าง Essay",
    instruction: "เรียงส่วนหลักของ Essay ตั้งแต่เปิดประเด็นจนถึงบทสรุป",
    pieces: [
      { id: "body2", text: "Body Paragraph 2 — เพิ่มเหตุผลสนับสนุนอีกข้อ พร้อมตัวอย่าง" },
      { id: "conclusion", text: "Conclusion — สรุปประเด็นและปิดท้ายความคิด" },
      { id: "introduction", text: "Introduction — เกริ่นหัวข้อและบอก Thesis Statement" },
      { id: "body1", text: "Body Paragraph 1 — เสนอเหตุผลแรก พร้อมรายละเอียดสนับสนุน" }
    ],
    answer: ["introduction", "body1", "body2", "conclusion"],
    explanation: "Essay ทั่วไปเริ่มด้วย Introduction ตามด้วย Body Paragraphs และจบด้วย Conclusion"
  },
  {
    title: "ภารกิจ 2: สร้าง Introduction",
    instruction: "เรียงจากบริบทกว้างไปสู่ Thesis Statement ที่ชัดเจน",
    pieces: [
      { id: "thesis", text: "For these reasons, learning English is important because it supports education, career growth, and communication." },
      { id: "context", text: "Students encounter English in books, online resources, travel, and international conversations." },
      { id: "opening", text: "In today's connected world, people often communicate across countries and cultures." }
    ],
    answer: ["opening", "context", "thesis"],
    explanation: "Introduction เริ่มจากประเด็นนำเข้า ขยายบริบท แล้วจบด้วย Thesis Statement ที่บอกใจความหลัก"
  },
  {
    title: "ภารกิจ 3: เรียง Body Paragraph — Education",
    instruction: "จัด Topic Sentence, Supporting Details, Example และผลลัพธ์ให้ต่อเนื่อง",
    pieces: [
      { id: "result", text: "As a result, students who understand English can explore information beyond their local materials." },
      { id: "topic", text: "First, English gives students access to a wider range of learning resources." },
      { id: "example", text: "For example, many websites, books, and research articles are published in English." },
      { id: "link", text: "These resources can help them build knowledge and prepare for further study." }
    ],
    answer: ["topic", "example", "result", "link"],
    explanation: "ย่อหน้าเนื้อหาควรเริ่มด้วย Topic Sentence แล้วตามด้วยรายละเอียด ตัวอย่าง และผลที่เชื่อมกลับสู่ใจความ"
  },
  {
    title: "ภารกิจ 4: เรียง Body Paragraph — Careers",
    instruction: "ใช้คำเชื่อมแสดงการเพิ่มเหตุผล ตัวอย่าง และผลลัพธ์",
    pieces: [
      { id: "example", text: "For instance, an employee may need English to welcome international customers or join a global team." },
      { id: "topic", text: "Moreover, English can expand students' future career opportunities." },
      { id: "result", text: "Therefore, strong English skills may help people communicate at work and apply for more positions." },
      { id: "support", text: "Many employers value workers who can communicate with clients and colleagues from other countries." }
    ],
    answer: ["topic", "support", "example", "result"],
    explanation: "Moreover เพิ่มเหตุผล, For instance ยกตัวอย่าง และ Therefore นำไปสู่ผลลัพธ์"
  },
  {
    title: "ภารกิจ 5: เขียน Conclusion",
    instruction: "เริ่มด้วยคำเชื่อมสรุป ย้ำ Thesis ด้วยถ้อยคำใหม่ แล้วปิดท้ายด้วยความคิดส่งท้าย",
    pieces: [
      { id: "closing", text: "Although learning a language takes time, regular practice can help students use English with greater confidence." },
      { id: "summary", text: "In conclusion, English can support learning, create career opportunities, and connect people." },
      { id: "restatement", text: "By improving their English, students can prepare for a wider range of experiences in the future." }
    ],
    answer: ["summary", "restatement", "closing"],
    explanation: "Conclusion สรุปใจความหลักด้วยคำเชื่อม เช่น In conclusion แล้วทิ้งท้ายด้วยข้อคิดหรือมุมมองต่อไป"
  }
];

const board = document.getElementById("puzzle-board");
const levelProgress = document.getElementById("level-progress");
const scoreElement = document.getElementById("score");
const livesElement = document.getElementById("lives");
const levelLabel = document.getElementById("level-label");
const progressLabel = document.getElementById("progress-label");
const titleElement = document.getElementById("puzzle-title");
const instructionElement = document.getElementById("puzzle-instruction");
const feedbackElement = document.getElementById("feedback");
const modal = document.getElementById("result-modal");
const checkButton = document.getElementById("check-answer");
const resetButton = document.getElementById("reset-puzzle");
const restartButton = document.getElementById("restart-game");
const interactionHelp = document.getElementById("interaction-help");

let puzzleIndex = 0;
let score = 0;
let lives = 3;
let order = [];
let selectedIndex = null;
let draggedIndex = null;
let canSubmit = true;
let feedbackTimeout = null;

function renderPuzzle() {
  const puzzle = puzzles[puzzleIndex];
  levelProgress.textContent = `${puzzleIndex + 1} / ${puzzles.length}`;
  scoreElement.textContent = String(score);
  livesElement.textContent = "● ".repeat(lives).trim() || "—";
  livesElement.setAttribute("aria-label", `เหลือ ${lives} ครั้ง`);
  levelLabel.textContent = `PUZZLE ${String(puzzleIndex + 1).padStart(2, "0")}`;
  progressLabel.textContent = `ชิ้นส่วน ${order.length} ชิ้น`;
  titleElement.textContent = puzzle.title;
  instructionElement.textContent = puzzle.instruction;
  feedbackElement.textContent = "";
  feedbackElement.className = "feedback";
  canSubmit = true;
  checkButton.disabled = false;
  resetButton.disabled = false;
  selectedIndex = null;
  board.replaceChildren();

  order.forEach((pieceId, index) => {
    const piece = puzzle.pieces.find((item) => item.id === pieceId);
    const item = document.createElement("li");
    const button = document.createElement("button");
    button.className = "puzzle-piece";
    button.type = "button";
    button.draggable = true;
    button.dataset.index = String(index);
    button.setAttribute("aria-pressed", "false");
    button.setAttribute("aria-label", `ลำดับที่ ${index + 1}: ${piece.text}. แตะเพื่อเลือกและย้าย`);
    button.style.setProperty("--piece-color", ["#83709b", "#568197", "#bd8d4e", "#6a896f"][index % 4]);

    const number = document.createElement("span");
    number.className = "piece-number";
    number.textContent = String(index + 1);
    number.setAttribute("aria-hidden", "true");
    const text = document.createElement("span");
    text.className = "piece-text";
    text.textContent = piece.text;
    button.append(number, text);
    item.append(button);
    board.append(item);
  });
}

function movePiece(fromIndex, toIndex) {
  if (fromIndex === toIndex || fromIndex < 0 || toIndex < 0 || toIndex >= order.length) return;
  const [piece] = order.splice(fromIndex, 1);
  order.splice(toIndex, 0, piece);
  selectedIndex = null;
  renderPuzzle();
}

function handleBoardClick(event) {
  const piece = event.target.closest(".puzzle-piece");
  if (!piece || !board.contains(piece)) return;
  const index = Number(piece.dataset.index);

  if (selectedIndex === null) {
    selectedIndex = index;
    piece.classList.add("selected");
    piece.setAttribute("aria-pressed", "true");
    interactionHelp.textContent = `เลือกชิ้นส่วนลำดับที่ ${index + 1} แล้ว แตะชิ้นส่วนปลายทางเพื่อสลับตำแหน่ง`;
    return;
  }

  if (selectedIndex === index) {
    selectedIndex = null;
    renderPuzzle();
    return;
  }

  movePiece(selectedIndex, index);
  interactionHelp.textContent = "ลากชิ้นส่วนเพื่อเรียงใหม่ หรือแตะชิ้นส่วนหนึ่งแล้วแตะตำแหน่งที่ต้องการสลับไป";
}

function handleBoardKeydown(event) {
  const piece = event.target.closest(".puzzle-piece");
  if (!piece || !event.altKey || !["ArrowUp", "ArrowDown"].includes(event.key)) return;
  event.preventDefault();
  const fromIndex = Number(piece.dataset.index);
  const toIndex = fromIndex + (event.key === "ArrowUp" ? -1 : 1);
  movePiece(fromIndex, toIndex);
  board.querySelectorAll(".puzzle-piece")[Math.min(Math.max(toIndex, 0), order.length - 1)]?.focus();
}

function handleDragStart(event) {
  const piece = event.target.closest(".puzzle-piece");
  if (!piece) return;
  draggedIndex = Number(piece.dataset.index);
  piece.classList.add("dragging");
  event.dataTransfer.effectAllowed = "move";
  event.dataTransfer.setData("text/plain", String(draggedIndex));
}

function handleDragEnd(event) {
  event.target.closest(".puzzle-piece")?.classList.remove("dragging");
  board.querySelectorAll(".drop-target").forEach((piece) => piece.classList.remove("drop-target"));
  draggedIndex = null;
}

function handleDrop(event) {
  const target = event.target.closest(".puzzle-piece");
  if (!target || draggedIndex === null) return;
  event.preventDefault();
  movePiece(draggedIndex, Number(target.dataset.index));
}

function checkAnswer() {
  if (!canSubmit) return;
  const puzzle = puzzles[puzzleIndex];
  const correct = order.every((pieceId, index) => pieceId === puzzle.answer[index]);
  if (correct) {
    canSubmit = false;
    checkButton.disabled = true;
    resetButton.disabled = true;
    score += 20;
    scoreElement.textContent = String(score);
    feedbackElement.textContent = `ถูกต้อง! ${puzzle.explanation}`;
    feedbackElement.className = "feedback success";

    feedbackTimeout = window.setTimeout(() => {
      feedbackTimeout = null;
      puzzleIndex += 1;
      if (puzzleIndex === puzzles.length) {
        finishGame(true);
      } else {
        order = shuffledPieceIds(puzzles[puzzleIndex]);
        renderPuzzle();
      }
    }, 1100);
    return;
  }

  lives -= 1;
  livesElement.textContent = "● ".repeat(lives).trim() || "—";
  livesElement.setAttribute("aria-label", `เหลือ ${lives} ครั้ง`);
  feedbackElement.textContent = lives > 0
    ? "ยังเรียงไม่ตรง ลองดูคำเชื่อมและความสัมพันธ์ระหว่างประโยค แล้วจัดใหม่อีกครั้ง"
    : "โอกาสลองหมดแล้ว ลองเริ่มเกมใหม่และสังเกตหน้าที่ของแต่ละประโยค";
  feedbackElement.className = "feedback error";
  if (lives === 0) {
    canSubmit = false;
    checkButton.disabled = true;
    resetButton.disabled = true;
    feedbackTimeout = window.setTimeout(() => {
      feedbackTimeout = null;
      finishGame(false);
    }, 900);
  }
}

function shuffledPieceIds(puzzle) {
  const ids = puzzle.pieces.map((piece) => piece.id);
  for (let index = ids.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [ids[index], ids[swapIndex]] = [ids[swapIndex], ids[index]];
  }
  if (ids.every((pieceId, index) => pieceId === puzzle.answer[index])) {
    ids.push(ids.shift());
  }
  return ids;
}

function finishGame(won) {
  document.getElementById("result-icon").textContent = won ? "✍️" : "📝";
  document.getElementById("result-title").textContent = won ? "Essay สมบูรณ์แล้ว!" : "ฝึกต่อได้อีกครั้ง";
  document.getElementById("result-description").textContent = won
    ? "คุณจัดโครงสร้าง Introduction, Body Paragraphs และ Conclusion พร้อมใช้คำเชื่อมสร้างความต่อเนื่องได้ครบ"
    : "อ่านบทเรียนเรื่อง Essay Structure และ Transitional Phrases แล้วกลับมาลองเรียงชิ้นส่วนอีกครั้ง";
  document.getElementById("final-score").textContent = `คะแนน ${score} / 100 · เหลือโอกาส ${lives} ครั้ง`;
  document.getElementById("next-quiz").hidden = !won;
  document.getElementById("play-again").textContent = won ? "เล่นอีกครั้ง" : "เริ่มเกมใหม่";
  modal.classList.add("visible");
  modal.setAttribute("aria-hidden", "false");
  document.getElementById("play-again").focus();
}

function resetCurrentPuzzle() {
  order = shuffledPieceIds(puzzles[puzzleIndex]);
  renderPuzzle();
}

function restartGame() {
  if (feedbackTimeout !== null) {
    window.clearTimeout(feedbackTimeout);
    feedbackTimeout = null;
  }
  puzzleIndex = 0;
  score = 0;
  lives = 3;
  order = shuffledPieceIds(puzzles[puzzleIndex]);
  modal.classList.remove("visible");
  modal.setAttribute("aria-hidden", "true");
  renderPuzzle();
}

board.addEventListener("click", handleBoardClick);
board.addEventListener("keydown", handleBoardKeydown);
board.addEventListener("dragstart", handleDragStart);
board.addEventListener("dragend", handleDragEnd);
board.addEventListener("dragover", (event) => {
  const target = event.target.closest(".puzzle-piece");
  if (!target) return;
  event.preventDefault();
  target.classList.add("drop-target");
});
board.addEventListener("dragleave", (event) => {
  event.target.closest(".puzzle-piece")?.classList.remove("drop-target");
});
board.addEventListener("drop", handleDrop);
checkButton.addEventListener("click", checkAnswer);
resetButton.addEventListener("click", resetCurrentPuzzle);
restartButton.addEventListener("click", restartGame);
document.getElementById("play-again").addEventListener("click", restartGame);

restartGame();
