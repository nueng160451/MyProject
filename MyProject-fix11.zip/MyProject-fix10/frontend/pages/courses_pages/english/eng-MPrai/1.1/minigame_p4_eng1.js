"use strict";

const questions = [
  {
    category: "Subjunctive · recommendation",
    prompt: "คุณครูแนะนำให้นักเรียนอ่านหนังสือทุกวัน",
    hint: "recommend that + subject + base verb (ไม่เติม -s)",
    answer: ["The", "teacher", "recommended", "that", "students", "read", "every", "day", "."]
  },
  {
    category: "Subjunctive · be",
    prompt: "จำเป็นอย่างยิ่งที่ผู้สมัครทุกคนต้องมาตรงเวลา",
    hint: "It is essential that + subject + base verb; ใช้ be กับทุกประธาน",
    answer: ["It", "is", "essential", "that", "every", "applicant", "be", "on", "time", "."]
  },
  {
    category: "Subjunctive · insist",
    prompt: "โค้ชยืนยันว่าทีมต้องฝึกซ้อมหลังเลิกเรียน",
    hint: "insist that + subject + base verb",
    answer: ["The", "coach", "insisted", "that", "the", "team", "practice", "after", "school", "."]
  },
  {
    category: "Subjunctive · suggestion",
    prompt: "ฉันเสนอว่าเธอควรพักสักครู่",
    hint: "suggest that + subject + base verb (ไม่ใช้ suggests ตามประธาน she)",
    answer: ["I", "suggest", "that", "she", "take", "a", "short", "break", "."]
  },
  {
    category: "Subjunctive · hypothetical",
    prompt: "ถ้าฉันเป็นคุณ ฉันจะทบทวนรายงาน",
    hint: "สถานการณ์สมมติที่ไม่เป็นจริงในปัจจุบัน ใช้ If I were you, ...",
    answer: ["If", "I", "were", "you", ",", "I", "would", "review", "the", "report", "."]
  },
  {
    category: "Participle · present participle",
    prompt: "นักเรียนที่กำลังรออยู่ข้างนอกกำลังทำข้อสอบ",
    hint: "Present participle (V-ing) ใช้ขยาย students ว่ากำลังรออยู่",
    answer: ["The", "students", "waiting", "outside", "are", "taking", "the", "exam", "."]
  },
  {
    category: "Participle · past participle",
    prompt: "เมื่อช็อกจากประกาศ มายาจึงโทรหาครอบครัว",
    hint: "Past participle phrase (shocked) บอกสภาพของ Maya",
    answer: ["Shocked", "by", "the", "announcement", ",", "Maya", "called", "her", "family", "."]
  },
  {
    category: "Participle · reduced relative clause",
    prompt: "หนังสือที่เขียนโดยออร์เวลล์ถูกนำมาเรียนในชั้นเรียน",
    hint: "Past participle (written) ย่อจาก which was written",
    answer: ["The", "book", "written", "by", "Orwell", "is", "studied", "in", "class", "."]
  },
  {
    category: "Participle · present participle clause",
    prompt: "ขณะที่เดินชมพิพิธภัณฑ์ พวกเราเห็นแผนที่โบราณ",
    hint: "Present participle clause (Walking...) มีประธานเดียวกับประโยคหลัก คือ we",
    answer: ["Walking", "through", "the", "museum", ",", "we", "saw", "an", "ancient", "map", "."]
  },
  {
    category: "Participle · perfect participle",
    prompt: "หลังจากทำการทดลองเสร็จแล้ว นักวิจัยจึงบันทึกผล",
    hint: "Having + V.3 ใช้บอกว่าเหตุการณ์นี้เสร็จก่อนกริยาหลัก",
    answer: ["Having", "finished", "the", "experiment", ",", "the", "researchers", "recorded", "the", "results", "."]
  }
];

const MAX_HEALTH = 3;
const RETRY_DELAY = 1600;
const NEXT_QUESTION_DELAY = 1100;

let currentQuestion = 0;
let score = 0;
let health = MAX_HEALTH;
let selectedTokenIds = [];
let isLocked = false;
let transitionTimeout = null;
let ignoreClickUntil = 0;

const elements = {
  progress: document.getElementById("questionProgress"),
  score: document.getElementById("scoreText"),
  health: document.getElementById("healthText"),
  tag: document.getElementById("grammarTag"),
  number: document.getElementById("questionNumber"),
  title: document.getElementById("challengeTitle"),
  prompt: document.getElementById("thaiPrompt"),
  hint: document.getElementById("grammarHint"),
  answerArea: document.getElementById("answerArea"),
  wordBank: document.getElementById("wordBank"),
  feedback: document.getElementById("feedbackBanner"),
  check: document.getElementById("checkButton"),
  undo: document.getElementById("undoButton"),
  clear: document.getElementById("clearButton"),
  restart: document.getElementById("restartButton"),
  modal: document.getElementById("resultModal"),
  modalIcon: document.getElementById("modalIcon"),
  modalTitle: document.getElementById("modalTitle"),
  modalDescription: document.getElementById("modalDesc"),
  modalScore: document.getElementById("modalScoreText"),
  playAgain: document.getElementById("playAgainButton"),
  nextPage: document.getElementById("nextPageButton")
};

function shuffle(items) {
  const shuffled = items.slice();
  for (let index = shuffled.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [shuffled[index], shuffled[swapIndex]] = [shuffled[swapIndex], shuffled[index]];
  }
  return shuffled;
}

function renderHealth() {
  elements.health.textContent = `${"♥ ".repeat(health)}${"♡ ".repeat(MAX_HEALTH - health)}`.trim();
  elements.health.setAttribute("aria-label", `พลังใจ ${health} จาก ${MAX_HEALTH} ดวง`);
}

function renderToken(token, location) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = `word-token ${location === "answer" ? "placed-token" : ""}`;
  button.textContent = token.text;
  button.draggable = location === "bank" && !isLocked;
  button.disabled = isLocked;
  button.dataset.tokenId = String(token.id);

  if (location === "bank") {
    button.addEventListener("click", () => {
      if (Date.now() < ignoreClickUntil || isLocked) return;
      selectedTokenIds.push(token.id);
      renderSentence();
    });
    button.addEventListener("dragstart", (event) => {
      event.dataTransfer.setData("text/plain", String(token.id));
      event.dataTransfer.effectAllowed = "move";
    });
    button.addEventListener("dragend", () => {
      ignoreClickUntil = Date.now() + 250;
    });
  } else {
    button.addEventListener("click", () => {
      if (isLocked) return;
      selectedTokenIds = selectedTokenIds.filter((id) => id !== token.id);
      renderSentence();
    });
  }
  return button;
}

function renderSentence() {
  const question = questions[currentQuestion];
  const tokens = question.answer.map((text, id) => ({ id, text }));
  const selectedIds = new Set(selectedTokenIds);
  elements.answerArea.replaceChildren();
  elements.wordBank.replaceChildren();

  selectedTokenIds.forEach((id) => {
    elements.answerArea.append(renderToken(tokens[id], "answer"));
  });
  shuffle(tokens.filter((token) => !selectedIds.has(token.id)))
    .forEach((token) => elements.wordBank.append(renderToken(token, "bank")));

  elements.answerArea.classList.toggle("has-tokens", selectedTokenIds.length > 0);
  elements.check.disabled = isLocked;
  elements.undo.disabled = isLocked || selectedTokenIds.length === 0;
  elements.clear.disabled = isLocked || selectedTokenIds.length === 0;
}

function renderQuestion() {
  const question = questions[currentQuestion];
  isLocked = false;
  selectedTokenIds = [];
  elements.progress.textContent = `${currentQuestion + 1} / ${questions.length}`;
  elements.score.textContent = String(score);
  elements.tag.textContent = question.category;
  elements.number.textContent = `ประโยค ${currentQuestion + 1}`;
  elements.title.textContent = "สร้างประโยคจากชิ้นส่วนคำ";
  elements.prompt.textContent = question.prompt;
  elements.hint.textContent = question.hint;
  elements.feedback.textContent = "";
  elements.feedback.className = "feedback";
  renderSentence();
}

function sentenceFromTokens(tokenTexts) {
  return tokenTexts.reduce((sentence, token) => {
    if ([",", ".", "?", "!"].includes(token)) return `${sentence.trimEnd()}${token}`;
    return sentence ? `${sentence} ${token}` : token;
  }, "");
}

function checkSentence() {
  if (isLocked) return;
  if (selectedTokenIds.length === 0) {
    elements.feedback.textContent = "เลือกคำจากคลังก่อน แล้วเรียงลงในพื้นที่สร้างประโยค";
    elements.feedback.className = "feedback";
    return;
  }

  const question = questions[currentQuestion];
  const tokens = question.answer.map((text, id) => ({ id, text }));
  const actual = selectedTokenIds.map((id) => tokens[id].text);
  const isCorrect = actual.length === question.answer.length
    && actual.every((word, index) => word === question.answer[index]);

  if (isCorrect) {
    isLocked = true;
    score += 10;
    elements.score.textContent = String(score);
    elements.feedback.textContent = "เยี่ยมมาก! เรียงประโยคได้ถูกต้อง";
    elements.feedback.className = "feedback success";
    renderSentence();
    transitionTimeout = window.setTimeout(() => {
      transitionTimeout = null;
      currentQuestion += 1;
      if (currentQuestion < questions.length) {
        renderQuestion();
      } else {
        finishGame(true);
      }
    }, NEXT_QUESTION_DELAY);
    return;
  }

  health -= 1;
  renderHealth();
  elements.feedback.textContent = `ลำดับยังไม่ถูก ลองอีกครั้ง: ${sentenceFromTokens(question.answer)}`;
  elements.feedback.className = "feedback error";

  if (health === 0) {
    isLocked = true;
    renderSentence();
    transitionTimeout = window.setTimeout(() => {
      transitionTimeout = null;
      finishGame(false);
    }, RETRY_DELAY);
    return;
  }

  isLocked = true;
  renderSentence();
  transitionTimeout = window.setTimeout(() => {
    transitionTimeout = null;
    isLocked = false;
    selectedTokenIds = [];
    elements.feedback.textContent = "ลองประกอบประโยคอีกครั้งจากคลังคำ";
    elements.feedback.className = "feedback";
    renderSentence();
  }, RETRY_DELAY);
}

function finishGame(won) {
  isLocked = true;
  elements.modal.classList.add("active");
  elements.modal.setAttribute("aria-hidden", "false");
  elements.modalIcon.textContent = won ? "🏆" : "🧱";
  elements.modalTitle.textContent = won ? "สร้างประโยคสำเร็จ!" : "พลังใจหมดแล้ว";
  elements.modalDescription.textContent = won
    ? "คุณประกอบประโยค Subjunctive และ Participle ครบทุกข้อแล้ว ไปทำแบบทดสอบต่อได้เลย"
    : "ทบทวนรูปประโยคและลองสร้างประโยคใหม่อีกครั้ง";
  elements.modalScore.textContent = `คะแนนรวม ${score} / ${questions.length * 10} · พลังใจเหลือ ${health} ดวง`;
  elements.nextPage.style.display = won ? "inline-flex" : "none";
}

function restartGame() {
  if (transitionTimeout !== null) {
    window.clearTimeout(transitionTimeout);
    transitionTimeout = null;
  }
  currentQuestion = 0;
  score = 0;
  health = MAX_HEALTH;
  selectedTokenIds = [];
  isLocked = false;
  elements.modal.classList.remove("active");
  elements.modal.setAttribute("aria-hidden", "true");
  renderHealth();
  renderQuestion();
}

elements.answerArea.addEventListener("dragover", (event) => {
  event.preventDefault();
  event.dataTransfer.dropEffect = "move";
});
elements.answerArea.addEventListener("drop", (event) => {
  event.preventDefault();
  if (isLocked) return;
  const tokenId = Number(event.dataTransfer.getData("text/plain"));
  const question = questions[currentQuestion];
  if (Number.isInteger(tokenId) && tokenId >= 0 && tokenId < question.answer.length
      && !selectedTokenIds.includes(tokenId)) {
    selectedTokenIds.push(tokenId);
    renderSentence();
  }
});
elements.check.addEventListener("click", checkSentence);
elements.undo.addEventListener("click", () => {
  selectedTokenIds.pop();
  renderSentence();
});
elements.clear.addEventListener("click", () => {
  selectedTokenIds = [];
  renderSentence();
});
elements.restart.addEventListener("click", restartGame);
elements.playAgain.addEventListener("click", restartGame);

renderHealth();
renderQuestion();
