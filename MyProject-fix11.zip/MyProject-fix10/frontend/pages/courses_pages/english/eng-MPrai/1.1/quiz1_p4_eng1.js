"use strict";

const questions = [
  {
    question: "Complete: The teacher recommended that students ___ every day.",
    options: ["read", "reads", "reading"],
    answer: 0
  },
  {
    question: "Choose the correct mandative subjunctive structure.",
    options: [
      "They insisted that he be present.",
      "They insisted that he is present.",
      "They insisted that he being present."
    ],
    answer: 0
  },
  {
    question: "Complete: It is essential that every applicant ___ on time.",
    options: ["be", "is", "was"],
    answer: 0
  },
  {
    question: "Complete: I suggest that she ___ a short break.",
    options: ["takes", "take", "took"],
    answer: 1
  },
  {
    question: "Which verb form follows recommend that in the mandative subjunctive?",
    options: ["The base form of the verb", "The verb with -s", "The past continuous form"],
    answer: 0
  },
  {
    question: "Complete the hypothetical advice: If I ___ you, I would review the report.",
    options: ["am", "were", "will be"],
    answer: 1
  },
  {
    question: "In “The students waiting outside are taking the exam,” what does waiting do?",
    options: ["It is a present participle describing the students.", "It is a past participle describing the exam.", "It is the main verb of the sentence."],
    answer: 0
  },
  {
    question: "Choose the past participle phrase.",
    options: ["Shocked by the announcement", "Walking through the museum", "To shock the audience"],
    answer: 0
  },
  {
    question: "Complete: The book ___ by Orwell is studied in class.",
    options: ["writing", "written", "writes"],
    answer: 1
  },
  {
    question: "Choose the correct participle clause: ___ through the museum, we saw an ancient map.",
    options: ["Walking", "Walked", "To walking"],
    answer: 0
  },
  {
    question: "Complete: ___ finished the experiment, the researchers recorded the results.",
    options: ["Having", "Has", "Were"],
    answer: 0
  },
  {
    question: "What does Having + past participle usually show in a participle clause?",
    options: [
      "The participle action happened before the main action.",
      "The participle action will happen after the main action.",
      "The participle action happens every day."
    ],
    answer: 0
  },
  {
    question: "Which sentence uses a present participle clause?",
    options: [
      "Walking home, Nina called her friend.",
      "Written in 1925, the book is famous.",
      "The letter was written yesterday."
    ],
    answer: 0
  },
  {
    question: "In “Shocked by the news, Maya called her family,” who was shocked?",
    options: ["Maya", "Her family", "The news"],
    answer: 0
  },
  {
    question: "Choose the correctly ordered sentence.",
    options: [
      "The coach insisted that the team practice after school.",
      "The coach insisted that the team practices after school.",
      "The coach insisted that practice the team after school."
    ],
    answer: 0
  }
];

let currentQuestion = 0;
let score = 0;
let canAnswer = true;
let nextQuestionTimeout = null;

const questionNumberEl = document.getElementById("question-number");
const scoreCountEl = document.getElementById("score-count");
const questionTextEl = document.getElementById("question-text");
const optionsContainerEl = document.getElementById("options-container");
const quizBox = document.getElementById("quiz-box");
const resultBox = document.getElementById("result-box");
const finalScoreEl = document.getElementById("final-score");

function loadQuestion() {
  canAnswer = true;
  const question = questions[currentQuestion];
  questionNumberEl.textContent = `ข้อที่ ${currentQuestion + 1} / ${questions.length}`;
  scoreCountEl.textContent = `คะแนน: ${score}`;
  questionTextEl.textContent = question.question;
  optionsContainerEl.replaceChildren();

  question.options.forEach((option, index) => {
    const button = document.createElement("button");
    button.className = "option-btn";
    button.type = "button";
    button.textContent = option;
    button.addEventListener("click", () => selectOption(index, button));
    optionsContainerEl.append(button);
  });
}

function selectOption(selectedIndex, selectedButton) {
  if (!canAnswer) return;
  canAnswer = false;
  const correctIndex = questions[currentQuestion].answer;
  const optionButtons = optionsContainerEl.querySelectorAll(".option-btn");

  if (selectedIndex === correctIndex) {
    selectedButton.classList.add("correct");
    score += 1;
    scoreCountEl.textContent = `คะแนน: ${score}`;
  } else {
    selectedButton.classList.add("incorrect");
    optionButtons[correctIndex].classList.add("correct");
  }

  optionButtons.forEach((button) => {
    button.disabled = true;
  });

  nextQuestionTimeout = window.setTimeout(() => {
    nextQuestionTimeout = null;
    currentQuestion += 1;
    if (currentQuestion < questions.length) {
      loadQuestion();
    } else {
      showResult();
    }
  }, 1000);
}

function showResult() {
  quizBox.classList.add("hidden");
  resultBox.classList.remove("hidden");
  finalScoreEl.textContent = `คุณได้คะแนน ${score} จาก ${questions.length} คะแนน`;
}

function restartQuiz() {
  if (nextQuestionTimeout !== null) {
    window.clearTimeout(nextQuestionTimeout);
    nextQuestionTimeout = null;
  }
  currentQuestion = 0;
  score = 0;
  resultBox.classList.add("hidden");
  quizBox.classList.remove("hidden");
  loadQuestion();
}

loadQuestion();
