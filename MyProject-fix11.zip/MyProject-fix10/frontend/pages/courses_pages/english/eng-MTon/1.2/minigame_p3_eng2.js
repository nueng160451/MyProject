const NEXT_PAGE_URL = "quiz1_p3_eng2.html";

const casesData = [
  {
    caseId: 1,
    witnessName: "พยาน: Lady Clara",
    directSpeech: '"I left my diamond ring on the table 5 minutes ago."',
    svgIllustration: `<svg viewBox="0 0 400 170" width="100%" height="100%">
      <rect width="400" height="170" fill="#291D18"/>
      <rect x="20" y="20" width="360" height="130" fill="#422A1D" stroke="#D4AF37" stroke-width="2" rx="8"/>
      <rect x="140" y="90" width="120" height="50" fill="#653E2A" rx="4"/>
      <ellipse cx="200" cy="110" rx="14" ry="8" fill="#D4AF37"/>
      <circle cx="80" cy="75" r="18" fill="#FDE68A"/>
      <path d="M 60 130 L 100 130 L 95 95 L 65 95 Z" fill="#9333EA"/>
    </svg>`,
    step1: {
      question: "Lady Clara said that she _______ her diamond ring on the table 5 minutes before.",
      options: [
        { text: "had left", isCorrect: true },
        { text: "has left", isCorrect: false },
        { text: "was leaving", isCorrect: false }
      ],
      explanation: "เมื่อรายงาน left (Past Simple) ย้อนจากคำพูดเดิม มักเปลี่ยนเป็น had left (Past Perfect); ago เปลี่ยนเป็น before"
    },
    step2: {
      evidence: "แหวนยังอยู่บนโต๊ะ และมีพยานเห็น Clara วางแหวนไว้เมื่อไม่กี่นาทีก่อน",
      question: "Conclusion: Clara _______ have left the ring on the table.",
      options: [
        { text: "must", isCorrect: true },
        { text: "might", isCorrect: false },
        { text: "can't", isCorrect: false }
      ],
      explanation: "หลักฐานตรงกันอย่างชัดเจน จึงใช้ must have + V.3 เพื่อแสดงข้อสรุปที่มั่นใจสูง"
    }
  },
  {
    caseId: 2,
    witnessName: "พยาน: The Butler",
    directSpeech: '"I am walking in the garden right now."',
    svgIllustration: `<svg viewBox="0 0 400 170" width="100%" height="100%">
      <rect width="400" height="170" fill="#1C1917"/>
      <rect x="20" y="20" width="360" height="130" fill="#3A271D" stroke="#D4AF37" stroke-width="2" rx="8"/>
      <circle cx="320" cy="75" r="18" fill="#FDE68A"/>
      <path d="M 300 130 L 340 130 L 335 95 L 305 95 Z" fill="#1E293B"/>
      <ellipse cx="200" cy="110" rx="20" ry="10" fill="#78350F"/>
    </svg>`,
    step1: {
      question: "The butler said that he _______ in the garden at that moment.",
      options: [
        { text: "is walking", isCorrect: false },
        { text: "was walking", isCorrect: true },
        { text: "had walked", isCorrect: false }
      ],
      explanation: "Present Continuous am walking เปลี่ยนเป็น Past Continuous was walking; right now เปลี่ยนเป็น at that moment"
    },
    step2: {
      evidence: "รองเท้าของพ่อบ้านเปื้อนโคลนเปียก และมีรอยเท้าจากสวนมาถึงประตู",
      question: "Conclusion: The butler _______ have been outside in the garden.",
      options: [
        { text: "can't", isCorrect: false },
        { text: "might", isCorrect: false },
        { text: "must", isCorrect: true }
      ],
      explanation: "รอยเท้าและโคลนเป็นหลักฐานหนักแน่น ใช้ must have been เพื่ออนุมานอดีตอย่างมั่นใจ"
    }
  },
  {
    caseId: 3,
    witnessName: "พยาน: The Guards",
    directSpeech: '"We were sleeping when the alarm sounded."',
    svgIllustration: `<svg viewBox="0 0 400 170" width="100%" height="100%">
      <rect width="400" height="170" fill="#18181B"/>
      <rect x="20" y="20" width="360" height="130" fill="#27272A" stroke="#D4AF37" stroke-width="2" rx="8"/>
      <path d="M 190 120 L 210 120 L 215 140 L 185 140 Z" fill="#D97706"/>
      <text x="100" y="70" fill="#FACC15" font-weight="bold" font-size="20">Zzz...</text>
    </svg>`,
    step1: {
      question: "The guards admitted that they _______ sleeping when the alarm sounded.",
      options: [
        { text: "had been", isCorrect: true },
        { text: "are", isCorrect: false },
        { text: "have been", isCorrect: false }
      ],
      explanation: "Past Continuous were sleeping เปลี่ยนเป็น Past Perfect Continuous had been sleeping ใน reported speech"
    },
    step2: {
      evidence: "บันทึกกล้องและพยานยืนยันว่าทหารยามหลับอยู่ในห้องอื่นขณะสัญญาณเตือนดัง",
      question: "Conclusion: The guards _______ have seen the thief during the alarm.",
      options: [
        { text: "must", isCorrect: false },
        { text: "might", isCorrect: false },
        { text: "can't", isCorrect: true }
      ],
      explanation: "เมื่อยามหลับอยู่ในอีกห้อง จึงแทบเป็นไปไม่ได้ที่จะเห็นคนร้าย ใช้ can't have + V.3"
    }
  },
  {
    caseId: 4,
    witnessName: "พยาน: Detective Holmes",
    directSpeech: '"The suspect will leave the town tomorrow."',
    svgIllustration: `<svg viewBox="0 0 400 170" width="100%" height="100%">
      <rect width="400" height="170" fill="#1C1917"/>
      <rect x="20" y="20" width="360" height="130" fill="#44403C" stroke="#D4AF37" stroke-width="2" rx="8"/>
      <rect x="170" y="90" width="60" height="40" fill="#FDE68A" rx="4"/>
      <circle cx="200" cy="70" r="16" fill="none" stroke="#D4AF37" stroke-width="4"/>
    </svg>`,
    step1: {
      question: "Holmes reported that the suspect _______ leave the town the next day.",
      options: [
        { text: "will", isCorrect: false },
        { text: "would", isCorrect: true },
        { text: "can", isCorrect: false }
      ],
      explanation: "will เปลี่ยนเป็น would ใน reported speech; tomorrow เปลี่ยนเป็น the next day"
    },
    step2: {
      evidence: "พบตั๋วรถไฟที่จองไว้ แต่ยังไม่ทราบว่าใครเป็นผู้โดยสาร",
      question: "Conclusion: The suspect _______ be planning to travel by train.",
      options: [
        { text: "might", isCorrect: true },
        { text: "must", isCorrect: false },
        { text: "can't", isCorrect: false }
      ],
      explanation: "ตั๋วรถไฟเป็นเพียงหลักฐานที่เป็นไปได้แต่ยังไม่ยืนยันตัวผู้โดยสาร จึงใช้ might"
    }
  }
];

let currentCaseIdx = 0;
let currentStep = 1;
let score = 0;
let isAnswerLocked = false;
let nextStepTimeout = null;

function initGame() {
  if (nextStepTimeout !== null) {
    window.clearTimeout(nextStepTimeout);
    nextStepTimeout = null;
  }

  currentCaseIdx = 0;
  currentStep = 1;
  score = 0;
  isAnswerLocked = false;
  document.getElementById('resultModal').classList.remove('active');
  loadCase();
}

function loadCase() {
  const currentCase = casesData[currentCaseIdx];
  document.getElementById('caseProgress').innerText =
    `${currentCaseIdx + 1} / ${casesData.length}`;
  document.getElementById('scoreText').innerText = `${score} คะแนน`;
  document.getElementById('courtIllustration').innerHTML = currentCase.svgIllustration;
  document.getElementById('witnessName').innerText = `👤 ${currentCase.witnessName}`;
  document.getElementById('directSpeechText').innerText = currentCase.directSpeech;

  document.getElementById('step1Container').classList.toggle('hidden', currentStep !== 1);
  document.getElementById('step2Container').classList.toggle('hidden', currentStep !== 2);
  document.getElementById('tabStep1').classList.toggle('active', currentStep === 1);
  document.getElementById('tabStep2').classList.toggle('active', currentStep === 2);

  const step = currentStep === 1 ? currentCase.step1 : currentCase.step2;
  const questionElement = document.getElementById(
    currentStep === 1 ? 'step1Question' : 'step2Question'
  );
  questionElement.innerText = step.question;

  const evidenceBox = document.getElementById('evidenceBox');
  if (currentStep === 2) {
    evidenceBox.innerText = `🔎 หลักฐานในที่เกิดเหตุ: ${step.evidence}`;
  }

  const optionsGrid = document.getElementById(
    currentStep === 1 ? 'step1Options' : 'step2Options'
  );
  optionsGrid.innerHTML = '';
  const feedbackBanner = document.getElementById('feedbackBanner');
  feedbackBanner.innerText = '';
  feedbackBanner.className = 'feedback-banner';
  isAnswerLocked = false;

  step.options.forEach(option => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'option-btn';
    button.innerText = option.text;
    button.addEventListener('click', () => handleSelectOption(button, option, step, optionsGrid));
    optionsGrid.appendChild(button);
  });
}

function handleSelectOption(selectedButton, option, step, optionsGrid) {
  if (isAnswerLocked) return;
  isAnswerLocked = true;

  const feedbackBanner = document.getElementById('feedbackBanner');
  const optionButtons = optionsGrid.querySelectorAll('.option-btn');
  optionButtons.forEach(button => {
    button.disabled = true;
  });

  if (option.isCorrect) {
    selectedButton.classList.add('correct');
    score += 10;
    document.getElementById('scoreText').innerText = `${score} คะแนน`;
    feedbackBanner.innerText = `✨ ถูกต้อง! ${step.explanation}`;
    feedbackBanner.className = 'feedback-banner correct';
  } else {
    selectedButton.classList.add('wrong');
    feedbackBanner.innerText = `❌ ยังไม่ถูกต้อง! ${step.explanation}`;
    feedbackBanner.className = 'feedback-banner wrong';
    const correctOption = step.options.find(item => item.isCorrect);
    const correctButton = Array.from(optionButtons).find(button =>
      button.innerText === correctOption.text
    );
    if (correctButton) correctButton.classList.add('correct');
  }

  nextStepTimeout = window.setTimeout(() => {
    nextStepTimeout = null;
    if (currentStep === 1) {
      currentStep = 2;
    } else {
      currentCaseIdx++;
      currentStep = 1;
    }

    if (currentCaseIdx < casesData.length) {
      loadCase();
    } else {
      showCompletionModal();
    }
  }, 1600);
}

function resetGame() {
  initGame();
}

function showCompletionModal() {
  const maxScore = casesData.length * 20;
  document.getElementById('modalScoreText').innerText =
    `คะแนนรวมทั้งหมด: ${score} / ${maxScore} คะแนน`;
  document.getElementById('modalStars').innerText =
    score === maxScore ? '⭐⭐⭐' : score >= maxScore * 0.6 ? '⭐⭐' : '⭐';
  document.getElementById('modalDesc').innerText =
    `ตอบถูก ${score / 10} จาก ${maxScore / 10} ข้อ`;
  document.getElementById('resultModal').classList.add('active');
}

function goToNextPage() {
  const maxScore = casesData.length * 20;
  if (window.parent && window.parent !== window) {
    window.parent.postMessage({
      type: 'LESSON_COMPLETE',
      action: 'NEXT_LESSON',
      lessonId: 'english-p3-reported-speech-deduction',
      status: 'PASS',
      score,
      maxScore
    }, '*');
  }

  window.location.href = NEXT_PAGE_URL;
}

window.onload = initGame;
