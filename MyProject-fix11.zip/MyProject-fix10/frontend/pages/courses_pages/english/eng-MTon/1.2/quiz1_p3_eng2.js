const questions = [
    {
        question: "Choose the correct reported sentence: Lady Clara said, 'I left my ring.'",
        options: [
            "She said that she had left her ring.",
            "She said that she has left her ring.",
            "She said that she was leaving her ring."
        ],
        answer: 0
    },
    {
        question: "In reported speech, what does 'ago' often change to?",
        options: ["before", "tomorrow", "right now"],
        answer: 0
    },
    {
        question: "Choose the correct reported sentence: 'I am walking in the garden right now.'",
        options: [
            "He said that he is walking in the garden right now.",
            "He said that he was walking in the garden at that moment.",
            "He said that he had walked in the garden tomorrow."
        ],
        answer: 1
    },
    {
        question: "What does Present Continuous usually change to in reported speech?",
        options: ["Past Continuous", "Present Perfect", "Future Simple"],
        answer: 0
    },
    {
        question: "Choose the correct reported sentence: 'We were sleeping when the alarm sounded.'",
        options: [
            "They admitted that they had been sleeping when the alarm sounded.",
            "They admitted that they are sleeping when the alarm sounded.",
            "They admitted that they have slept when the alarm sounded."
        ],
        answer: 0
    },
    {
        question: "What does Past Continuous usually change to in reported speech?",
        options: ["Past Perfect Continuous", "Present Continuous", "Past Simple"],
        answer: 0
    },
    {
        question: "Choose the correct report: 'The suspect will leave tomorrow.'",
        options: [
            "Holmes reported that the suspect would leave the next day.",
            "Holmes reported that the suspect will leave tomorrow.",
            "Holmes reported that the suspect had left yesterday."
        ],
        answer: 0
    },
    {
        question: "In reported speech, 'will' usually changes to ___.",
        options: ["would", "had", "was"],
        answer: 0
    },
    {
        question: "Which modal shows a strong, evidence-based conclusion about the present?",
        options: ["must", "might", "can't"],
        answer: 0
    },
    {
        question: "The evidence is possible but not certain. Which modal is appropriate?",
        options: ["must", "might", "can't"],
        answer: 1
    },
    {
        question: "The guards were asleep in another room. They ___ have seen the thief.",
        options: ["must", "might", "can't"],
        answer: 2
    },
    {
        question: "Which structure is used to make a deduction about a past event?",
        options: ["modal + have + V.3", "modal + V-ing", "have + V-ing"],
        answer: 0
    },
    {
        question: "There are clear wet footprints from the garden. The butler ___ have been outside.",
        options: ["must", "might", "can't"],
        answer: 0
    },
    {
        question: "An unmarked train ticket was found, but its owner is unknown. The suspect ___ be planning to travel by train.",
        options: ["must", "might", "can't"],
        answer: 1
    },
    {
        question: "Which statement correctly describes the modal verbs in this lesson?",
        options: [
            "must = strong certainty; might = possibility; can't = strong impossibility",
            "must = possibility; might = impossibility; can't = certainty",
            "must, might, and can't all show the same level of certainty"
        ],
        answer: 0
    }
];

let currentQuestion = 0;
let score = 0;
let canAnswer = true;
let nextQuestionTimeout = null;

const questionNumberEl = document.getElementById('question-number');
const scoreCountEl = document.getElementById('score-count');
const questionTextEl = document.getElementById('question-text');
const optionsContainerEl = document.getElementById('options-container');
const quizBox = document.getElementById('quiz-box');
const resultBox = document.getElementById('result-box');
const finalScoreEl = document.getElementById('final-score');

loadQuestion();

function loadQuestion() {
    canAnswer = true;
    const question = questions[currentQuestion];
    questionNumberEl.innerText = `ข้อที่ ${currentQuestion + 1} / ${questions.length}`;
    scoreCountEl.innerText = `คะแนน: ${score}`;
    questionTextEl.innerText = question.question;
    optionsContainerEl.innerHTML = '';

    question.options.forEach((option, index) => {
        const button = document.createElement('button');
        button.classList.add('option-btn');
        button.type = 'button';
        button.innerText = option;
        button.addEventListener('click', () => selectOption(index, button));
        optionsContainerEl.appendChild(button);
    });
}

function selectOption(selectedIndex, selectedButton) {
    if (!canAnswer) return;
    canAnswer = false;

    const correctIndex = questions[currentQuestion].answer;
    const optionButtons = optionsContainerEl.querySelectorAll('.option-btn');

    if (selectedIndex === correctIndex) {
        selectedButton.classList.add('correct');
        score++;
        scoreCountEl.innerText = `คะแนน: ${score}`;
    } else {
        selectedButton.classList.add('incorrect');
        optionButtons[correctIndex].classList.add('correct');
    }

    optionButtons.forEach(button => {
        button.disabled = true;
    });

    nextQuestionTimeout = window.setTimeout(() => {
        nextQuestionTimeout = null;
        currentQuestion++;
        if (currentQuestion < questions.length) {
            loadQuestion();
        } else {
            showResult();
        }
    }, 1000);
}

function showResult() {
    quizBox.classList.add('hidden');
    resultBox.classList.remove('hidden');
    finalScoreEl.innerText = `คุณได้คะแนน ${score} จาก ${questions.length} คะแนน`;
}

function restartQuiz() {
    if (nextQuestionTimeout !== null) {
        window.clearTimeout(nextQuestionTimeout);
        nextQuestionTimeout = null;
    }
    currentQuestion = 0;
    score = 0;
    resultBox.classList.add('hidden');
    quizBox.classList.remove('hidden');
    loadQuestion();
}
