"use strict";

const questions = [
  {
    question: "ข้อใดเรียงโครงสร้างย่อหน้าแสดงความคิดเห็นได้เหมาะสม?",
    options: [
      "Opinion → Reason → Example → Conclusion",
      "Example → Conclusion → Opinion → Reason",
      "Conclusion → Example → Reason → Opinion"
    ],
    answer: 0
  },
  {
    question: "ประโยคใดเป็นการเสนอความคิดเห็น (Giving an opinion)?",
    options: ["In my opinion, students need time to rest.", "Close the door, please.", "Where is your classroom?"],
    answer: 0
  },
  {
    question: "ประโยคใดเหมาะใช้บอกเหตุผลสนับสนุนความคิดเห็น?",
    options: ["One reason is that students need enough sleep.", "What time is it?", "See you tomorrow."],
    answer: 0
  },
  {
    question: "วลี For example, ใช้ทำหน้าที่ใดในย่อหน้า?",
    options: ["เริ่มยกตัวอย่าง", "บอกว่าไม่เห็นด้วย", "กล่าวทักทาย"],
    answer: 0
  },
  {
    question: "เพื่อนพูดว่า “School uniforms are useful.” คุณเห็นด้วย ควรตอบอย่างไร?",
    options: ["I agree. They can help students feel like a team.", "That is a silly idea.", "You must stop talking."],
    answer: 0
  },
  {
    question: "คุณไม่เห็นด้วยกับเพื่อน แต่ต้องการตอบอย่างสุภาพ ควรพูดว่า...",
    options: [
      "I see your point, but I have a different opinion.",
      "You are wrong and should be quiet.",
      "I do not want to listen to you."
    ],
    answer: 0
  },
  {
    question: "ข้อใดเป็นประโยคสรุปความคิดเห็นที่เหมาะสม?",
    options: [
      "For these reasons, I believe students need a balanced amount of homework.",
      "For example, students need a balanced amount of homework.",
      "One reason is homework."
    ],
    answer: 0
  },
  {
    question: "หัวข้อคือ “Should homework be reduced?” ข้อใดเป็น Topic sentence ที่แสดงจุดยืนชัดเจน?",
    options: [
      "I agree that students should have less homework.",
      "Homework is a word with eight letters.",
      "For example, students have books."
    ],
    answer: 0
  },
  {
    question: "จุดประสงค์หลักของประโยค Reason คืออะไร?",
    options: ["อธิบายว่าทำไมเราจึงมีความคิดเห็นเช่นนั้น", "เปลี่ยนหัวข้อโดยไม่เกี่ยวข้อง", "กล่าวลาผู้อ่าน"],
    answer: 0
  },
  {
    question: "ข้อใดเป็นตัวอย่างที่สนับสนุนเหตุผลเรื่องการพักผ่อนหลังเลิกเรียน?",
    options: [
      "For example, free time lets students play sports or spend time with family.",
      "For example, homework is a school task.",
      "For example, students should agree with everyone."
    ],
    answer: 0
  },
  {
    question: "เลือกคำเชื่อมที่เหมาะสำหรับเริ่มประโยคสรุป",
    options: ["For these reasons,", "For example,", "At the same time,"],
    answer: 0
  },
  {
    question: "ถ้าคิดว่าเกมช่วยฝึกการแก้ปัญหา ส่วนใดเป็น Reason ที่เหมาะสม?",
    options: [
      "Some games help students solve problems and work as a team.",
      "Every student likes every game.",
      "Students should never take a break."
    ],
    answer: 0
  },
  {
    question: "เพื่อนเสนอความเห็นต่างจากคุณ วิธีตอบแบบใดแสดงความเคารพ?",
    options: [
      "I understand your idea. Can I share a different opinion?",
      "Your idea is stupid.",
      "I will not speak to you again."
    ],
    answer: 0
  },
  {
    question: "ควรวาง Example ไว้ตรงไหนของย่อหน้าแบบ Opinion → Reason → Example → Conclusion?",
    options: ["หลัง Reason และก่อน Conclusion", "ก่อน Opinion", "หลัง Conclusion เท่านั้น"],
    answer: 0
  },
  {
    question: "เลือกย่อหน้าที่มีลำดับความคิดสมบูรณ์และสอดคล้องกัน",
    options: [
      "I think students need less homework. They need time to rest. For example, they can play sports after school. For these reasons, a reasonable amount of homework is best.",
      "For example, students need rest. I think homework. For these reasons, school is a place.",
      "I think students need less homework. For these reasons, students need less homework. For example, homework is a word."
    ],
    answer: 0
  }
];

let currentQuestion = 0;
let score = 0;
let canAnswer = true;
let nextQuestionTimeout = null;

const questionNumberEl = document.getElementById("question-number");
const scoreCountEl = document.getElementById("score-count");
const questionTextEl = document.getElementById("question-text");
const optionsContainerEl = document.getElementById("options-container");
const quizBox = document.getElementById("quiz-box");
const resultBox = document.getElementById("result-box");
const finalScoreEl = document.getElementById("final-score");

function loadQuestion() {
  canAnswer = true;
  const question = questions[currentQuestion];
  questionNumberEl.textContent = `ข้อที่ ${currentQuestion + 1} / ${questions.length}`;
  scoreCountEl.textContent = `คะแนน: ${score}`;
  questionTextEl.textContent = question.question;
  optionsContainerEl.replaceChildren();

  question.options.forEach((option, index) => {
    const button = document.createElement("button");
    button.className = "option-btn";
    button.type = "button";
    button.textContent = option;
    button.addEventListener("click", () => selectOption(index, button));
    optionsContainerEl.append(button);
  });
}

function selectOption(selectedIndex, selectedButton) {
  if (!canAnswer) return;
  canAnswer = false;
  const correctIndex = questions[currentQuestion].answer;
  const optionButtons = optionsContainerEl.querySelectorAll(".option-btn");

  if (selectedIndex === correctIndex) {
    selectedButton.classList.add("correct");
    score += 1;
    scoreCountEl.textContent = `คะแนน: ${score}`;
  } else {
    selectedButton.classList.add("incorrect");
    optionButtons[correctIndex].classList.add("correct");
  }

  optionButtons.forEach((button) => {
    button.disabled = true;
  });

  nextQuestionTimeout = window.setTimeout(() => {
    nextQuestionTimeout = null;
    currentQuestion += 1;
    if (currentQuestion < questions.length) {
      loadQuestion();
    } else {
      showResult();
    }
  }, 1000);
}

function showResult() {
  quizBox.classList.add("hidden");
  resultBox.classList.remove("hidden");
  finalScoreEl.textContent = `คุณได้คะแนน ${score} จาก ${questions.length} คะแนน`;
}

function restartQuiz() {
  if (nextQuestionTimeout !== null) {
    window.clearTimeout(nextQuestionTimeout);
    nextQuestionTimeout = null;
  }
  currentQuestion = 0;
  score = 0;
  resultBox.classList.add("hidden");
  quizBox.classList.remove("hidden");
  loadQuestion();
}

loadQuestion();
