"use strict";

const islands = [
  {
    name: "School Uniforms",
    icon: "🏫",
    topic: "Should students wear school uniforms?",
    classmateOpinion: "I think students should wear school uniforms.",
    replyPrompt: "คุณเห็นด้วยกับเพื่อน เลือกคำตอบรับอย่างสุภาพ",
    replyOptions: [
      "I agree. Uniforms can help students feel like a team.",
      "I see your point, but I have a different opinion.",
      "That is a silly idea."
    ],
    replyAnswer: 0,
    agree: {
      opening: "I agree that students should wear school uniforms.",
      reasons: [
        "They help students feel equal and ready to learn.",
        "Students need more time to choose clothes.",
        "Uniforms make every school subject easier."
      ],
      reasonAnswer: 0,
      examples: [
        "For example, students can focus on class instead of comparing their clothes.",
        "For example, uniforms help students finish their homework at school.",
        "For example, students can learn every subject without a teacher."
      ],
      exampleAnswer: 0,
      closings: [
        "For these reasons, I believe uniforms are a good choice for schools.",
        "That is why I believe schools should never have any rules."
      ],
      closingAnswer: 0
    },
    disagree: {
      opening: "I do not think students should have to wear school uniforms.",
      reasons: [
        "Students should have some freedom to express themselves.",
        "Uniforms make students learn every lesson faster.",
        "Students can choose their own school building."
      ],
      reasonAnswer: 0,
      examples: [
        "For example, students could wear neat clothes that show their interests.",
        "For example, students can stop doing all their classwork.",
        "For example, everyone would have the same favorite subject."
      ],
      exampleAnswer: 0,
      closings: [
        "For these reasons, I think students should be allowed to choose neat clothes.",
        "For these reasons, I think students should not need to study."
      ],
      closingAnswer: 0
    }
  },
  {
    name: "Video Games",
    icon: "🎮",
    topic: "Is playing video games good for students?",
    classmateOpinion: "I think video games can help students learn.",
    replyPrompt: "คุณไม่เห็นด้วย แต่ต้องการตอบอย่างสุภาพ เลือกประโยคที่เหมาะสม",
    replyOptions: [
      "I see your point, but I have a different opinion.",
      "I agree with you because games are always perfect.",
      "You are wrong, so stop talking."
    ],
    replyAnswer: 0,
    agree: {
      opening: "I think video games can be good for students.",
      reasons: [
        "Some games help students solve problems and work as a team.",
        "Games mean students never need to read books.",
        "Every game teaches the same useful skills."
      ],
      reasonAnswer: 0,
      examples: [
        "For example, a puzzle game can encourage players to try different solutions.",
        "For example, games can do all of a student's homework.",
        "For example, students do not need to listen to anyone."
      ],
      exampleAnswer: 0,
      closings: [
        "For these reasons, video games can be helpful when students play in moderation.",
        "For these reasons, students should play games all day."
      ],
      closingAnswer: 0
    },
    disagree: {
      opening: "I do not think video games are always good for students.",
      reasons: [
        "Playing for too long can take time away from sleep and schoolwork.",
        "Every video game is impossible to understand.",
        "Students should never do anything for fun."
      ],
      reasonAnswer: 0,
      examples: [
        "For example, a student who plays late may feel tired in class the next day.",
        "For example, video games make every student forget how to read.",
        "For example, students can finish all their work while sleeping."
      ],
      exampleAnswer: 0,
      closings: [
        "For these reasons, students should balance gaming with rest and study.",
        "For these reasons, students should never take a break."
      ],
      closingAnswer: 0
    }
  },
  {
    name: "Homework",
    icon: "📚",
    topic: "Should homework be reduced?",
    classmateOpinion: "I think students should have less homework.",
    replyPrompt: "คุณเห็นด้วยกับเพื่อน เลือกคำตอบรับอย่างสุภาพ",
    replyOptions: [
      "I agree. Students need time to rest after school.",
      "I understand your idea, but I do not agree.",
      "That opinion is ridiculous."
    ],
    replyAnswer: 0,
    agree: {
      opening: "I agree that students should have less homework.",
      reasons: [
        "Students need time to rest and enjoy other activities.",
        "Homework makes every school day a holiday.",
        "Students learn best when they never practice."
      ],
      reasonAnswer: 0,
      examples: [
        "For example, free time lets students play sports or spend time with family.",
        "For example, students can skip every class.",
        "For example, students never need to learn new things."
      ],
      exampleAnswer: 0,
      closings: [
        "For these reasons, a reasonable amount of homework is best.",
        "For these reasons, students should stop learning at school."
      ],
      closingAnswer: 0
    },
    disagree: {
      opening: "I do not think homework should be reduced too much.",
      reasons: [
        "A small amount of practice can help students remember a lesson.",
        "Homework means students never need a teacher.",
        "More homework always makes every student happy."
      ],
      reasonAnswer: 0,
      examples: [
        "For example, a few math problems can help students remember a new method.",
        "For example, students can learn without reading or practicing.",
        "For example, students can finish a test before it is given."
      ],
      exampleAnswer: 0,
      closings: [
        "For these reasons, homework should be useful but not overwhelming.",
        "For these reasons, students should have no free time."
      ],
      closingAnswer: 0
    }
  }
];

const STAGES_PER_ISLAND = 6;
const MAX_HEALTH = 5;
const TRANSITION_DELAY = 1100;
const stageNames = [
  "ตอบรับความคิดเห็นอย่างสุภาพ",
  "เลือกจุดยืนของตนเอง",
  "เลือกเหตุผลสนับสนุน",
  "เลือกตัวอย่างประกอบ",
  "เรียงส่วนประกอบของย่อหน้า",
  "เลือกประโยคสรุป"
];

let islandIndex = 0;
let stageIndex = 0;
let score = 0;
let health = MAX_HEALTH;
let answerLocked = false;
let transitionTimer = null;
let completedParagraphs = [];
let currentDraft = {};

const elements = {
  islandProgress: document.getElementById("islandProgress"),
  score: document.getElementById("scoreText"),
  health: document.getElementById("healthText"),
  stepProgress: document.getElementById("stepProgress"),
  topicLabel: document.getElementById("topicLabel"),
  stageTitle: document.getElementById("stageTitle"),
  prompt: document.getElementById("promptText"),
  hint: document.getElementById("stageHint"),
  options: document.getElementById("optionsGrid"),
  feedback: document.getElementById("feedbackBanner"),
  paragraph: document.getElementById("paragraphText"),
  restart: document.getElementById("restartButton"),
  modal: document.getElementById("resultModal"),
  modalIcon: document.getElementById("resultIcon"),
  modalTitle: document.getElementById("resultTitle"),
  modalDesc: document.getElementById("modalDesc"),
  modalScore: document.getElementById("modalScoreText"),
  paragraphResults: document.getElementById("paragraphResults"),
  playAgain: document.getElementById("playAgainButton"),
  nextPage: document.getElementById("nextPageButton")
};

function getOptions(island, stage) {
  if (stage === 0) {
    return { choices: island.replyOptions, answer: island.replyAnswer };
  }
  if (stage === 1) {
    return { choices: ["Agree — เห็นด้วย", "Disagree — ไม่เห็นด้วย"], answer: null };
  }

  const opinion = currentDraft.stance;
  const branch = island[opinion];
  if (stage === 2) {
    return { choices: branch.reasons, answer: branch.reasonAnswer };
  }
  if (stage === 3) {
    return { choices: branch.examples, answer: branch.exampleAnswer };
  }
  if (stage === 4) {
    const correctOrder = "Opinion → Reason → Example → Conclusion";
    const otherOrders = [
      "Reason → Example → Conclusion → Opinion",
      "Example → Opinion → Conclusion → Reason"
    ];
    const answer = islandIndex % 3;
    const choices = otherOrders.slice();
    choices.splice(answer, 0, correctOrder);
    return { choices, answer };
  }
  return { choices: branch.closings, answer: branch.closingAnswer };
}

function getPrompt(island, stage) {
  if (stage === 0) return `เพื่อนพูดว่า “${island.classmateOpinion}” ${island.replyPrompt}`;
  if (stage === 1) return island.topic;
  if (stage === 2) return "เหตุผลข้อใดสนับสนุนความคิดเห็นของคุณได้ดีที่สุด?";
  if (stage === 3) return "เลือกตัวอย่างที่อธิบายเหตุผลของคุณได้ชัดเจน";
  if (stage === 4) return "ลำดับใดช่วยให้ผู้อ่านเข้าใจความคิดเห็นของคุณได้เป็นขั้นตอน?";
  return "เลือกประโยคสรุปที่ย้ำความคิดเห็นของคุณ";
}

function getHint(stage) {
  const hints = [
    "Responding: ใช้ I agree... หรือ I see your point, but... และหลีกเลี่ยงคำพูดไม่สุภาพ",
    "Giving an opinion: เลือกจุดยืนที่คุณต้องการนำเสนอ",
    "Paragraph structure: Opinion → Reason",
    "Paragraph structure: ยกตัวอย่างที่เกี่ยวข้องกับเหตุผล",
    "Paragraph structure: Opinion → Reason → Example → Conclusion",
    "Paragraph structure: สรุปความคิดด้วย For these reasons..."
  ];
  return hints[stage];
}

function renderParagraph() {
  if (islandIndex >= islands.length || !currentDraft) {
    elements.paragraph.textContent = "เลือกความคิดเห็น เหตุผล และตัวอย่างเพื่อเริ่มสร้างย่อหน้า";
    return;
  }

  const parts = [];
  if (currentDraft.stance) {
    const branch = islands[islandIndex][currentDraft.stance];
    parts.push(branch.opening);
    if (currentDraft.reason) parts.push(currentDraft.reason);
    if (currentDraft.example) parts.push(currentDraft.example);
    if (currentDraft.closing) parts.push(currentDraft.closing);
  }
  elements.paragraph.textContent = parts.length ? parts.join(" ") : "เลือกความคิดเห็น เหตุผล และตัวอย่างเพื่อเริ่มสร้างย่อหน้า";
}

function updateMap() {
  islands.forEach((island, index) => {
    const marker = document.getElementById(`mapIsland${index}`);
    marker.classList.toggle("active", index === islandIndex && health > 0);
    marker.classList.toggle("complete", index < islandIndex || (islandIndex >= islands.length && health > 0));
    marker.querySelector("strong").textContent = index < islandIndex || (islandIndex >= islands.length && health > 0)
      ? "✓ Complete"
      : island.name;
  });
}

function renderStage() {
  if (islandIndex >= islands.length) {
    finishGame(true);
    return;
  }
  const island = islands[islandIndex];
  const stage = stageIndex;
  const options = getOptions(island, stage);

  answerLocked = false;
  elements.islandProgress.textContent = `เกาะ ${islandIndex + 1} / ${islands.length}`;
  elements.stepProgress.textContent = `ภารกิจ ${islandIndex * STAGES_PER_ISLAND + stage + 1} / ${islands.length * STAGES_PER_ISLAND}`;
  elements.topicLabel.textContent = island.name;
  elements.stageTitle.textContent = stageNames[stage];
  elements.prompt.textContent = getPrompt(island, stage);
  elements.hint.textContent = getHint(stage);
  elements.feedback.textContent = "";
  elements.feedback.className = "feedback";
  elements.options.replaceChildren();
  updateMap();

  options.choices.forEach((choice, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "answer-option";
    button.textContent = choice;
    button.addEventListener("click", () => selectAnswer(button, index, options));
    elements.options.append(button);
  });
  renderParagraph();
}

function updateHealth() {
  elements.health.textContent = `${"♥ ".repeat(health)}${"♡ ".repeat(MAX_HEALTH - health)}`.trim();
  elements.health.setAttribute("aria-label", `พลังใจ ${health} จาก ${MAX_HEALTH} ดวง`);
}

function saveAnswer(stage, optionIndex, options) {
  const island = islands[islandIndex];
  if (stage === 0) {
    currentDraft.reply = island.replyOptions[options.answer];
  } else if (stage === 1) {
    currentDraft.stance = optionIndex === 0 ? "agree" : "disagree";
  } else {
    const branch = island[currentDraft.stance];
    if (stage === 2) currentDraft.reason = branch.reasons[options.answer];
    if (stage === 3) currentDraft.example = branch.examples[options.answer];
    if (stage === 5) currentDraft.closing = branch.closings[options.answer];
  }
}

function selectAnswer(button, optionIndex, options) {
  if (answerLocked) return;
  answerLocked = true;
  const isOpinionChoice = stageIndex === 1;
  const isCorrect = isOpinionChoice || optionIndex === options.answer;

  Array.from(elements.options.children).forEach((optionButton, index) => {
    optionButton.disabled = true;
    if (!isOpinionChoice && index === options.answer) optionButton.classList.add("correct");
  });

  if (isCorrect) {
    if (isOpinionChoice) {
      button.classList.add("correct");
    }
    score += 10;
    elements.score.textContent = String(score);
    elements.feedback.textContent = isOpinionChoice
      ? `บันทึกจุดยืนของคุณ: ${optionIndex === 0 ? "เห็นด้วย" : "ไม่เห็นด้วย"}`
      : "ถูกต้อง! ไปต่อกันเลย";
    elements.feedback.className = "feedback success";
    saveAnswer(stageIndex, optionIndex, options);
  } else {
    button.classList.add("incorrect");
    health -= 1;
    updateHealth();
    elements.feedback.textContent = `ลองสังเกตความหมายอีกครั้ง คำตอบที่เหมาะสมคือ “${options.choices[options.answer]}”`;
    elements.feedback.className = "feedback error";
    saveAnswer(stageIndex, options.answer, options);
  }

  renderParagraph();
  transitionTimer = window.setTimeout(() => {
    transitionTimer = null;
    if (health <= 0) {
      finishGame(false);
      return;
    }
    stageIndex += 1;
    if (stageIndex >= STAGES_PER_ISLAND) {
      completedParagraphs.push({ ...currentDraft, topic: islands[islandIndex].name });
      islandIndex += 1;
      stageIndex = 0;
      currentDraft = islandIndex < islands.length ? {} : null;
    }
    renderStage();
  }, TRANSITION_DELAY);
}

function renderResults() {
  elements.paragraphResults.replaceChildren();
  completedParagraphs.forEach((draft) => {
    const article = document.createElement("article");
    const heading = document.createElement("h3");
    heading.textContent = draft.topic;
    const reply = document.createElement("p");
    reply.className = "reply";
    reply.textContent = `Responding: “${draft.reply}”`;
    const paragraph = document.createElement("p");
    const island = islands.find((item) => item.name === draft.topic);
    const branch = island[draft.stance];
    paragraph.textContent = [branch.opening, draft.reason, draft.example, draft.closing].join(" ");
    article.append(heading, reply, paragraph);
    elements.paragraphResults.append(article);
  });
}

function finishGame(won) {
  answerLocked = true;
  elements.modal.classList.add("visible");
  elements.modal.setAttribute("aria-hidden", "false");
  elements.modalIcon.textContent = won ? "🏝️" : "💫";
  elements.modalTitle.textContent = won ? "สำรวจครบทุกเกาะแล้ว!" : "พลังใจหมดแล้ว";
  elements.modalDesc.textContent = won
    ? "เยี่ยมมาก! คุณฝึกตอบรับอย่างสุภาพและสร้างย่อหน้าความคิดเห็นครบทั้ง 3 หัวข้อแล้ว"
    : "ลองทบทวนการตอบรับอย่างสุภาพ การให้เหตุผล และการยกตัวอย่าง แล้วเริ่มใหม่อีกครั้ง";
  elements.modalScore.textContent = `คะแนน ${score} / ${islands.length * STAGES_PER_ISLAND * 10}`;
  elements.nextPage.style.display = won ? "inline-flex" : "none";
  renderResults();
}

function restartGame() {
  if (transitionTimer !== null) {
    window.clearTimeout(transitionTimer);
    transitionTimer = null;
  }
  islandIndex = 0;
  stageIndex = 0;
  score = 0;
  health = MAX_HEALTH;
  completedParagraphs = [];
  currentDraft = {};
  elements.score.textContent = "0";
  updateHealth();
  elements.modal.classList.remove("visible");
  elements.modal.setAttribute("aria-hidden", "true");
  renderStage();
}

elements.restart.addEventListener("click", restartGame);
elements.playAgain.addEventListener("click", restartGame);
updateHealth();
renderStage();
