"use strict";

const questions = [
  {
    base: "kind",
    definition: "ความรู้สึกหรือคุณสมบัติของการเป็นคนใจดี",
    type: "Suffix",
    answer: "-ness",
    choices: ["-ness", "-ful", "un-"],
    word: "kindness",
    meaning: "kindness = ความใจดี",
    enemy: "Grumpy Goblin",
    avatar: "👹"
  },
  {
    base: "possible",
    definition: "สิ่งที่ไม่สามารถเกิดขึ้นหรือทำได้",
    type: "Prefix",
    answer: "im-",
    choices: ["re-", "im-", "-less"],
    word: "impossible",
    meaning: "impossible = เป็นไปไม่ได้",
    enemy: "Impossible Imp",
    avatar: "👾"
  },
  {
    base: "care",
    definition: "ทำสิ่งต่าง ๆ อย่างรอบคอบและใส่ใจ",
    type: "Suffix",
    answer: "-ful",
    choices: ["-ful", "-ness", "un-"],
    word: "careful",
    meaning: "careful = ระมัดระวัง",
    enemy: "Careless Creep",
    avatar: "👻"
  },
  {
    base: "fair",
    definition: "สิ่งที่ไม่ยุติธรรมหรือไม่เป็นธรรม",
    type: "Prefix",
    answer: "un-",
    choices: ["dis-", "un-", "-ful"],
    word: "unfair",
    meaning: "unfair = ไม่ยุติธรรม",
    enemy: "Unfair Ogre",
    avatar: "👺"
  },
  {
    base: "write",
    definition: "เขียนอีกครั้ง",
    type: "Prefix",
    answer: "re-",
    choices: ["re-", "im-", "-ness"],
    word: "rewrite",
    meaning: "rewrite = เขียนใหม่",
    enemy: "Rewrite Wraith",
    avatar: "🧟"
  },
  {
    base: "help",
    definition: "ไม่มีความช่วยเหลือ หรือช่วยเหลือตัวเองไม่ได้",
    type: "Suffix",
    answer: "-less",
    choices: ["-ful", "-less", "dis-"],
    word: "helpless",
    meaning: "helpless = หมดหนทาง / ช่วยตัวเองไม่ได้",
    enemy: "Helpless Hydra",
    avatar: "🐲"
  },
  {
    base: "agree",
    definition: "มีความคิดเห็นไม่ตรงกัน",
    type: "Prefix",
    answer: "dis-",
    choices: ["un-", "dis-", "-ness"],
    word: "disagree",
    meaning: "disagree = ไม่เห็นด้วย",
    enemy: "Disagree Dragon",
    avatar: "🐉"
  },
  {
    base: "dark",
    definition: "สภาวะที่ไม่มีแสงสว่าง",
    type: "Suffix",
    answer: "-ness",
    choices: ["-ful", "re-", "-ness"],
    word: "darkness",
    meaning: "darkness = ความมืด",
    enemy: "Darkness Beast",
    avatar: "🦇"
  }
];

const TRANSITION_DELAY = 1200;
const MAX_HEALTH = 3;
let currentQuestion = 0;
let score = 0;
let health = MAX_HEALTH;
let answerLocked = false;
let transitionTimer = null;

const elements = {
  progress: document.getElementById("questionProgress"),
  score: document.getElementById("scoreText"),
  health: document.getElementById("healthText"),
  playerHealthBar: document.getElementById("playerHealthBar"),
  enemyHealthBar: document.getElementById("enemyHealthBar"),
  enemyAvatar: document.getElementById("enemyAvatar"),
  enemyName: document.getElementById("enemyName"),
  player: document.querySelector(".player"),
  enemy: document.querySelector(".enemy"),
  battleMessage: document.getElementById("battleMessage"),
  round: document.getElementById("roundLabel"),
  type: document.getElementById("affixTypeLabel"),
  definition: document.getElementById("definitionText"),
  base: document.getElementById("baseWord"),
  preview: document.getElementById("wordPreview"),
  options: document.getElementById("optionsGrid"),
  feedback: document.getElementById("feedbackBanner"),
  restart: document.getElementById("restartButton"),
  modal: document.getElementById("resultModal"),
  modalIcon: document.getElementById("resultIcon"),
  modalTitle: document.getElementById("resultTitle"),
  modalDesc: document.getElementById("modalDesc"),
  modalScore: document.getElementById("modalScoreText"),
  playAgain: document.getElementById("playAgainButton")
};

function makeWord(question, affix) {
  return affix.endsWith("-")
    ? affix.slice(0, -1) + question.base
    : question.base + affix.slice(1);
}

function renderQuestion() {
  if (currentQuestion >= questions.length) {
    finishGame(true);
    return;
  }

  const question = questions[currentQuestion];
  answerLocked = false;
  elements.progress.textContent = `${currentQuestion + 1} / ${questions.length}`;
  elements.round.textContent = `ศัตรูตัวที่ ${currentQuestion + 1}`;
  elements.type.textContent = `เลือก ${question.type}`;
  elements.definition.textContent = question.definition;
  elements.base.textContent = question.base;
  elements.preview.textContent = `${question.base} + ?`;
  elements.enemyName.textContent = question.enemy;
  elements.enemyAvatar.textContent = question.avatar;
  elements.enemyHealthBar.style.width = "100%";
  elements.battleMessage.textContent = "สร้างคำให้ถูก เพื่อโจมตี!";
  elements.feedback.textContent = "";
  elements.feedback.className = "feedback";
  elements.options.replaceChildren();

  question.choices.forEach((choice) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "affix-option";
    button.textContent = choice;
    button.setAttribute("aria-label", `ส่วนเติม ${choice}`);
    button.addEventListener("click", () => selectAnswer(button, choice, question));
    elements.options.append(button);
  });
}

function updateHealth() {
  elements.health.textContent = `${"♥ ".repeat(health)}${"♡ ".repeat(MAX_HEALTH - health)}`.trim();
  elements.health.setAttribute("aria-label", `พลังชีวิต ${health} จาก ${MAX_HEALTH} ดวง`);
  elements.playerHealthBar.style.width = `${(health / MAX_HEALTH) * 100}%`;
}

function selectAnswer(selectedButton, selectedAffix, question) {
  if (answerLocked) return;
  answerLocked = true;
  const isCorrect = selectedAffix === question.answer;

  Array.from(elements.options.children).forEach((button) => {
    button.disabled = true;
    if (button.textContent === question.answer) button.classList.add("correct");
  });

  if (isCorrect) {
    score += 10;
    elements.score.textContent = String(score);
    elements.preview.textContent = `${question.base} + ${question.answer} = ${question.word}`;
    elements.enemyHealthBar.style.width = "0%";
    elements.enemy.classList.remove("hit");
    void elements.enemy.offsetWidth;
    elements.enemy.classList.add("hit");
    elements.battleMessage.textContent = "โจมตีสำเร็จ!";
    elements.feedback.textContent = `ถูกต้อง! ${question.meaning}`;
    elements.feedback.className = "feedback success";
  } else {
    selectedButton.classList.add("incorrect");
    health -= 1;
    updateHealth();
    elements.preview.textContent = `${question.base} + ${selectedAffix} = ${makeWord(question, selectedAffix)}`;
    elements.player.classList.remove("hit");
    void elements.player.offsetWidth;
    elements.player.classList.add("hit");
    elements.battleMessage.textContent = "มอนสเตอร์สวนกลับ!";
    elements.feedback.textContent = `ยังไม่ถูก คำตอบคือ ${question.answer} → ${question.word} (${question.meaning})`;
    elements.feedback.className = "feedback error";
  }

  transitionTimer = window.setTimeout(() => {
    transitionTimer = null;
    if (health <= 0) {
      finishGame(false);
      return;
    }
    currentQuestion += 1;
    renderQuestion();
  }, TRANSITION_DELAY);
}

function finishGame(won) {
  answerLocked = true;
  elements.modal.classList.add("visible");
  elements.modal.setAttribute("aria-hidden", "false");
  elements.modalIcon.textContent = won ? "🦊" : "💫";
  elements.modalTitle.textContent = won ? "ปลดล็อก Fox Scholar แล้ว!" : "พลังชีวิตหมด!";
  elements.modalDesc.textContent = won
    ? "กำจัดมอนสเตอร์ครบทุกตัว รับตัวละครโบนัสและเหรียญจากคะแนน แล้วไปทดสอบความรู้ต่อได้เลย"
    : "ไม่เป็นไร ลองทบทวน Prefixes และ Suffixes แล้วเริ่มศึกใหม่อีกครั้ง";
  elements.modalScore.textContent = `คะแนน ${score} / ${questions.length * 10} เหรียญ`;
  document.getElementById("nextPageButton").style.display = won ? "inline-flex" : "none";
}

function restartGame() {
  if (transitionTimer !== null) {
    window.clearTimeout(transitionTimer);
    transitionTimer = null;
  }
  currentQuestion = 0;
  score = 0;
  health = MAX_HEALTH;
  elements.score.textContent = "0";
  updateHealth();
  elements.modal.classList.remove("visible");
  elements.modal.setAttribute("aria-hidden", "true");
  renderQuestion();
}

elements.restart.addEventListener("click", restartGame);
elements.playAgain.addEventListener("click", restartGame);
updateHealth();
renderQuestion();
