"use strict";

const questions = [
  {
    question: "Prefix คือส่วนเติมชนิดใด?",
    options: ["ส่วนเติมหน้าคำพื้นฐาน", "ส่วนเติมท้ายคำพื้นฐาน", "คำที่มีความหมายตรงข้ามเท่านั้น"],
    answer: 0
  },
  {
    question: "Suffix คือส่วนเติมชนิดใด?",
    options: ["ส่วนเติมหน้าคำพื้นฐาน", "ส่วนเติมท้ายคำพื้นฐาน", "คำกริยาที่อยู่หน้าประโยค"],
    answer: 1
  },
  {
    question: "เติมส่วนใดใน kind + ___ = kindness?",
    options: ["-ness", "un-", "re-"],
    answer: 0
  },
  {
    question: "คำว่า impossible หมายถึง “เป็นไปไม่ได้” ควรเติมส่วนใดหน้า possible?",
    options: ["re-", "im-", "dis-"],
    answer: 1
  },
  {
    question: "care + -ful ได้คำใด?",
    options: ["careful", "careless", "carefulness"],
    answer: 0
  },
  {
    question: "re- + write ได้คำใด และหมายถึงอะไร?",
    options: ["rewrite = เขียนใหม่", "unwrite = ไม่เขียน", "writeful = เต็มไปด้วยการเขียน"],
    answer: 0
  },
  {
    question: "help + -less ได้คำว่า helpless ซึ่งหมายถึงอะไร?",
    options: ["ช่วยเหลืออย่างเต็มที่", "หมดหนทาง / ช่วยตัวเองไม่ได้", "ช่วยอีกครั้ง"],
    answer: 1
  },
  {
    question: "เติม Prefix ใดใน ___ + agree = disagree?",
    options: ["un-", "dis-", "im-"],
    answer: 1
  },
  {
    question: "dark + -ness ได้คำว่า darkness ซึ่งหมายถึงอะไร?",
    options: ["ความมืด", "ความใจดี", "ความระมัดระวัง"],
    answer: 0
  },
  {
    question: "fair + un- ได้คำใดที่หมายถึง “ไม่ยุติธรรม”?",
    options: ["unfair", "fairness", "refair"],
    answer: 0
  },
  {
    question: "Suffix -less มักสื่อความหมายใด?",
    options: ["ไม่มีสิ่งนั้น / ปราศจาก", "ทำอีกครั้ง", "ไม่เห็นด้วย"],
    answer: 0
  },
  {
    question: "Suffix -ful ใน careful สื่อความหมายใกล้เคียงกับข้อใด?",
    options: ["เต็มไปด้วยหรือมีลักษณะนั้น", "ไม่มีสิ่งนั้น", "เกิดขึ้นก่อน"],
    answer: 0
  },
  {
    question: "เลือกคำที่แปลว่า “ระมัดระวัง”",
    options: ["careful", "careless", "discare"],
    answer: 0
  },
  {
    question: "ถ้าต้องการสื่อว่า “ไม่มีความช่วยเหลือ” ควรเลือกคำใด?",
    options: ["helpful", "helpless", "rehelp"],
    answer: 1
  },
  {
    question: "ในคำว่า rewrite ส่วนเติม re- เป็นอะไร?",
    options: ["Prefix เพราะอยู่หน้าคำพื้นฐาน", "Suffix เพราะอยู่ท้ายคำพื้นฐาน", "คำพื้นฐาน"],
    answer: 0
  }
];

let currentQuestion = 0;
let score = 0;
let canAnswer = true;
let nextQuestionTimeout = null;

const questionNumberEl = document.getElementById("question-number");
const scoreCountEl = document.getElementById("score-count");
const questionTextEl = document.getElementById("question-text");
const optionsContainerEl = document.getElementById("options-container");
const quizBox = document.getElementById("quiz-box");
const resultBox = document.getElementById("result-box");
const finalScoreEl = document.getElementById("final-score");

function loadQuestion() {
  canAnswer = true;
  const question = questions[currentQuestion];
  questionNumberEl.textContent = `ข้อที่ ${currentQuestion + 1} / ${questions.length}`;
  scoreCountEl.textContent = `คะแนน: ${score}`;
  questionTextEl.textContent = question.question;
  optionsContainerEl.replaceChildren();

  question.options.forEach((option, index) => {
    const button = document.createElement("button");
    button.className = "option-btn";
    button.type = "button";
    button.textContent = option;
    button.addEventListener("click", () => selectOption(index, button));
    optionsContainerEl.append(button);
  });
}

function selectOption(selectedIndex, selectedButton) {
  if (!canAnswer) return;
  canAnswer = false;

  const correctIndex = questions[currentQuestion].answer;
  const optionButtons = optionsContainerEl.querySelectorAll(".option-btn");
  if (selectedIndex === correctIndex) {
    selectedButton.classList.add("correct");
    score += 1;
    scoreCountEl.textContent = `คะแนน: ${score}`;
  } else {
    selectedButton.classList.add("incorrect");
    optionButtons[correctIndex].classList.add("correct");
  }

  optionButtons.forEach((button) => {
    button.disabled = true;
  });

  nextQuestionTimeout = window.setTimeout(() => {
    nextQuestionTimeout = null;
    currentQuestion += 1;
    if (currentQuestion < questions.length) {
      loadQuestion();
    } else {
      showResult();
    }
  }, 1000);
}

function showResult() {
  quizBox.classList.add("hidden");
  resultBox.classList.remove("hidden");
  finalScoreEl.textContent = `คุณได้คะแนน ${score} จาก ${questions.length} คะแนน`;
}

function restartQuiz() {
  if (nextQuestionTimeout !== null) {
    window.clearTimeout(nextQuestionTimeout);
    nextQuestionTimeout = null;
  }
  currentQuestion = 0;
  score = 0;
  resultBox.classList.add("hidden");
  quizBox.classList.remove("hidden");
  loadQuestion();
}

loadQuestion();
