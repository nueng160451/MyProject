const NEXT_PAGE_URL = "quiz1_p3_eng1.html";

const questionsData = [
  {
    tenseCategory: "Present Perfect Tense",
    sentence: "I _______ (visit) Japan twice.",
    hint: "ใช้ have/has + V.3 เพื่อพูดถึงประสบการณ์ที่เกิดขึ้นก่อนตอนนี้",
    options: ["have visited", "was visiting", "had visited"],
    correctAnswer: "have visited",
    explanation: "I have visited ใช้ Present Perfect เพื่อบอกประสบการณ์ที่เคยเกิดขึ้น"
  },
  {
    tenseCategory: "Present Perfect Tense",
    sentence: "She _______ (live) in Bangkok for 5 years.",
    hint: "ใช้ have/has + V.3 กับเหตุการณ์ที่เริ่มในอดีตและต่อเนื่องถึงปัจจุบัน",
    options: ["lives", "has lived", "was living"],
    correctAnswer: "has lived",
    explanation: "She has lived ใช้ Present Perfect เพราะเริ่มอยู่ในอดีตและยังอยู่ต่อเนื่องถึงปัจจุบัน"
  },
  {
    tenseCategory: "Past Continuous Tense",
    sentence: "While I _______ (read) a book, the phone rang.",
    hint: "ใช้ was/were + V-ing กับเหตุการณ์ที่กำลังดำเนินอยู่ในอดีต",
    options: ["have read", "was reading", "had read"],
    correctAnswer: "was reading",
    explanation: "I was reading เป็นเหตุการณ์ที่กำลังดำเนินอยู่ ขณะที่โทรศัพท์ดังแทรกขึ้นมา"
  },
  {
    tenseCategory: "Past Continuous Tense",
    sentence: "They _______ (play) football at 5 PM yesterday.",
    hint: "ใช้ was/were + V-ing สำหรับเหตุการณ์ที่กำลังเกิด ณ เวลาหนึ่งในอดีต",
    options: ["were playing", "have played", "had played"],
    correctAnswer: "were playing",
    explanation: "They were playing ใช้ Past Continuous เพราะกำลังเล่นอยู่ ณ เวลา 5 โมงเย็นเมื่อวาน"
  },
  {
    tenseCategory: "Past Perfect Tense",
    sentence: "The train _______ (leave) before we arrived at the station.",
    hint: "ใช้ had + V.3 กับเหตุการณ์ที่เกิดก่อนอีกเหตุการณ์หนึ่งในอดีต",
    options: ["has left", "was leaving", "had left"],
    correctAnswer: "had left",
    explanation: "The train had left เป็นเหตุการณ์ที่เกิดก่อน we arrived"
  },
  {
    tenseCategory: "Past Perfect Tense",
    sentence: "She _______ (finish) her homework before she went out.",
    hint: "ใช้ had + V.3 เพื่อบอกว่างานหนึ่งเสร็จก่อนอีกเหตุการณ์ในอดีต",
    options: ["had finished", "has finished", "was finishing"],
    correctAnswer: "had finished",
    explanation: "She had finished her homework ก่อนที่ she went out"
  }
];

let currentIdx = 0;
let score = 0;
let isAnswerLocked = false;
let nextQuestionTimeout = null;

function initGame() {
  if (nextQuestionTimeout !== null) {
    window.clearTimeout(nextQuestionTimeout);
    nextQuestionTimeout = null;
  }

  currentIdx = 0;
  score = 0;
  isAnswerLocked = false;
  document.getElementById('resultModal').classList.remove('active');
  loadQuestion();
}

function loadQuestion() {
  const question = questionsData[currentIdx];
  document.getElementById('questionProgress').innerText =
    `${currentIdx + 1} / ${questionsData.length}`;
  document.getElementById('scoreText').innerText = `${score} คะแนน`;
  document.getElementById('tenseCategoryTag').innerText = question.tenseCategory;
  document.getElementById('sentenceText').innerText = question.sentence;
  document.getElementById('sentenceHint').innerText = question.hint;

  const optionsGrid = document.getElementById('optionsGrid');
  optionsGrid.innerHTML = '';
  const feedbackBanner = document.getElementById('feedbackBanner');
  feedbackBanner.innerText = '';
  feedbackBanner.className = 'feedback-banner';
  isAnswerLocked = false;

  question.options.forEach(option => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'option-btn';
    button.innerText = option;
    button.addEventListener('click', () => handleSelectOption(button, option, question));
    optionsGrid.appendChild(button);
  });
}

function handleSelectOption(selectedButton, selectedAnswer, question) {
  if (isAnswerLocked) return;
  isAnswerLocked = true;

  const feedbackBanner = document.getElementById('feedbackBanner');
  const optionButtons = document.querySelectorAll('.option-btn');
  optionButtons.forEach(button => {
    button.disabled = true;
  });

  if (selectedAnswer === question.correctAnswer) {
    selectedButton.classList.add('correct');
    score += 10;
    document.getElementById('scoreText').innerText = `${score} คะแนน`;
    feedbackBanner.innerText = `✨ ถูกต้อง! ${question.explanation}`;
    feedbackBanner.className = 'feedback-banner correct';
  } else {
    selectedButton.classList.add('wrong');
    feedbackBanner.innerText =
      `❌ ยังไม่ถูกต้อง! คำตอบคือ '${question.correctAnswer}' (${question.explanation})`;
    feedbackBanner.className = 'feedback-banner wrong';

    optionButtons.forEach(button => {
      if (button.innerText === question.correctAnswer) {
        button.classList.add('correct');
      }
    });
  }

  nextQuestionTimeout = window.setTimeout(() => {
    nextQuestionTimeout = null;
    currentIdx++;
    if (currentIdx < questionsData.length) {
      loadQuestion();
    } else {
      showCompletionModal();
    }
  }, 1800);
}

function resetGame() {
  initGame();
}

function showCompletionModal() {
  const maxScore = questionsData.length * 10;
  document.getElementById('modalScoreText').innerText =
    `คะแนนรวมทั้งหมด: ${score} / ${maxScore} คะแนน`;
  document.getElementById('modalStars').innerText =
    score === maxScore ? '⭐⭐⭐' : score >= 40 ? '⭐⭐' : '⭐';
  document.getElementById('modalDesc').innerText =
    `ตอบถูก ${score / 10} จาก ${questionsData.length} ข้อ`;
  document.getElementById('resultModal').classList.add('active');
}

function goToNextPage() {
  const maxScore = questionsData.length * 10;
  if (window.parent && window.parent !== window) {
    window.parent.postMessage({
      type: 'LESSON_COMPLETE',
      action: 'NEXT_LESSON',
      lessonId: 'english-p3-perfect-continuous-tenses',
      status: 'PASS',
      score,
      maxScore
    }, '*');
  }

  window.location.href = NEXT_PAGE_URL;
}

window.onload = initGame;
