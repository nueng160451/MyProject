const questions = [
    {
        question: "Which structure forms the Present Perfect?",
        options: ["have/has + V.3", "was/were + V-ing", "had + V.3"],
        answer: 0
    },
    {
        question: "Complete: I ___ visited Japan twice.",
        options: ["has", "have", "had been"],
        answer: 1
    },
    {
        question: "Complete: She ___ lived in Bangkok for 5 years.",
        options: ["have", "has", "was"],
        answer: 1
    },
    {
        question: "Which tense can describe an experience before now?",
        options: ["Present Perfect", "Past Continuous", "Past Perfect"],
        answer: 0
    },
    {
        question: "In 'She has lived in Bangkok for 5 years,' what does 'for 5 years' tell us?",
        options: ["A duration of time", "A place", "A single past time"],
        answer: 0
    },
    {
        question: "Which structure forms the Past Continuous?",
        options: ["have/has + V.3", "was/were + V-ing", "had + V.3"],
        answer: 1
    },
    {
        question: "Complete: While I ___ a book, the phone rang.",
        options: ["was reading", "have read", "had read"],
        answer: 0
    },
    {
        question: "Complete: They ___ football at 5 PM yesterday.",
        options: ["was playing", "were playing", "have played"],
        answer: 1
    },
    {
        question: "Which tense describes an action in progress at a specific time in the past?",
        options: ["Present Perfect", "Past Continuous", "Past Perfect"],
        answer: 1
    },
    {
        question: "In 'While I was reading, the phone rang,' which action was in progress?",
        options: ["Reading a book", "The phone rang", "Arriving at a station"],
        answer: 0
    },
    {
        question: "Which structure forms the Past Perfect?",
        options: ["have/has + V.3", "was/were + V-ing", "had + V.3"],
        answer: 2
    },
    {
        question: "Complete: The train ___ left before we arrived.",
        options: ["has", "was", "had"],
        answer: 2
    },
    {
        question: "Complete: She ___ finished her homework before she went out.",
        options: ["had", "has", "was"],
        answer: 0
    },
    {
        question: "Which tense marks an action completed before another past action?",
        options: ["Present Perfect", "Past Continuous", "Past Perfect"],
        answer: 2
    },
    {
        question: "Choose the correct tense for each clue: experience, action in progress in the past, earlier past action.",
        options: [
            "Present Perfect, Past Continuous, Past Perfect",
            "Past Continuous, Past Perfect, Present Perfect",
            "Past Perfect, Present Perfect, Past Continuous"
        ],
        answer: 0
    }
];

let currentQuestion = 0;
let score = 0;
let canAnswer = true;
let nextQuestionTimeout = null;

const questionNumberEl = document.getElementById('question-number');
const scoreCountEl = document.getElementById('score-count');
const questionTextEl = document.getElementById('question-text');
const optionsContainerEl = document.getElementById('options-container');
const quizBox = document.getElementById('quiz-box');
const resultBox = document.getElementById('result-box');
const finalScoreEl = document.getElementById('final-score');

loadQuestion();

function loadQuestion() {
    canAnswer = true;
    const question = questions[currentQuestion];
    questionNumberEl.innerText = `ข้อที่ ${currentQuestion + 1} / ${questions.length}`;
    scoreCountEl.innerText = `คะแนน: ${score}`;
    questionTextEl.innerText = question.question;
    optionsContainerEl.innerHTML = '';

    question.options.forEach((option, index) => {
        const button = document.createElement('button');
        button.classList.add('option-btn');
        button.type = 'button';
        button.innerText = option;
        button.addEventListener('click', () => selectOption(index, button));
        optionsContainerEl.appendChild(button);
    });
}

function selectOption(selectedIndex, selectedButton) {
    if (!canAnswer) return;
    canAnswer = false;

    const correctIndex = questions[currentQuestion].answer;
    const optionButtons = optionsContainerEl.querySelectorAll('.option-btn');

    if (selectedIndex === correctIndex) {
        selectedButton.classList.add('correct');
        score++;
        scoreCountEl.innerText = `คะแนน: ${score}`;
    } else {
        selectedButton.classList.add('incorrect');
        optionButtons[correctIndex].classList.add('correct');
    }

    optionButtons.forEach(button => {
        button.disabled = true;
    });

    nextQuestionTimeout = window.setTimeout(() => {
        nextQuestionTimeout = null;
        currentQuestion++;
        if (currentQuestion < questions.length) {
            loadQuestion();
        } else {
            showResult();
        }
    }, 1000);
}

function showResult() {
    quizBox.classList.add('hidden');
    resultBox.classList.remove('hidden');
    finalScoreEl.innerText = `คุณได้คะแนน ${score} จาก ${questions.length} คะแนน`;
}

function restartQuiz() {
    if (nextQuestionTimeout !== null) {
        window.clearTimeout(nextQuestionTimeout);
        nextQuestionTimeout = null;
    }
    currentQuestion = 0;
    score = 0;
    resultBox.classList.add('hidden');
    quizBox.classList.remove('hidden');
    loadQuestion();
}
