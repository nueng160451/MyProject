const questions = [
    {
        question: "What does 'Eyes' mean?",
        options: ["ดวงตา", "หู", "มือ"],
        answer: 0
    },
    {
        question: "Which English word means 'มือ'?",
        options: ["Nose", "Hand", "Ear"],
        answer: 1
    },
    {
        question: "What does 'Ear' mean?",
        options: ["จมูก", "ดวงตา", "หู"],
        answer: 2
    },
    {
        question: "Which English word means 'จมูก'?",
        options: ["Nose", "Hand", "Eyes"],
        answer: 0
    },
    {
        question: "Which body part do we use to hear?",
        options: ["Eyes", "Ear", "Nose"],
        answer: 1
    },
    {
        question: "'วันจันทร์' in English is ____.",
        options: ["Sunday", "January", "Monday"],
        answer: 2
    },
    {
        question: "What does 'Sunday' mean?",
        options: ["วันอาทิตย์", "วันจันทร์", "เดือนพฤษภาคม"],
        answer: 0
    },
    {
        question: "'เดือนมกราคม' in English is ____.",
        options: ["May", "January", "Monday"],
        answer: 1
    },
    {
        question: "What does 'May' mean?",
        options: ["วันอาทิตย์", "เดือนมกราคม", "เดือนพฤษภาคม"],
        answer: 2
    },
    {
        question: "Which word is a month?",
        options: ["January", "Sunday", "Monday"],
        answer: 0
    },
    {
        question: "What color is 'Red'?",
        options: ["สีน้ำเงิน", "สีแดง", "สีเหลือง"],
        answer: 1
    },
    {
        question: "'สีน้ำเงิน' in English is ____.",
        options: ["Green", "Yellow", "Blue"],
        answer: 2
    },
    {
        question: "Which English word means 'สีเหลือง'?",
        options: ["Yellow", "Red", "Blue"],
        answer: 0
    },
    {
        question: "What color is 'Green'?",
        options: ["สีแดง", "สีเขียว", "สีน้ำเงิน"],
        answer: 1
    },
    {
        question: "Which group contains only colors?",
        options: ["Eyes, Hand, Ear", "Monday, Sunday, May", "Red, Blue, Yellow"],
        answer: 2
    }
];

let currentQuestion = 0;
let score = 0;
let canAnswer = true;

const questionNumberEl = document.getElementById('question-number');
const scoreCountEl = document.getElementById('score-count');
const questionTextEl = document.getElementById('question-text');
const optionsContainerEl = document.getElementById('options-container');
const quizBox = document.getElementById('quiz-box');
const resultBox = document.getElementById('result-box');
const finalScoreEl = document.getElementById('final-score');

loadQuestion();

function loadQuestion() {
    canAnswer = true;
    const question = questions[currentQuestion];
    questionNumberEl.innerText = `ข้อที่ ${currentQuestion + 1} / ${questions.length}`;
    scoreCountEl.innerText = `คะแนน: ${score}`;
    questionTextEl.innerText = question.question;
    optionsContainerEl.innerHTML = '';

    question.options.forEach((option, index) => {
        const button = document.createElement('button');
        button.classList.add('option-btn');
        button.type = 'button';
        button.innerText = option;
        button.addEventListener('click', () => selectOption(index, button));
        optionsContainerEl.appendChild(button);
    });
}

function selectOption(selectedIndex, selectedButton) {
    if (!canAnswer) return;
    canAnswer = false;

    const correctIndex = questions[currentQuestion].answer;
    const optionButtons = optionsContainerEl.querySelectorAll('.option-btn');

    if (selectedIndex === correctIndex) {
        selectedButton.classList.add('correct');
        score++;
        scoreCountEl.innerText = `คะแนน: ${score}`;
    } else {
        selectedButton.classList.add('incorrect');
        optionButtons[correctIndex].classList.add('correct');
    }

    optionButtons.forEach(button => {
        button.disabled = true;
    });

    window.setTimeout(() => {
        currentQuestion++;
        if (currentQuestion < questions.length) {
            loadQuestion();
        } else {
            showResult();
        }
    }, 1000);
}

function showResult() {
    quizBox.classList.add('hidden');
    resultBox.classList.remove('hidden');
    finalScoreEl.innerText = `คุณได้คะแนน ${score} จาก ${questions.length} คะแนน`;
}

function restartQuiz() {
    currentQuestion = 0;
    score = 0;
    resultBox.classList.add('hidden');
    quizBox.classList.remove('hidden');
    loadQuestion();
}
