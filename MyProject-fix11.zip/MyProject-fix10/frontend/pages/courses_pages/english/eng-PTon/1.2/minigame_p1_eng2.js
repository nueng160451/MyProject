
const cardPairsData = [
  // 1. หมวดร่างกาย (Body Parts)
  { id: 'eyes', category: 'body', text: 'ดวงตา', icon: '👀', matchId: 'eyes' },
  { id: 'eyes-en', category: 'body', text: 'Eyes', icon: '👁️', matchId: 'eyes' },
  { id: 'hand', category: 'body', text: 'มือ', icon: '✋', matchId: 'hand' },
  { id: 'hand-en', category: 'body', text: 'Hand', icon: '🖐️', matchId: 'hand' },
  { id: 'ear', category: 'body', text: 'หู', icon: '👂', matchId: 'ear' },
  { id: 'ear-en', category: 'body', text: 'Ear', icon: '👂', matchId: 'ear' },
  { id: 'nose', category: 'body', text: 'จมูก', icon: '👃', matchId: 'nose' },
  { id: 'nose-en', category: 'body', text: 'Nose', icon: '👃', matchId: 'nose' },

  // 2. หมวดวันและเดือน (Days & Months)
  { id: 'jan', category: 'time', text: 'เดือนมกราคม', icon: '❄️', matchId: 'jan' },
  { id: 'jan-en', category: 'time', text: 'January', icon: '🗓️', matchId: 'jan' },
  { id: 'mon', category: 'time', text: 'วันจันทร์', icon: '🟡', matchId: 'mon' },
  { id: 'mon-en', category: 'time', text: 'Monday', icon: '📅', matchId: 'mon' },
  { id: 'sun', category: 'time', text: 'วันอาทิตย์', icon: '🔴', matchId: 'sun' },
  { id: 'sun-en', category: 'time', text: 'Sunday', icon: '☀️', matchId: 'sun' },
  { id: 'may', category: 'time', text: 'เดือนพฤษภาคม', icon: '🌸', matchId: 'may' },
  { id: 'may-en', category: 'time', text: 'May', icon: '🌺', matchId: 'may' },

  // 3. หมวดสี (Colors)
  { id: 'red', category: 'colors', text: 'สีแดง', icon: '🔴', matchId: 'red' },
  { id: 'red-en', category: 'colors', text: 'Red', icon: '🔴', matchId: 'red' },
  { id: 'blue', category: 'colors', text: 'สีน้ำเงิน', icon: '🔵', matchId: 'blue' },
  { id: 'blue-en', category: 'colors', text: 'Blue', icon: '🔵', matchId: 'blue' },
  { id: 'yellow', category: 'colors', text: 'สีเหลือง', icon: '🟡', matchId: 'yellow' },
  { id: 'yellow-en', category: 'colors', text: 'Yellow', icon: '🟡', matchId: 'yellow' },
  { id: 'green', category: 'colors', text: 'สีเขียว', icon: '🟢', matchId: 'green' },
  { id: 'green-en', category: 'colors', text: 'Green', icon: '🟢', matchId: 'green' }
];

// State Variables
let currentCategory = 'all';
let cards = [];
let flippedCards = [];
let matchedCount = 0;
let totalPairs = 0;
let moves = 0;
let timerSeconds = 0;
let timerInterval = null;
let isBoardLocked = false;

// Initialize Game
function initGame() {
  const cardGrid = document.getElementById('cardGrid');
  cardGrid.innerHTML = '';
  flippedCards = [];
  matchedCount = 0;
  moves = 0;
  timerSeconds = 0;
  isBoardLocked = false;
  
  clearInterval(timerInterval);
  document.getElementById('timer').innerText = '00:00';
  document.getElementById('moveCount').innerText = '0 ครั้ง';

  // Filter Cards by Selected Category
  let filteredData = cardPairsData;
  if (currentCategory !== 'all') {
    filteredData = cardPairsData.filter(item => item.category === currentCategory);
  }

  // Shuffle and Create Card Pool
  cards = shuffleArray([...filteredData]);
  totalPairs = cards.length / 2;
  document.getElementById('matchScore').innerText = `0 / ${totalPairs}`;

  // Render Cards into Grid
  cards.forEach((data, index) => {
    const cardEl = createCardElement(data, index);
    cardGrid.appendChild(cardEl);
  });
}

// Create Card HTML Element
function createCardElement(data, index) {
  const card = document.createElement('div');
  card.className = 'memory-card';
  card.dataset.index = index;
  card.dataset.matchId = data.matchId;

  card.innerHTML = `
    <div class="card-inner">
      <div class="card-back"></div>
      <div class="card-front">
        <div class="card-icon">${data.icon}</div>
        <div class="card-text">${data.text}</div>
      </div>
    </div>
  `;

  card.addEventListener('click', () => handleCardClick(card));
  return card;
}

// Handle Card Click Logic
function handleCardClick(card) {
  if (isBoardLocked || card.classList.contains('flipped') || card.classList.contains('matched')) {
    return;
  }

  // Start Timer on First Move
  if (moves === 0 && flippedCards.length === 0 && !timerInterval) {
    startTimer();
  }

  card.classList.add('flipped');
  flippedCards.push(card);

  if (flippedCards.length === 2) {
    moves++;
    document.getElementById('moveCount').innerText = `${moves} ครั้ง`;
    checkMatch();
  }
}

// Check if Flipped Cards Match
function checkMatch() {
  const [card1, card2] = flippedCards;
  const isMatch = card1.dataset.matchId === card2.dataset.matchId;

  if (isMatch) {
    card1.classList.add('matched');
    card2.classList.add('matched');
    matchedCount++;
    document.getElementById('matchScore').innerText = `${matchedCount} / ${totalPairs}`;
    flippedCards = [];

    // Check Win Condition
    if (matchedCount === totalPairs) {
      clearInterval(timerInterval);
      setTimeout(showResultModal, 600);
    }
  } else {
    isBoardLocked = true;
    setTimeout(() => {
      card1.classList.remove('flipped');
      card2.classList.remove('flipped');
      flippedCards = [];
      isBoardLocked = false;
    }, 1000);
  }
}

// Switch Vocabulary Category
function switchCategory(cat) {
  currentCategory = cat;
  document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
  event.target.classList.add('active');
  initGame();
}

// Timer Utilities
function startTimer() {
  timerInterval = setInterval(() => {
    timerSeconds++;
    const mins = String(Math.floor(timerSeconds / 60)).padStart(2, '0');
    const secs = String(timerSeconds % 60).padStart(2, '0');
    document.getElementById('timer').innerText = `${mins}:${secs}`;
  }, 1000);
}

// Shuffle Utility
function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

// Restart Game
function restartGame() {
  document.getElementById('resultModal').classList.remove('active');
  initGame();
}

// Show Completion Result Modal
function showResultModal() {
  const modal = document.getElementById('resultModal');
  const mins = String(Math.floor(timerSeconds / 60)).padStart(2, '0');
  const secs = String(timerSeconds % 60).padStart(2, '0');
  
  document.getElementById('summaryTime').innerText = `${mins}:${secs}`;
  document.getElementById('summaryMoves').innerText = `${moves} ครั้ง`;

  modal.classList.add('active');
}

// PostMessage integration for course website / LMS
function finishLesson() {
  if (window.parent) {
    window.parent.postMessage({
      type: 'LESSON_COMPLETE',
      lessonId: 'find-the-match-1',
      status: 'PASS',
      moves: moves,
      timeInSeconds: timerSeconds
    }, '*');
  }
  window.location.href = 'quiz1_p1_eng2.html';
}

// Load Game on Startup
window.onload = initGame;