const questions = [
  {
    question: "There is ___ orange in the lunch box.",
    options: ["a", "an", "the"],
    answer: 1
  },
  {
    question: "I saw ___ cat. ___ cat was sleeping.",
    options: ["A / The", "An / A", "The / An"],
    answer: 0
  },
  {
    question: "She wants to bring ___ umbrella because it may rain.",
    options: ["a", "an", "those"],
    answer: 1
  },
  {
    question: "___ is the book in my hand.",
    options: ["This", "That", "Those"],
    answer: 0
  },
  {
    question: "Look at the stars far away. ___ are beautiful.",
    options: ["This", "These", "Those"],
    answer: 2
  },
  {
    question: "___ are my pencils here on the desk.",
    options: ["That", "These", "This"],
    answer: 1
  },
  {
    question: "Look at the toy on the high shelf. ___ is a rocket.",
    options: ["That", "These", "Those"],
    answer: 0
  },
  {
    question: "___ Earth goes around the sun.",
    options: ["A", "An", "The"],
    answer: 2
  },
  {
    question: "I have ___ apple and ___ banana.",
    options: ["a / an", "an / a", "the / an"],
    answer: 1
  },
  {
    question: "Which word is used for one thing that is near?",
    options: ["Those", "That", "This"],
    answer: 2
  },
  {
    question: "Which word is used for many things that are far away?",
    options: ["These", "Those", "This"],
    answer: 1
  },
  {
    question: "Choose the correct sentence.",
    options: [
      "These is my books.",
      "Those are my books over there.",
      "That are my books."
    ],
    answer: 1
  }
];

let currentQuestion = 0;
let score = 0;
let canAnswer = true;

const questionNumberEl = document.getElementById('questionNumber');
const scoreCountEl = document.getElementById('scoreCount');
const questionTextEl = document.getElementById('questionText');
const optionsContainerEl = document.getElementById('optionsContainer');
const feedbackEl = document.getElementById('feedback');
const quizBox = document.getElementById('quizBox');
const resultBox = document.getElementById('resultBox');
const finalScoreEl = document.getElementById('finalScore');

function loadQuestion() {
  canAnswer = true;
  const question = questions[currentQuestion];
  questionNumberEl.innerText = `ข้อที่ ${currentQuestion + 1} / ${questions.length}`;
  scoreCountEl.innerText = `คะแนน: ${score}`;
  questionTextEl.innerText = question.question;
  feedbackEl.innerText = '';
  feedbackEl.className = 'feedback';
  optionsContainerEl.innerHTML = '';

  question.options.forEach((option, index) => {
    const button = document.createElement('button');
    button.className = 'option-btn';
    button.type = 'button';
    button.innerText = option;
    button.addEventListener('click', () => selectOption(index, button));
    optionsContainerEl.appendChild(button);
  });
}

function selectOption(selectedIndex, selectedButton) {
  if (!canAnswer) return;
  canAnswer = false;

  const correctIndex = questions[currentQuestion].answer;
  const optionButtons = optionsContainerEl.querySelectorAll('.option-btn');
  optionButtons.forEach(button => {
    button.disabled = true;
  });

  if (selectedIndex === correctIndex) {
    score++;
    selectedButton.classList.add('correct');
    feedbackEl.innerText = 'ถูกต้อง เก่งมาก! ✅';
    feedbackEl.classList.add('correct');
    scoreCountEl.innerText = `คะแนน: ${score}`;
  } else {
    selectedButton.classList.add('incorrect');
    optionButtons[correctIndex].classList.add('correct');
    feedbackEl.innerText = 'ยังไม่ถูก ลองจำหลักไวยากรณ์ข้อนี้ไว้นะ';
    feedbackEl.classList.add('incorrect');
  }

  window.setTimeout(() => {
    currentQuestion++;
    if (currentQuestion < questions.length) {
      loadQuestion();
    } else {
      showResult();
    }
  }, 1000);
}

function showResult() {
  quizBox.hidden = true;
  resultBox.hidden = false;
  finalScoreEl.innerText = `คุณได้ ${score} จาก ${questions.length} คะแนน`;
}

function restartQuiz() {
  currentQuestion = 0;
  score = 0;
  resultBox.hidden = true;
  quizBox.hidden = false;
  loadQuestion();
}

document.getElementById('restartButton').addEventListener('click', restartQuiz);
loadQuestion();