// =============================================================
// ⚙️ การตั้งค่าระบบเปลี่ยนหน้า
// =============================================================
// ใส่ URL หน้าถัดไปที่คุณต้องการให้นักเรียนเปลี่ยนไปเมื่อเล่นจบครบทุกด่าน
const NEXT_PAGE_URL = "quiz1_p1_eng3.html";
const MAX_LIVES = 5;

// Database of 3 Distinct Stages & Questions
const stageData = [
  // -------------------------------------------------------------
  // STAGE 1: Detective Office (Topic: Articles -> a, an, the)
  // -------------------------------------------------------------
  {
    stageId: 1,
    title: "ด่านที่ 1: ห้องนักสืบ",
    grammarTopic: "Articles (A / An / The)",
    svgScene: `<svg viewBox="0 0 800 400" width="100%" height="100%">
      <rect width="800" height="300" fill="#FEF3C7"/>
      <rect y="300" width="800" height="100" fill="#D97706"/>
      <rect x="50" y="40" width="140" height="120" rx="10" fill="#BAE6FD" stroke="#78350F" stroke-width="6"/>
      <circle cx="120" cy="90" r="28" fill="#FACC15"/>
      <rect x="620" y="30" width="130" height="270" fill="#92400E"/>
      <rect x="630" y="50" width="110" height="10" fill="#78350F"/>
      <rect x="630" y="130" width="110" height="10" fill="#78350F"/>
      <path d="M 280 220 L 520 220 L 550 320 L 250 320 Z" fill="#B45309"/>
      <circle cx="340" cy="205" r="14" fill="#EF4444"/>
      <path d="M 340 190 Q 344 185 342 180" stroke="#15803D" stroke-width="2" fill="none"/>
      <rect x="50" y="240" width="160" height="80" rx="15" fill="#F97316"/>
      <ellipse cx="130" cy="305" rx="22" ry="14" fill="#78350F"/>
      <line x1="230" y1="160" x2="210" y2="290" stroke="#0284C7" stroke-width="8" stroke-linecap="round"/>
    </svg>`,
    hotspots: [
      {
        id: "s1-q1",
        x: "42%", y: "48%",
        icon: "🔍",
        category: "แอปเปิลบนโต๊ะ",
        question: "Look! There is ___ apple on the table.",
        options: ["a", "an", "the"],
        answer: "an",
        svgIcon: `<svg viewBox="0 0 60 60" width="60"><circle cx="30" cy="34" r="20" fill="#EF4444"/><path d="M30 14 Q34 8 32 4" stroke="#15803D" stroke-width="3" fill="none"/></svg>`
      },
      {
        id: "s1-q2",
        x: "15%", y: "18%",
        icon: "🔍",
        category: "พระอาทิตย์นอกหน้าต่าง",
        question: "Look outside! ___ sun is shining brightly.",
        options: ["A", "An", "The"],
        answer: "The",
        svgIcon: `<svg viewBox="0 0 60 60" width="60"><circle cx="30" cy="30" r="22" fill="#FACC15"/></svg>`
      },
      {
        id: "s1-q3",
        x: "28%", y: "52%",
        icon: "🔍",
        category: "ร่มพิงผนัง",
        question: "It might rain. Don't forget to bring ___ umbrella.",
        options: ["a", "an", "the"],
        answer: "an",
        svgIcon: `<svg viewBox="0 0 60 60" width="60"><path d="M 10 35 Q 30 10 50 35 Z" fill="#0284C7"/><line x1="30" y1="35" x2="30" y2="52" stroke="#334155" stroke-width="4"/></svg>`
      },
      {
        id: "s1-q4",
        x: "16%", y: "74%",
        icon: "🔍",
        category: "สุนัขใต้โซฟา",
        question: "I see ___ cute dog sleeping under the sofa.",
        options: ["a", "an", "the"],
        answer: "a",
        svgIcon: `<svg viewBox="0 0 60 60" width="60"><ellipse cx="30" cy="34" rx="20" ry="14" fill="#78350F"/><circle cx="18" cy="28" r="10" fill="#78350F"/></svg>`
      }
    ]
  },

  // -------------------------------------------------------------
  // STAGE 2: Toy Shop & Distance (Topic: This / That / These / Those)
  // -------------------------------------------------------------
  {
    stageId: 2,
    title: "ด่านที่ 2: ร้านของเล่น",
    grammarTopic: "Demonstratives (This / That / These / Those)",
    svgScene: `<svg viewBox="0 0 800 400" width="100%" height="100%">
      <rect width="800" height="400" fill="#F0F9FF"/>
      <rect x="40" y="80" width="720" height="14" fill="#0284C7"/>
      <rect x="40" y="200" width="720" height="14" fill="#0284C7"/>
      <ellipse cx="650" cy="290" rx="28" ry="24" fill="#9A3412"/>
      <circle cx="650" cy="250" r="20" fill="#9A3412"/>
      <polygon points="120,30 125,42 138,42 127,50 131,62 120,54 109,62 113,50 102,42 115,42" fill="#FACC15"/>
      <polygon points="200,40 205,52 218,52 207,60 211,72 200,64 189,72 193,60 182,52 195,52" fill="#FACC15"/>
      <rect x="520" y="170" width="40" height="26" fill="#EF4444" rx="3"/>
      <rect x="570" y="166" width="40" height="30" fill="#3B82F6" rx="3"/>
      <path d="M 300 40 L 320 75 L 280 75 Z" fill="#EC4899"/>
      <rect x="285" y="75" width="30" height="40" fill="#E2E8F0"/>
    </svg>`,
    hotspots: [
      {
        id: "s2-q1",
        x: "80%", y: "65%",
        icon: "🔍",
        category: "หมีเทดดี้ (ใกล้ตัว / 1 ตัว)",
        hint: "👉 อยู่ใกล้ตัวนักสืบ (1 สิ่ง)",
        question: "___ is my favourite teddy bear in my hand.",
        options: ["This", "That", "These", "Those"],
        answer: "This",
        svgIcon: `<svg viewBox="0 0 60 60" width="60"><circle cx="30" cy="24" r="16" fill="#9A3412"/><ellipse cx="30" cy="44" rx="20" ry="14" fill="#9A3412"/></svg>`
      },
      {
        id: "s2-q2",
        x: "20%", y: "12%",
        icon: "🔍",
        category: "ดาวห้อยเพดาน (ไกลตัว / หลายดวง)",
        hint: "👈 อยู่ไกลตัวบนเพดาน (หลายสิ่ง)",
        question: "Look up there! ___ are shiny stars hanging high.",
        options: ["This", "That", "These", "Those"],
        answer: "Those",
        svgIcon: `<svg viewBox="0 0 60 60" width="60"><polygon points="30,5 37,20 54,20 40,30 45,46 30,36 15,46 20,30 6,20 23,20" fill="#FACC15"/></svg>`
      },
      {
        id: "s2-q3",
        x: "68%", y: "42%",
        icon: "🔍",
        category: "หนังสือบนโต๊ะ (ใกล้ตัว / หลายเล่ม)",
        hint: "👉 อยู่ใกล้ตัววางบนโต๊ะ (หลายสิ่ง)",
        question: "___ are colorful books right here on my desk.",
        options: ["This", "That", "These", "Those"],
        answer: "These",
        svgIcon: `<svg viewBox="0 0 60 60" width="60"><rect x="10" y="15" width="40" height="14" fill="#EF4444" rx="2"/><rect x="10" y="32" width="40" height="14" fill="#3B82F6" rx="2"/></svg>`
      },
      {
        id: "s2-q4",
        x: "37%", y: "18%",
        icon: "🔍",
        category: "จรวดบนชั้นสูง (ไกลตัว / 1 ชิ้น)",
        hint: "👈 อยู่ไกลบนชั้นวางสูง (1 สิ่ง)",
        question: "Look at the high shelf! ___ is a pink rocket toy.",
        options: ["This", "That", "These", "Those"],
        answer: "That",
        svgIcon: `<svg viewBox="0 0 60 60" width="60"><path d="M 30 5 L 45 35 L 15 35 Z" fill="#EC4899"/><rect x="20" y="35" width="20" height="20" fill="#94A3B8"/></svg>`
      }
    ]
  },

  // -------------------------------------------------------------
  // STAGE 3: Treasure Island (Topic: Master Mixed Challenge)
  // -------------------------------------------------------------
  {
    stageId: 3,
    title: "ด่านที่ 3: เกาะมหาสมบัติ",
    grammarTopic: "Grammar Master Challenge (รวมไวยากรณ์)",
    svgScene: `<svg viewBox="0 0 800 400" width="100%" height="100%">
      <rect width="800" height="280" fill="#38BDF8"/>
      <path d="M 0 280 Q 400 240 800 280 L 800 400 L 0 400 Z" fill="#FDE047"/>
      <rect x="350" y="270" width="100" height="65" rx="8" fill="#78350F" stroke="#F59E0B" stroke-width="4"/>
      <circle cx="400" cy="300" r="8" fill="#FACC15"/>
      <rect x="80" y="150" width="30" height="140" fill="#78350F"/>
      <circle cx="95" cy="120" r="50" fill="#15803D"/>
      <path d="M 600 60 Q 610 50 620 60 Q 630 50 640 60" stroke="#1E293B" stroke-width="3" fill="none"/>
      <path d="M 660 80 Q 670 70 680 80 Q 690 70 700 80" stroke="#1E293B" stroke-width="3" fill="none"/>
    </svg>`,
    hotspots: [
      {
        id: "s3-q1",
        x: "11%", y: "24%",
        icon: "🔍",
        category: "นกฮูกบนต้นไม้",
        question: "Look up at the tree! There is ___ owl sitting there.",
        options: ["a", "an", "the"],
        answer: "an",
        svgIcon: `<svg viewBox="0 0 60 60" width="60"><circle cx="30" cy="30" r="20" fill="#A16207"/><circle cx="23" cy="26" r="6" fill="white"/><circle cx="37" cy="26" r="6" fill="white"/><circle cx="23" cy="26" r="3" fill="black"/><circle cx="37" cy="26" r="3" fill="black"/></svg>`
      },
      {
        id: "s3-q2",
        x: "82%", y: "16%",
        icon: "🔍",
        category: "ฝูงนกบนท้องฟ้า (ไกล)",
        hint: "👈 อยู่ไกลบนท้องฟ้า (หลายตัว)",
        question: "Look at the sky! ___ are wild birds flying away.",
        options: ["This", "That", "These", "Those"],
        answer: "Those",
        svgIcon: `<svg viewBox="0 0 60 60" width="60"><path d="M 10 30 Q 25 15 40 30 Q 55 15 70 30" stroke="#1E293B" stroke-width="4" fill="none"/></svg>`
      },
      {
        id: "s3-q3",
        x: "50%", y: "70%",
        icon: "🗝️",
        category: "หีบสมบัติโบราณ",
        question: "___ chest right here holds the golden treasure!",
        options: ["This", "That", "These", "Those"],
        answer: "This",
        svgIcon: `<svg viewBox="0 0 60 60" width="60"><rect x="10" y="15" width="40" height="30" rx="4" fill="#78350F" stroke="#FACC15" stroke-width="3"/><circle cx="30" cy="30" r="4" fill="#FACC15"/></svg>`
      },
      {
        id: "s3-q4",
        x: "40%", y: "20%",
        icon: "🔍",
        category: "ดาวเคราะห์โลกในอวกาศ",
        question: "___ Earth goes around the sun.",
        options: ["A", "An", "The"],
        answer: "The",
        svgIcon: `<svg viewBox="0 0 60 60" width="60"><circle cx="30" cy="30" r="22" fill="#0284C7"/><path d="M 15 25 Q 25 20 35 32 Q 40 40 48 35" fill="#22C55E"/></svg>`
      }
    ]
  }
];

// Global State Variables
let currentStageIdx = 0;
let solvedHotspotIds = new Set();
let stageScore = 0;
let activeHotspot = null;
let lives = MAX_LIVES;
let isAnswerLocked = false;

// Initialize Elements
const sceneContainer = document.getElementById('sceneContainer');
const stageTitleText = document.getElementById('stageTitleText');
const clueProgress = document.getElementById('clueProgress');
const totalScoreEl = document.getElementById('totalScore');
const quizModal = document.getElementById('quizModal');
const stageEndModal = document.getElementById('stageEndModal');
const gameOverModal = document.getElementById('gameOverModal');
const livesDisplay = document.getElementById('livesDisplay');

function updateLivesDisplay() {
  livesDisplay.innerText = `${'❤️'.repeat(lives)}${'🖤'.repeat(MAX_LIVES - lives)}`;
  livesDisplay.setAttribute('aria-label', `ชีวิต ${lives} จาก ${MAX_LIVES}`);
}

function restartGame() {
  currentStageIdx = 0;
  stageScore = 0;
  lives = MAX_LIVES;
  isAnswerLocked = false;
  activeHotspot = null;
  totalScoreEl.innerText = '0';
  quizModal.classList.remove('active');
  stageEndModal.classList.remove('active');
  gameOverModal.classList.remove('active');
  updateLivesDisplay();
  loadStage(0);
}

// Load Current Stage
function loadStage(idx) {
  currentStageIdx = idx;
  const stage = stageData[currentStageIdx];
  solvedHotspotIds.clear();

  // Update Stage Navigation Pills
  for (let i = 1; i <= 3; i++) {
    const pill = document.getElementById(`pill-${i}`);
    if (i - 1 === currentStageIdx) {
      pill.className = 'stage-pill active';
    } else if (i - 1 < currentStageIdx) {
      pill.className = 'stage-pill';
    } else {
      pill.className = 'stage-pill locked';
    }
  }

  // Update Status Display
  stageTitleText.innerText = stage.title;
  clueProgress.innerText = `0 / ${stage.hotspots.length}`;

  // Render Scene SVG & Hotspot Pins
  sceneContainer.innerHTML = stage.svgScene;

  stage.hotspots.forEach(hp => {
    const btn = document.createElement('div');
    btn.className = 'hotspot-btn';
    btn.style.left = hp.x;
    btn.style.top = hp.y;
    btn.innerText = hp.icon;
    btn.dataset.id = hp.id;

    btn.addEventListener('click', () => openQuizModal(hp, btn));
    sceneContainer.appendChild(btn);
  });
}

// Open Quiz Modal
function openQuizModal(hp, btnEl) {
  if (solvedHotspotIds.has(hp.id) || lives === 0) return;

  activeHotspot = { ...hp, btnEl };
  isAnswerLocked = false;

  document.getElementById('quizItemCategory').innerText = hp.category;
  document.getElementById('quizItemIllustration').innerHTML = hp.svgIcon;
  
  const distanceHint = document.getElementById('quizDistanceHint');
  if (hp.hint) {
    distanceHint.innerText = hp.hint;
    distanceHint.style.display = 'inline-block';
  } else {
    distanceHint.style.display = 'none';
  }

  document.getElementById('questionText').innerText = hp.question;
  document.getElementById('quizFeedback').innerText = '';
  document.getElementById('quizFeedback').className = 'feedback-msg';

  // Render Option Buttons
  const optionsGrid = document.getElementById('optionsGrid');
  optionsGrid.innerHTML = '';

  hp.options.forEach(opt => {
    const btn = document.createElement('button');
    btn.className = 'opt-btn';
    btn.innerText = opt;
    btn.onclick = () => submitAnswer(opt);
    optionsGrid.appendChild(btn);
  });

  quizModal.classList.add('active');
}

// Submit Quiz Answer
function submitAnswer(selectedOpt) {
  if (isAnswerLocked || !activeHotspot) return;

  const feedback = document.getElementById('quizFeedback');
  const stage = stageData[currentStageIdx];
  const optionButtons = document.querySelectorAll('#optionsGrid .opt-btn');
  isAnswerLocked = true;
  optionButtons.forEach(button => {
    button.disabled = true;
  });

  if (selectedOpt === activeHotspot.answer) {
    feedback.innerText = '✨ ถูกต้องแล้ว! พบบทเรียนไวยากรณ์ลับ 🎉';
    feedback.className = 'feedback-msg correct';

    solvedHotspotIds.add(activeHotspot.id);
    activeHotspot.btnEl.classList.add('solved');
    stageScore++;
    totalScoreEl.innerText = stageScore;
    clueProgress.innerText = `${solvedHotspotIds.size} / ${stage.hotspots.length}`;

    setTimeout(() => {
      quizModal.classList.remove('active');
      // Check Stage Completion
      if (solvedHotspotIds.size === stage.hotspots.length) {
        showStageEndModal();
      } else {
        isAnswerLocked = false;
      }
    }, 1000);
  } else {
    lives--;
    updateLivesDisplay();
    feedback.innerText = lives === 0
      ? '❌ พลาดครบ 5 ครั้งแล้ว!'
      : `❌ ยังไม่ถูกต้อง! เหลือหัวใจ ${lives} ดวง ลองอีกครั้งนะ`;
    feedback.className = 'feedback-msg wrong';

    setTimeout(() => {
      if (lives === 0) {
        quizModal.classList.remove('active');
        gameOverModal.classList.add('active');
        return;
      }

      optionButtons.forEach(button => {
        button.disabled = false;
      });
      isAnswerLocked = false;
    }, 700);
  }
}

// Show Stage Completion Modal
function showStageEndModal() {
  const modalIcon = document.getElementById('stageModalIcon');
  const modalTitle = document.getElementById('stageModalTitle');
  const modalDesc = document.getElementById('stageModalDesc');
  const nextStageBtn = document.getElementById('nextStageBtn');

  if (currentStageIdx < stageData.length - 1) {
    // ยังไม่จบเกม (ผ่านด่าน 1 หรือ 2)
    modalIcon.innerText = '🌟';
    modalTitle.innerText = `เคลียร์ ${stageData[currentStageIdx].title}!`;
    modalDesc.innerText = 'ยอดเยี่ยมมาก! คุณไขปริศนาเบาะแสครบถ้วนในด่านนี้';
    nextStageBtn.innerText = '➡️ ไปด่านถัดไป';
  } else {
    // เล่นจบครบทุกด่านแล้ว (ด่านที่ 3)
    modalIcon.innerText = '🏆';
    modalTitle.innerText = 'ยินดีด้วย! คุณคือสุดยอดนักสืบไวยากรณ์';
    modalDesc.innerText = 'คุณพิชิตครบทั้ง 3 ด่านเรียบร้อยแล้ว! กดปุ่มด้านล่างเพื่อไปยังบทเรียนถัดไป';
    nextStageBtn.innerText = '➡️ ไปบทเรียนถัดไป';
  }

  stageEndModal.classList.add('active');
}

// Replay Current Stage
function replayCurrentStage() {
  stageEndModal.classList.remove('active');
  loadStage(currentStageIdx);
}

// =============================================================
// 🚀 ระบบนำทางเมื่อจบด่าน / จบเกม
// =============================================================
function goToNextStage() {
  stageEndModal.classList.remove('active');

  if (currentStageIdx < stageData.length - 1) {
    // กรณีที่ยังไม่ครบด่านสุดท้าย -> โหลดด่านถัดไปในเกม
    loadStage(currentStageIdx + 1);
  } else {
    // กรณีเล่นจบครบทุกด่านแล้ว (ครบ 3 ด่าน)

    // 1. ส่งสัญญาณ postMessage ไปยังระบบเว็บหลัก (กรณีนำเกมไปฝังผ่าน iframe)
    if (window.parent && window.parent !== window) {
      window.parent.postMessage({
        type: 'LESSON_COMPLETE',
        action: 'NEXT_LESSON',
        lessonId: 'detective-grammar-quest',
        status: 'PASS',
        score: stageScore
      }, '*');
    }

    // 2. สั่งเปลี่ยนหน้าเว็บไปยัง URL หน้าถัดไปที่กำหนดไว้ใน NEXT_PAGE_URL
    if (NEXT_PAGE_URL && NEXT_PAGE_URL.trim() !== "") {
      window.location.href = NEXT_PAGE_URL;
    } else {
      alert('🎉 คุณเล่นจบครบทุกด่านเรียบร้อยแล้ว!');
    }
  }
}

// Start Game on Page Load
window.onload = () => {
  updateLivesDisplay();
  loadStage(0);
};