// =============================================================
// ⚙️ การตั้งค่า URL ลิงก์ไปหน้าถัดไปเมื่อทำครบ
// =============================================================
const NEXT_PAGE_URL = "quiz1_p1_eng4.html";
const MAX_LIVES = 3;

// Database of 6 Simple Sentence Questions & Answers
const questionsData = [
  { id: 1, thai: "พ่อของฉันเป็นหมอ", english: "My father is a doctor.", icon: "👨‍⚕️" },
  { id: 2, thai: "นั่นคือสีแดง", english: "That is red.", icon: "🔴" },
  { id: 3, thai: "นี่คือแอปเปิล", english: "This is an apple.", icon: "🍎" },
  { id: 4, thai: "แมวกำลังนอนหลับ", english: "The cat is sleeping.", icon: "🐱" },
  { id: 5, thai: "พระอาทิตย์ส่องแสง", english: "The sun is shining.", icon: "☀️" },
  { id: 6, thai: "สุนัขตัวนี้วิ่งเร็ว", english: "The dog runs fast.", icon: "🐶" }
];

// Game Logic State Variables
let selectedLeft = null;
let matchedPairs = new Map(); // Stores id -> id pairs
let leftItems = [];
let rightItems = [];
let score = 0;
let lives = MAX_LIVES;
let isBoardLocked = false;

const gameOverModal = document.getElementById('gameOverModal');
const livesDisplay = document.getElementById('livesDisplay');

function updateLivesDisplay() {
  livesDisplay.innerText = `${'❤️'.repeat(lives)}${'🖤'.repeat(MAX_LIVES - lives)}`;
  livesDisplay.setAttribute('aria-label', `ชีวิต ${lives} จาก ${MAX_LIVES}`);
}

// Initialize & Render Board
function initGame() {
  const leftCol = document.getElementById('leftColumn');
  const rightCol = document.getElementById('rightColumn');
  const svg = document.getElementById('svgOverlay');

  leftCol.innerHTML = '';
  rightCol.innerHTML = '';
  svg.innerHTML = '';

  selectedLeft = null;
  matchedPairs.clear();
  score = 0;
  lives = MAX_LIVES;
  isBoardLocked = false;
  gameOverModal.classList.remove('active');
  updateLivesDisplay();
  updateStats();

  // Shuffle Questions for left and right columns
  leftItems = [...questionsData];
  rightItems = shuffleArray([...questionsData]);

  // Render Left Cards
  leftItems.forEach(item => {
    const card = document.createElement('div');
    card.className = 'match-card';
    card.dataset.id = item.id;
    card.dataset.side = 'left';

    card.innerHTML = `
      <span class="card-icon">${item.icon}</span>
      <span class="card-text">${item.thai}</span>
      <div class="dot-handle"></div>
    `;

    card.addEventListener('click', () => handleLeftClick(card, item));
    leftCol.appendChild(card);
  });

  // Render Right Cards
  rightItems.forEach(item => {
    const card = document.createElement('div');
    card.className = 'match-card';
    card.dataset.id = item.id;
    card.dataset.side = 'right';

    card.innerHTML = `
      <div class="dot-handle"></div>
      <span class="card-text">${item.english}</span>
    `;

    card.addEventListener('click', () => handleRightClick(card, item));
    rightCol.appendChild(card);
  });
}

// Handle Click on Left Item
function handleLeftClick(cardEl, item) {
  if (isBoardLocked || matchedPairs.has(item.id)) return;

  // Clear previous selection
  document.querySelectorAll('.left-column .match-card').forEach(c => c.classList.remove('selected'));

  selectedLeft = { cardEl, item };
  cardEl.classList.add('selected');
}

// Handle Click on Right Item
function handleRightClick(rightCardEl, rightItem) {
  if (isBoardLocked || !selectedLeft) return;
  if (Array.from(matchedPairs.values()).includes(rightItem.id)) return; // Skip if already matched

  const leftItem = selectedLeft.item;
  const leftCardEl = selectedLeft.cardEl;

  // Check Match
  if (leftItem.id === rightItem.id) {
    // Correct Pair Match!
    matchedPairs.set(leftItem.id, rightItem.id);
    score += 10;

    leftCardEl.classList.remove('selected');
    leftCardEl.classList.add('matched');
    rightCardEl.classList.add('matched');

    // Draw Permanent Line
    drawLine(leftCardEl, rightCardEl, '#22C55E');
    selectedLeft = null;

    updateStats();

    // Check if Game Complete
    if (matchedPairs.size === questionsData.length) {
      setTimeout(showCompletionModal, 600);
    }
  } else {
    lives--;
    updateLivesDisplay();
    selectedLeft.cardEl.classList.remove('selected');
    selectedLeft = null;
    isBoardLocked = true;
    rightCardEl.style.borderColor = '#EF4444';
    setTimeout(() => {
      rightCardEl.style.borderColor = '';
      isBoardLocked = false;
      if (lives === 0) {
        gameOverModal.classList.add('active');
      }
    }, 600);
  }
}

// Draw Connecting Line on SVG Canvas Overlay
function drawLine(leftEl, rightEl, color = '#22C55E') {
  const svg = document.getElementById('svgOverlay');
  const boardRect = document.getElementById('boardWrapper').getBoundingClientRect();

  const leftDot = leftEl.querySelector('.dot-handle').getBoundingClientRect();
  const rightDot = rightEl.querySelector('.dot-handle').getBoundingClientRect();

  const x1 = leftDot.left + leftDot.width / 2 - boardRect.left;
  const y1 = leftDot.top + leftDot.height / 2 - boardRect.top;

  const x2 = rightDot.left + rightDot.width / 2 - boardRect.left;
  const y2 = rightDot.top + rightDot.height / 2 - boardRect.top;

  const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
  line.setAttribute('x1', x1);
  line.setAttribute('y1', y1);
  line.setAttribute('x2', x2);
  line.setAttribute('y2', y2);
  line.setAttribute('stroke', color);
  line.setAttribute('stroke-width', '4');
  line.setAttribute('stroke-linecap', 'round');

  svg.appendChild(line);
}

// Update UI Stats Counter
function updateStats() {
  document.getElementById('matchProgress').innerText = `${matchedPairs.size} / ${questionsData.length}`;
  document.getElementById('scoreText').innerText = `${score} คะแนน`;
}

// Shuffle Utility
function shuffleArray(arr) {
  const array = [...arr];
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

// Reset Game Board
function resetBoard() {
  document.getElementById('resultModal').classList.remove('active');
  initGame();
}

// Show End Game Modal
function showCompletionModal() {
  document.getElementById('resultModal').classList.add('active');
}

// =============================================================
// 🚀 ระบบลิงก์ไปยังหน้าถัดไปเมื่อคลิกปุ่ม
// =============================================================
function goToNextPage() {
  // 1. ส่งสัญญาณ postMessage ไปยังเว็บแม่ (กรณีนำไปฝังใน iframe/LMS)
  if (window.parent && window.parent !== window) {
    window.parent.postMessage({
      type: 'LESSON_COMPLETE',
      action: 'NEXT_LESSON',
      lessonId: 'sentence-matching-eng4',
      status: 'PASS',
      score: score
    }, '*');
  }

  // 2. สั่งเปลี่ยนหน้าไปยัง URL หน้าถัดไป
  if (NEXT_PAGE_URL && NEXT_PAGE_URL.trim() !== "") {
    window.location.href = NEXT_PAGE_URL;
  } else {
    alert('🎉 ยินดีด้วย! คุณเรียนจบบทเรียนนี้แล้ว');
  }
}

// Load Game on Startup
window.onload = () => {
  updateLivesDisplay();
  initGame();
};

// Redraw Lines on Window Resize for responsiveness
window.onresize = () => {
  if (matchedPairs.size > 0) {
    const svg = document.getElementById('svgOverlay');
    svg.innerHTML = '';
    matchedPairs.forEach((rightId, leftId) => {
      const leftEl = document.querySelector(`.left-column .match-card[data-id="${leftId}"]`);
      const rightEl = document.querySelector(`.right-column .match-card[data-id="${rightId}"]`);
      if (leftEl && rightEl) {
        drawLine(leftEl, rightEl, '#22C55E');
      }
    });
  }
};