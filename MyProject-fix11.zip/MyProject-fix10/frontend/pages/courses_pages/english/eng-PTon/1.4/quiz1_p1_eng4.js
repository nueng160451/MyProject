const questions = [
  {
    question: "My father ___ a doctor.",
    options: ["am", "is", "are"],
    answer: 1
  },
  {
    question: "Which sentence means 'พ่อของฉันเป็นหมอ'?",
    options: ["My father is a doctor.", "My father are a doctor.", "My father is doctoring."],
    answer: 0
  },
  {
    question: "This is ___ apple.",
    options: ["a", "an", "are"],
    answer: 1
  },
  {
    question: "Which sentence means 'นั่นคือสีแดง'?",
    options: ["This is an apple.", "That is red.", "The sun is shining."],
    answer: 1
  },
  {
    question: "Choose the correct sentence.",
    options: ["The cat sleeping.", "The cat is sleeping.", "The cat are sleep."],
    answer: 1
  },
  {
    question: "In 'The cat is sleeping', what does 'is sleeping' tell us?",
    options: ["The cat's name", "An action happening now", "A color"],
    answer: 1
  },
  {
    question: "Choose the correct form for an action happening now.",
    options: ["Subject + is + verb-ing", "Subject + are + verb-s", "Subject + am + verb-ed"],
    answer: 0
  },
  {
    question: "Complete the sentence: The sun is ___.",
    options: ["shine", "shines", "shining"],
    answer: 2
  },
  {
    question: "Choose the correct sentence for a general fact.",
    options: ["The dog runs fast.", "The dog is run fast.", "The dog are running fast every day."],
    answer: 0
  },
  {
    question: "Why do we say 'The dog runs'?",
    options: ["The dog is plural.", "Add -s to the verb for he/she/it or a singular noun.", "All verbs end in -s."],
    answer: 1
  },
  {
    question: "Which sentence describes an action happening right now?",
    options: ["The dog runs fast.", "The dog is running fast.", "The dog run fast."],
    answer: 1
  },
  {
    question: "Match 'แมวกำลังนอนหลับ' with the English sentence.",
    options: ["The cat is sleeping.", "The cat sleeps fast.", "The cat is shining."],
    answer: 0
  }
];

let currentQuestion = 0;
let score = 0;
let canAnswer = true;

const questionNumberEl = document.getElementById('questionNumber');
const scoreCountEl = document.getElementById('scoreCount');
const questionTextEl = document.getElementById('questionText');
const optionsContainerEl = document.getElementById('optionsContainer');
const feedbackEl = document.getElementById('feedback');
const quizBox = document.getElementById('quizBox');
const resultBox = document.getElementById('resultBox');
const finalScoreEl = document.getElementById('finalScore');

function loadQuestion() {
  canAnswer = true;
  const question = questions[currentQuestion];
  questionNumberEl.innerText = `ข้อที่ ${currentQuestion + 1} / ${questions.length}`;
  scoreCountEl.innerText = `คะแนน: ${score}`;
  questionTextEl.innerText = question.question;
  feedbackEl.innerText = '';
  feedbackEl.className = 'feedback';
  optionsContainerEl.innerHTML = '';

  question.options.forEach((option, index) => {
    const button = document.createElement('button');
    button.className = 'option-btn';
    button.type = 'button';
    button.innerText = option;
    button.addEventListener('click', () => selectOption(index, button));
    optionsContainerEl.appendChild(button);
  });
}

function selectOption(selectedIndex, selectedButton) {
  if (!canAnswer) return;
  canAnswer = false;

  const correctIndex = questions[currentQuestion].answer;
  const optionButtons = optionsContainerEl.querySelectorAll('.option-btn');
  optionButtons.forEach(button => {
    button.disabled = true;
  });

  if (selectedIndex === correctIndex) {
    score++;
    selectedButton.classList.add('correct');
    feedbackEl.innerText = 'ถูกต้อง เก่งมาก! ✅';
    feedbackEl.classList.add('correct');
    scoreCountEl.innerText = `คะแนน: ${score}`;
  } else {
    selectedButton.classList.add('incorrect');
    optionButtons[correctIndex].classList.add('correct');
    feedbackEl.innerText = 'ยังไม่ถูก ลองทบทวนรูปประโยคข้อนี้ไว้นะ';
    feedbackEl.classList.add('incorrect');
  }

  window.setTimeout(() => {
    currentQuestion++;
    if (currentQuestion < questions.length) {
      loadQuestion();
    } else {
      showResult();
    }
  }, 1000);
}

function showResult() {
  quizBox.hidden = true;
  resultBox.hidden = false;
  finalScoreEl.innerText = `คุณได้ ${score} จาก ${questions.length} คะแนน`;
}

function restartQuiz() {
  currentQuestion = 0;
  score = 0;
  resultBox.hidden = true;
  quizBox.hidden = false;
  loadQuestion();
}

document.getElementById('restartButton').addEventListener('click', restartQuiz);
loadQuestion();