
const questions = [
  {
    id: 1,
    targetSentence: ["The", "boy", "is", "eating", "an", "apple."],
    options: ["The", "boy", "is", "eating", "an", "apple.", "Banana", "Girl", "drinking"],
    svg: `<svg viewBox="0 0 300 180" width="100%" height="100%">
      <rect width="300" height="180" fill="#E0F2FE"/>
      <circle cx="150" cy="190" r="120" fill="#BAE6FD"/>
      <!-- Boy Head -->
      <circle cx="150" cy="75" r="32" fill="#FDBA74"/>
      <!-- Hair -->
      <path d="M120 70 Q150 35 180 70 Q160 50 120 70 Z" fill="#451A03"/>
      <!-- Eyes -->
      <circle cx="140" cy="72" r="3.5" fill="#1E293B"/>
      <circle cx="160" cy="72" r="3.5" fill="#1E293B"/>
      <!-- Smile -->
      <path d="M142 85 Q150 95 158 85" stroke="#1E293B" stroke-width="3" fill="none"/>
      <!-- Body/Shirt -->
      <path d="M122 107 Q150 100 178 107 L190 160 L110 160 Z" fill="#3B82F6"/>
      <!-- Apple in hand -->
      <circle cx="178" cy="98" r="14" fill="#EF4444"/>
      <path d="M178 84 Q182 80 180 76" stroke="#15803D" stroke-width="2.5" fill="none"/>
      <path d="M180 78 Q186 76 184 82 Z" fill="#22C55E"/>
    </svg>`
  },
  {
    id: 2,
    targetSentence: ["The", "sun", "is", "shining", "in", "the", "sky."],
    options: ["The", "sun", "is", "shining", "in", "the", "sky.", "moon", "cloud", "rain"],
    svg: `<svg viewBox="0 0 300 180" width="100%" height="100%">
      <rect width="300" height="180" fill="#BAE6FD"/>
      <!-- Green Field -->
      <path d="M0 140 Q150 120 300 140 L300 180 L0 180 Z" fill="#4ADE80"/>
      <!-- Sun -->
      <circle cx="150" cy="70" r="35" fill="#FACC15"/>
      <!-- Sun Rays -->
      <g stroke="#FACC15" stroke-width="4" stroke-linecap="round">
        <line x1="150" y1="20" x2="150" y2="28" />
        <line x1="150" y1="112" x2="150" y2="120" />
        <line x1="100" y1="70" x2="108" y2="70" />
        <line x1="192" y1="70" x2="200" y2="70" />
        <line x1="115" y1="35" x2="121" y2="41" />
        <line x1="179" y1="99" x2="185" y2="105" />
        <line x1="115" y1="105" x2="121" y2="99" />
        <line x1="179" y1="41" x2="185" y2="35" />
      </g>
      <!-- Sun Face -->
      <circle cx="140" cy="65" r="3" fill="#78350F"/>
      <circle cx="160" cy="65" r="3" fill="#78350F"/>
      <path d="M142 78 Q150 86 158 78" stroke="#78350F" stroke-width="3" fill="none"/>
    </svg>`
  },
  {
    id: 3,
    targetSentence: ["A", "cat", "is", "sleeping", "on", "the", "mat."],
    options: ["A", "cat", "is", "sleeping", "on", "the", "mat.", "dog", "running", "chair"],
    svg: `<svg viewBox="0 0 300 180" width="100%" height="100%">
      <rect width="300" height="180" fill="#FEF3C7"/>
      <!-- Mat -->
      <ellipse cx="150" cy="120" rx="90" ry="30" fill="#F43F5E"/>
      <ellipse cx="150" cy="120" rx="80" ry="24" fill="#FB7185"/>
      <!-- Sleeping Cat -->
      <ellipse cx="150" cy="112" rx="35" ry="22" fill="#F97316"/>
      <!-- Head -->
      <circle cx="125" cy="108" r="18" fill="#F97316"/>
      <!-- Ears -->
      <polygon points="115,95 122,82 128,93" fill="#EA580C"/>
      <polygon points="126,93 134,84 138,96" fill="#EA580C"/>
      <!-- Sleeping Eyes (Zzz) -->
      <path d="M118 108 Q122 112 126 108" stroke="#7C2D12" stroke-width="2" fill="none"/>
      <!-- Tail -->
      <path d="M180 115 Q195 100 185 90" stroke="#F97316" stroke-width="6" fill="none" stroke-linecap="round"/>
      <!-- ZZZ -->
      <text x="100" y="80" fill="#9A3412" font-weight="bold" font-size="16">Z</text>
      <text x="90" y="65" fill="#9A3412" font-weight="bold" font-size="12">z</text>
    </svg>`
  },
  {
    id: 4,
    targetSentence: ["A", "small", "dog", "is", "running", "fast."],
    options: ["A", "small", "dog", "is", "running", "fast.", "big", "cat", "slow"],
    svg: `<svg viewBox="0 0 300 180" width="100%" height="100%">
      <rect width="300" height="180" fill="#DCFCE7"/>
      <path d="M0 130 Q150 110 300 130 L300 180 L0 180 Z" fill="#86EFAC"/>
      <!-- Dog Body -->
      <ellipse cx="150" cy="105" rx="28" ry="16" fill="#A16207"/>
      <!-- Head -->
      <circle cx="180" cy="90" r="16" fill="#A16207"/>
      <!-- Snout -->
      <ellipse cx="192" cy="94" rx="8" ry="6" fill="#CA8A04"/>
      <circle cx="196" cy="92" r="3" fill="#1E293B"/>
      <!-- Ear -->
      <path d="M172 80 Q165 95 174 100" fill="#713F12"/>
      <!-- Legs (Running posture) -->
      <line x1="135" y1="115" x2="120" y2="130" stroke="#713F12" stroke-width="5" stroke-linecap="round"/>
      <line x1="145" y1="118" x2="138" y2="135" stroke="#713F12" stroke-width="5" stroke-linecap="round"/>
      <line x1="160" y1="118" x2="172" y2="135" stroke="#713F12" stroke-width="5" stroke-linecap="round"/>
      <line x1="170" y1="115" x2="188" y2="128" stroke="#713F12" stroke-width="5" stroke-linecap="round"/>
      <!-- Tail -->
      <path d="M124 102 Q110 95 115 85" stroke="#A16207" stroke-width="4" fill="none" stroke-linecap="round"/>
      <!-- Speed lines -->
      <line x1="90" y1="100" x2="105" y2="100" stroke="#94A3B8" stroke-width="3" stroke-linecap="round"/>
      <line x1="80" y1="110" x2="100" y2="110" stroke="#94A3B8" stroke-width="3" stroke-linecap="round"/>
    </svg>`
  },
  {
    id: 5,
    targetSentence: ["She", "is", "drinking", "a", "glass", "of", "milk."],
    options: ["She", "is", "drinking", "a", "glass", "of", "milk.", "He", "eating", "water"],
    svg: `<svg viewBox="0 0 300 180" width="100%" height="100%">
      <rect width="300" height="180" fill="#FCE7F3"/>
      <!-- Girl Head -->
      <circle cx="140" cy="75" r="30" fill="#FDBA74"/>
      <!-- Hair (Pigtails) -->
      <path d="M110 75 Q140 35 170 75 Q140 55 110 75 Z" fill="#92400E"/>
      <circle cx="105" cy="80" r="12" fill="#92400E"/>
      <circle cx="175" cy="80" r="12" fill="#92400E"/>
      <!-- Eye -->
      <circle cx="132" cy="72" r="3" fill="#1E293B"/>
      <!-- Glass of Milk -->
      <rect x="155" y="80" width="22" height="32" rx="3" fill="#E2E8F0" opacity="0.8" stroke="#94A3B8" stroke-width="2"/>
      <rect x="157" y="86" width="18" height="24" fill="#FFFFFF"/>
      <!-- Straw -->
      <line x1="166" y1="95" x2="145" y2="78" stroke="#EF4444" stroke-width="3" stroke-linecap="round"/>
      <!-- Shirt -->
      <path d="M115 105 Q140 100 165 105 L172 160 L108 160 Z" fill="#EC4899"/>
    </svg>`
  }
];

// Game State
let currentIdx = 0;
let score = 0;
let questionAnswered = false;

// Initialize Elements
const sceneBox = document.getElementById('sceneBox');
const builderZone = document.getElementById('builderZone');
const wordBank = document.getElementById('wordBank');
const levelTag = document.getElementById('levelTag');
const scoreTag = document.getElementById('scoreTag');
const progressFill = document.getElementById('progressFill');
const feedback = document.getElementById('feedback');
const checkBtn = document.getElementById('checkBtn');
const nextBtn = document.getElementById('nextBtn');
const resetBtn = document.getElementById('resetBtn');

// Shuffle Utility
function shuffleArray(array) {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

// Load Question
function loadQuestion() {
  const q = questions[currentIdx];
  questionAnswered = false;

  // Reset UI
  feedback.className = 'feedback';
  feedback.style.display = 'none';
  checkBtn.style.display = 'inline-flex';
  nextBtn.style.display = 'none';
  resetBtn.disabled = false;

  // Header & Progress
  levelTag.innerText = `ข้อที่ ${currentIdx + 1}/${questions.length}`;
  scoreTag.innerText = `⭐ ดาวสะสม: ${score}`;
  progressFill.style.width = `${((currentIdx + 1) / questions.length) * 100}%`;

  // Render SVG
  sceneBox.innerHTML = q.svg;

  // Clear Zones
  builderZone.innerHTML = '';
  wordBank.innerHTML = '';

  // Shuffle Options
  const shuffledOptions = shuffleArray(q.options);

  // Render Options in Word Bank
  shuffledOptions.forEach((word, index) => {
    const chip = createWordChip(word, index);
    wordBank.appendChild(chip);
  });

}

// Create Word Chip Element
function createWordChip(word, id) {
  const chip = document.createElement('button');
  chip.type = 'button';
  chip.className = 'word-chip';
  chip.innerText = word;
  chip.dataset.word = word;
  chip.dataset.id = id;
  chip.draggable = true;

  // Click Handler
  chip.addEventListener('click', () => {
    if (questionAnswered) return;

    if (chip.parentElement === wordBank) {
      moveToZone(chip);
    } else {
      moveToBank(chip);
    }
  });

  // Drag Events
  chip.addEventListener('dragstart', (e) => {
    if (questionAnswered || !e.dataTransfer) {
      e.preventDefault();
      return;
    }

    e.dataTransfer.setData('text/plain', chip.dataset.id);
    chip.classList.add('dragging');
  });

  chip.addEventListener('dragend', () => {
    chip.classList.remove('dragging');
  });

  return chip;
}

// Move chip to sentence builder zone
function moveToZone(chip) {
  chip.classList.add('placed');
  builderZone.appendChild(chip);
}

// Move chip back to word bank
function moveToBank(chip) {
  chip.classList.remove('placed');
  wordBank.appendChild(chip);
}

// Drag & Drop Listeners
function setupDragAndDrop() {
  builderZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    builderZone.classList.add('drag-over');
  });

  builderZone.addEventListener('dragleave', () => {
    builderZone.classList.remove('drag-over');
  });

  builderZone.addEventListener('drop', (e) => {
    e.preventDefault();
    builderZone.classList.remove('drag-over');
    if (questionAnswered || !e.dataTransfer) return;

    const chipId = e.dataTransfer.getData('text/plain');
    const chip = document.querySelector(`.word-chip[data-id="${chipId}"]`);
    if (chip && chip.parentElement !== builderZone) {
      moveToZone(chip);
    }
  });
}

// Reset Current Question
function resetCurrentQuestion() {
  if (questionAnswered) return;

  const chips = Array.from(builderZone.querySelectorAll('.word-chip'));
  chips.forEach(chip => moveToBank(chip));
  feedback.style.display = 'none';
}

// Check Answer
function checkAnswer() {
  if (questionAnswered) return;

  const currentQ = questions[currentIdx];
  const userChips = Array.from(builderZone.querySelectorAll('.word-chip'));
  const userWords = userChips.map(c => c.dataset.word);

  if (userWords.length === 0) {
    showFeedback('กรุณาลากหรือคลิกเลือกคำศัพท์เพื่อสร้างประโยคก่อนครับ!', 'wrong');
    return;
  }

  const isCorrect = JSON.stringify(userWords) === JSON.stringify(currentQ.targetSentence);

  if (isCorrect) {
    questionAnswered = true;
    score++;
    scoreTag.innerText = `⭐ ดาวสะสม: ${score}`;
    showFeedback('✨ ถูกต้องแล้วครับ! เก่งมากๆ 🎉', 'correct');
    checkBtn.style.display = 'none';
    nextBtn.style.display = 'inline-flex';
    resetBtn.disabled = true;
  } else {
    showFeedback('ยังไม่ถูกต้องครับ ลองสลับตำแหน่งคำศัพท์ดูใหม่อีกครั้งนะ!', 'wrong');
  }
}

function showFeedback(msg, type) {
  feedback.innerText = msg;
  feedback.className = `feedback ${type}`;
}

// Next Question
function nextQuestion() {
  if (!questionAnswered) return;

  currentIdx++;
  if (currentIdx < questions.length) {
    loadQuestion();
  } else {
    showResults();
  }
}

// Show End Game Modal
function showResults() {
  const modal = document.getElementById('resultModal');
  const modalTitle = document.getElementById('modalTitle');
  const modalDesc = document.getElementById('modalDesc');
  const modalIcon = document.getElementById('modalIcon');
  const modalStars = document.getElementById('modalStars');
  const modalScoreText = document.getElementById('modalScoreText');
  const finishBtn = document.getElementById('finishBtn');

  const percentage = (score / questions.length) * 100;
  modalScoreText.innerText = `คะแนนที่ได้: ${score} / ${questions.length}`;

  if (percentage >= 70) {
    modalIcon.innerText = '🏆';
    modalTitle.innerText = 'ยินดีด้วย! คุณผ่านบทเรียนนี้';
    modalStars.innerText = score === 5 ? '⭐⭐⭐' : '⭐⭐';
    modalDesc.innerText = 'คุณมีความสามารถในการสร้างประโยคภาษาอังกฤษได้ดีเยี่ยม!';
    finishBtn.style.display = 'inline-flex';
  } else {
    modalIcon.innerText = '💪';
    modalTitle.innerText = 'พยายามได้ดีมาก!';
    modalStars.innerText = '⭐';
    modalDesc.innerText = 'ลองทบทวนและเล่นอีกครั้งเพื่อสะสมดาวให้ครบนะ!';
    finishBtn.style.display = 'none';
  }

  modal.classList.add('active');
}

// Restart Game
function restartGame() {
  currentIdx = 0;
  score = 0;
  document.getElementById('resultModal').classList.remove('active');
  loadQuestion();
}

// LMS PostMessage Integration
function finishLesson() {
  if (window.parent) {
    window.parent.postMessage({
      type: 'LESSON_COMPLETE',
      lessonId: 'build-a-sentence-1',
      status: 'PASS',
      score: score,
      maxScore: questions.length
    }, '*');
  }
  window.location.href = 'quiz1_p1_eng1.html';
}


setupDragAndDrop();
loadQuestion();