const questions = [
    {
        question: "Put the words in the correct order: (boy / The / is / eating)",
        options: ["The boy is eating.", "Eating the boy is.", "Is eating boy the."],
        answer: 0
    },
    {
        question: "Complete: The boy ___ eating an apple.",
        options: ["are", "is", "am"],
        answer: 1
    },
    {
        question: "Choose the correct article: The boy is eating ___ apple.",
        options: ["a", "an", "the"],
        answer: 1
    },
    {
        question: "Which sentence means 'พระอาทิตย์กำลังส่องแสงอยู่บนท้องฟ้า'?",
        options: [
            "The sun is shining in the sky.",
            "The sun is drinking in the sky.",
            "The moon is shining on the mat."
        ],
        answer: 0
    },
    {
        question: "Complete: The sun is ___ in the sky.",
        options: ["sleeping", "shining", "eating"],
        answer: 1
    },
    {
        question: "Choose the correct article: ___ cat is sleeping on the mat.",
        options: ["A", "An", "Are"],
        answer: 0
    },
    {
        question: "In 'A cat is sleeping', what does 'is sleeping' tell us?",
        options: ["The cat's color", "An action happening now", "A place"],
        answer: 1
    },
    {
        question: "Choose the correct present continuous sentence.",
        options: [
            "A small dog is running fast.",
            "A small dog are running fast.",
            "A small dog running fast."
        ],
        answer: 0
    },
    {
        question: "What does 'on the mat' mean?",
        options: ["ในท้องฟ้า", "บนเสื่อ", "ในแก้วนม"],
        answer: 1
    },
    {
        question: "Which word means 'ดื่ม'?",
        options: ["eat", "sleep", "drink"],
        answer: 2
    },
    {
        question: "Choose the correct article: She is drinking ___ glass of milk.",
        options: ["a", "an", "is"],
        answer: 0
    },
    {
        question: "Which sentence means 'แมวกำลังนอนอยู่บนเสื่อ'?",
        options: [
            "A cat is sleeping on the mat.",
            "A cat is running in the sky.",
            "A dog is eating an apple."
        ],
        answer: 0
    },
    {
        question: "What does 'milk' mean?",
        options: ["แอปเปิล", "นม", "เสื่อ"],
        answer: 1
    },
    {
        question: "Choose the correct sentence.",
        options: [
            "She is drinking milk.",
            "She drinking is milk.",
            "She are drinking milk."
        ],
        answer: 0
    },
    {
        question: "Which sentence correctly uses 'an'?",
        options: [
            "A apple is red.",
            "An apple is red.",
            "An dog is running."
        ],
        answer: 1
    }
];

let currentQuestion = 0;
let score = 0;
let canAnswer = true;

const questionNumberEl = document.getElementById('question-number');
const scoreCountEl = document.getElementById('score-count');
const questionTextEl = document.getElementById('question-text');
const optionsContainerEl = document.getElementById('options-container');
const quizBox = document.getElementById('quiz-box');
const resultBox = document.getElementById('result-box');
const finalScoreEl = document.getElementById('final-score');

loadQuestion();

function loadQuestion() {
    canAnswer = true;
    const question = questions[currentQuestion];
    questionNumberEl.innerText = `ข้อที่ ${currentQuestion + 1} / ${questions.length}`;
    scoreCountEl.innerText = `คะแนน: ${score}`;
    questionTextEl.innerText = question.question;
    optionsContainerEl.innerHTML = '';

    question.options.forEach((option, index) => {
        const button = document.createElement('button');
        button.classList.add('option-btn');
        button.type = 'button';
        button.innerText = option;
        button.addEventListener('click', () => selectOption(index, button));
        optionsContainerEl.appendChild(button);
    });
}

function selectOption(selectedIndex, selectedButton) {
    if (!canAnswer) return;
    canAnswer = false;

    const correctIndex = questions[currentQuestion].answer;
    const optionButtons = optionsContainerEl.querySelectorAll('.option-btn');

    if (selectedIndex === correctIndex) {
        selectedButton.classList.add('correct');
        score++;
        scoreCountEl.innerText = `คะแนน: ${score}`;
    } else {
        selectedButton.classList.add('incorrect');
        optionButtons[correctIndex].classList.add('correct');
    }

    optionButtons.forEach(button => {
        button.disabled = true;
    });

    window.setTimeout(() => {
        currentQuestion++;
        if (currentQuestion < questions.length) {
            loadQuestion();
        } else {
            showResult();
        }
    }, 1000);
}

function showResult() {
    quizBox.classList.add('hidden');
    resultBox.classList.remove('hidden');
    finalScoreEl.innerText = `คุณได้คะแนน ${score} จาก ${questions.length} คะแนน`;
}

function restartQuiz() {
    currentQuestion = 0;
    score = 0;
    resultBox.classList.add('hidden');
    quizBox.classList.remove('hidden');
    loadQuestion();
}
