const questions = [
    {
        question: "The waiter asks, 'What would you like to eat?' What is a suitable answer?",
        options: [
            "I'd like a hamburger, please.",
            "I am great, thank you.",
            "It is five o'clock."
        ],
        answer: 0
    },
    {
        question: "Which phrase politely tells someone what food you want?",
        options: ["I'd like ..., please.", "How are you?", "Goodbye, please."],
        answer: 0
    },
    {
        question: "The waiter asks, 'What would you like to drink?' Choose the best answer.",
        options: [
            "I'd like some orange juice, please.",
            "I'd like to ride a bicycle.",
            "I am eight years old."
        ],
        answer: 0
    },
    {
        question: "What does 'What would you like to eat?' ask about?",
        options: ["A food choice", "How someone feels", "The time"],
        answer: 0
    },
    {
        question: "What kind of answer fits the question 'What would you like to drink?'",
        options: ["A drink", "An animal's color", "A greeting"],
        answer: 0
    },
    {
        question: "Read: 'Fluffy is a small white cat.' What color is Fluffy?",
        options: ["Black", "White", "Yellow"],
        answer: 1
    },
    {
        question: "According to the story, what kind of cat is Fluffy?",
        options: ["A small cat", "A big dog", "A young rabbit"],
        answer: 0
    },
    {
        question: "What does Fluffy like to play with?",
        options: ["A blue ball", "A red car", "A green kite"],
        answer: 0
    },
    {
        question: "What does Fluffy like to drink?",
        options: ["Fresh milk", "Orange juice", "Watermelon juice"],
        answer: 0
    },
    {
        question: "Tim asks Ben, 'How are you today?' Which is a suitable reply?",
        options: [
            "I am great, thank you!",
            "I am eight years old.",
            "I am riding a bicycle."
        ],
        answer: 0
    },
    {
        question: "Where are Tim and Ben?",
        options: ["At the park", "At a restaurant", "At a pet shop"],
        answer: 0
    },
    {
        question: "What is Tim doing at the park?",
        options: ["Flying a kite", "Drinking milk", "Eating a hamburger"],
        answer: 0
    },
    {
        question: "What is Ben riding?",
        options: ["His red bicycle", "A blue ball", "A horse"],
        answer: 0
    },
    {
        question: "How do Tim and Ben feel at the park?",
        options: ["They are having fun.", "They are ordering food.", "They are looking for a cat."],
        answer: 0
    },
    {
        question: "When answering a reading question, what should you do?",
        options: [
            "Find the detail in the passage.",
            "Choose a random answer.",
            "Ignore the passage and guess."
        ],
        answer: 0
    }
];

let currentQuestion = 0;
let score = 0;
let canAnswer = true;
let nextQuestionTimeout = null;

const questionNumberEl = document.getElementById('question-number');
const scoreCountEl = document.getElementById('score-count');
const questionTextEl = document.getElementById('question-text');
const optionsContainerEl = document.getElementById('options-container');
const quizBox = document.getElementById('quiz-box');
const resultBox = document.getElementById('result-box');
const finalScoreEl = document.getElementById('final-score');

loadQuestion();

function loadQuestion() {
    canAnswer = true;
    const question = questions[currentQuestion];
    questionNumberEl.innerText = `ข้อที่ ${currentQuestion + 1} / ${questions.length}`;
    scoreCountEl.innerText = `คะแนน: ${score}`;
    questionTextEl.innerText = question.question;
    optionsContainerEl.innerHTML = '';

    question.options.forEach((option, index) => {
        const button = document.createElement('button');
        button.classList.add('option-btn');
        button.type = 'button';
        button.innerText = option;
        button.addEventListener('click', () => selectOption(index, button));
        optionsContainerEl.appendChild(button);
    });
}

function selectOption(selectedIndex, selectedButton) {
    if (!canAnswer) return;
    canAnswer = false;

    const correctIndex = questions[currentQuestion].answer;
    const optionButtons = optionsContainerEl.querySelectorAll('.option-btn');

    if (selectedIndex === correctIndex) {
        selectedButton.classList.add('correct');
        score++;
        scoreCountEl.innerText = `คะแนน: ${score}`;
    } else {
        selectedButton.classList.add('incorrect');
        optionButtons[correctIndex].classList.add('correct');
    }

    optionButtons.forEach(button => {
        button.disabled = true;
    });

    nextQuestionTimeout = window.setTimeout(() => {
        nextQuestionTimeout = null;
        currentQuestion++;
        if (currentQuestion < questions.length) {
            loadQuestion();
        } else {
            showResult();
        }
    }, 1000);
}

function showResult() {
    quizBox.classList.add('hidden');
    resultBox.classList.remove('hidden');
    finalScoreEl.innerText = `คุณได้คะแนน ${score} จาก ${questions.length} คะแนน`;
}

function restartQuiz() {
    if (nextQuestionTimeout !== null) {
        window.clearTimeout(nextQuestionTimeout);
        nextQuestionTimeout = null;
    }
    currentQuestion = 0;
    score = 0;
    resultBox.classList.add('hidden');
    quizBox.classList.remove('hidden');
    loadQuestion();
}
