const NEXT_PAGE_URL = "quiz1_p2_eng4.html";

const scenesData = [
  {
    sceneId: 0,
    title: "1. ร้านอาหาร 🍕",
    sceneNameText: "ฉากที่ 1: My Little Restaurant",
    svgIllustration: `<svg viewBox="0 0 400 180" width="100%" height="100%">
      <rect width="400" height="180" fill="#FEF3C7"/>
      <path d="M 80 120 L 320 120 L 340 180 L 60 180 Z" fill="#B45309"/>
      <circle cx="290" cy="65" r="22" fill="#FDBA74"/>
      <path d="M 270 90 L 310 90 L 315 140 L 265 140 Z" fill="#0284C7"/>
      <circle cx="110" cy="75" r="22" fill="#FDBA74"/>
      <path d="M 90 100 L 130 100 L 135 140 L 85 140 Z" fill="#16A34A"/>
      <ellipse cx="200" cy="125" rx="18" ry="8" fill="#D97706"/>
      <ellipse cx="200" cy="122" rx="16" ry="4" fill="#EF4444"/>
    </svg>`,
    questions: [
      {
        speaker: "👨‍🍳 Waiter (พนักงานร้านอาหาร):",
        passage: "Hello! Welcome to My Little Restaurant. What would you like to eat?",
        question: "เลือกประโยคตอบพนักงานเพื่อสั่งอาหารให้เหมาะสม:",
        options: [
          { text: "I'd like a hamburger, please.", isCorrect: true },
          { text: "Yes, I am fine.", isCorrect: false },
          { text: "It is five o'clock.", isCorrect: false }
        ],
        explanation: "เมื่อถูกถามว่า What would you like to eat? ให้ตอบสิ่งที่ต้องการด้วย I'd like..."
      },
      {
        speaker: "👨‍🍳 Waiter (พนักงานร้านอาหาร):",
        passage: "Great choice! And what would you like to drink?",
        question: "เลือกประโยคสั่งเครื่องดื่มให้เหมาะสม:",
        options: [
          { text: "I like playing football.", isCorrect: false },
          { text: "I'd like some orange juice, please.", isCorrect: true },
          { text: "No, I am a doctor.", isCorrect: false }
        ],
        explanation: "คำถาม What would you like to drink? ถามถึงเครื่องดื่ม จึงตอบชื่อเครื่องดื่มที่ต้องการ"
      }
    ]
  },
  {
    sceneId: 1,
    title: "2. ร้านสัตว์เลี้ยง 🐱",
    sceneNameText: "ฉากที่ 2: At the Pet Shop",
    svgIllustration: `<svg viewBox="0 0 400 180" width="100%" height="100%">
      <rect width="400" height="180" fill="#E0F2FE"/>
      <rect x="30" y="40" width="340" height="120" rx="10" fill="#BAE6FD" stroke="#0284C7" stroke-width="3"/>
      <ellipse cx="200" cy="115" rx="30" ry="20" fill="#FFFFFF" stroke="#94A3B8" stroke-width="2"/>
      <circle cx="175" cy="105" r="16" fill="#FFFFFF" stroke="#94A3B8" stroke-width="2"/>
      <polygon points="165,95 172,82 178,94" fill="#F472B6"/>
      <polygon points="176,94 182,84 188,96" fill="#F472B6"/>
      <circle cx="170" cy="105" r="2.5" fill="#1E293B"/>
      <circle cx="180" cy="105" r="2.5" fill="#1E293B"/>
      <circle cx="245" cy="122" r="10" fill="#2563EB"/>
    </svg>`,
    questions: [
      {
        speaker: "📖 Reading Passage (อ่านเรื่องสั้น):",
        passage: "This is Fluffy. It is a small white cat. Fluffy likes to play with a blue ball and drink fresh milk.",
        question: "From the story, what color is Fluffy?",
        options: [
          { text: "Black", isCorrect: false },
          { text: "White", isCorrect: true },
          { text: "Yellow", isCorrect: false }
        ],
        explanation: "อ่านรายละเอียดในเรื่อง: Fluffy เป็นแมวสีขาว (a small white cat)"
      },
      {
        speaker: "📖 Reading Passage (อ่านเรื่องสั้น):",
        passage: "This is Fluffy. It is a small white cat. Fluffy likes to play with a blue ball and drink fresh milk.",
        question: "What does Fluffy like to play with?",
        options: [
          { text: "A blue ball", isCorrect: true },
          { text: "A red car", isCorrect: false },
          { text: "A green kite", isCorrect: false }
        ],
        explanation: "เนื้อเรื่องบอกว่า Fluffy likes to play with a blue ball."
      }
    ]
  },
  {
    sceneId: 2,
    title: "3. สวนสาธารณะ 🌳",
    sceneNameText: "ฉากที่ 3: Fun Day at the Park",
    svgIllustration: `<svg viewBox="0 0 400 180" width="100%" height="100%">
      <rect width="400" height="120" fill="#BAE6FD"/>
      <path d="M 0 120 Q 200 100 400 120 L 400 180 L 0 180 Z" fill="#86EFAC"/>
      <circle cx="350" cy="40" r="20" fill="#FACC15"/>
      <rect x="50" y="70" width="20" height="70" fill="#78350F"/>
      <circle cx="60" cy="65" r="35" fill="#22C55E"/>
      <circle cx="180" cy="115" r="14" fill="#FDBA74"/>
      <path d="M 170 130 L 190 130 L 195 165 L 165 165 Z" fill="#EF4444"/>
      <polygon points="260,30 275,45 260,60 245,45" fill="#F59E0B"/>
      <line x1="180" y1="110" x2="260" y2="45" stroke="#64748B" stroke-width="1.5" stroke-dasharray="3,3"/>
    </svg>`,
    questions: [
      {
        speaker: "👦 Tim (บทสนทนาทักทาย):",
        passage: "Hi Ben! How are you today?",
        question: "ถ้าคุณเป็น Ben ควรตอบคำถาม How are you? อย่างไร?",
        options: [
          { text: "I am eight years old.", isCorrect: false },
          { text: "I am great, thank you!", isCorrect: true },
          { text: "Goodbye, see you later.", isCorrect: false }
        ],
        explanation: "How are you? เป็นคำถามถามสารทุกข์สุกดิบ จึงตอบความรู้สึก เช่น I am great, thank you!"
      },
      {
        speaker: "📖 Reading Passage (อ่านเรื่องสั้น):",
        passage: "Tim and Ben are at the park. Tim is flying a kite. Ben is riding his red bicycle. They are having fun!",
        question: "What is Ben doing at the park?",
        options: [
          { text: "Eating pizza", isCorrect: false },
          { text: "Flying a kite", isCorrect: false },
          { text: "Riding his red bicycle", isCorrect: true }
        ],
        explanation: "อ่านประโยคในเรื่อง: Ben is riding his red bicycle."
      }
    ]
  }
];

let currentSceneIdx = 0;
let currentQuestionIdx = 0;
let score = 0;
let isAnswerLocked = false;
let nextQuestionTimeout = null;

function initGame() {
  if (nextQuestionTimeout !== null) {
    window.clearTimeout(nextQuestionTimeout);
    nextQuestionTimeout = null;
  }

  currentSceneIdx = 0;
  currentQuestionIdx = 0;
  score = 0;
  isAnswerLocked = false;
  document.getElementById('resultModal').classList.remove('active');
  loadQuestion();
}

function loadQuestion() {
  const scene = scenesData[currentSceneIdx];
  const question = scene.questions[currentQuestionIdx];

  scenesData.forEach((item, index) => {
    const tab = document.getElementById(`tab-${index}`);
    tab.className = index === currentSceneIdx
      ? "tab-item active"
      : index < currentSceneIdx
        ? "tab-item"
        : "tab-item locked";
  });

  document.getElementById('sceneTitleText').innerText = scene.sceneNameText;
  document.getElementById('questionProgress').innerText =
    `${currentQuestionIdx + 1} / ${scene.questions.length}`;
  document.getElementById('scoreText').innerText = `${score} คะแนน`;
  document.getElementById('illustrationBox').innerHTML = scene.svgIllustration;
  document.getElementById('speakerTag').innerText = question.speaker;
  document.getElementById('passageText').innerText = question.passage;
  document.getElementById('questionText').innerText = question.question;

  const optionsGrid = document.getElementById('optionsGrid');
  optionsGrid.innerHTML = '';
  const feedbackBanner = document.getElementById('feedbackBanner');
  feedbackBanner.innerText = '';
  feedbackBanner.className = 'feedback-banner';
  isAnswerLocked = false;

  question.options.forEach(option => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'option-btn';
    button.innerText = option.text;
    button.addEventListener('click', () => handleSelectOption(button, option, question));
    optionsGrid.appendChild(button);
  });
}

function handleSelectOption(selectedButton, option, question) {
  if (isAnswerLocked) return;
  isAnswerLocked = true;

  const feedbackBanner = document.getElementById('feedbackBanner');
  const optionButtons = document.querySelectorAll('.option-btn');
  optionButtons.forEach(button => {
    button.disabled = true;
  });

  if (option.isCorrect) {
    selectedButton.classList.add('correct');
    score += 10;
    document.getElementById('scoreText').innerText = `${score} คะแนน`;
    feedbackBanner.innerText = `✨ ถูกต้อง! ${question.explanation}`;
    feedbackBanner.className = 'feedback-banner correct';
  } else {
    selectedButton.classList.add('wrong');
    feedbackBanner.innerText = `❌ ยังไม่ถูกต้อง! ${question.explanation}`;
    feedbackBanner.className = 'feedback-banner wrong';

    const correctIndex = question.options.findIndex(item => item.isCorrect);
    if (correctIndex >= 0 && optionButtons[correctIndex]) {
      optionButtons[correctIndex].classList.add('correct');
    }
  }

  nextQuestionTimeout = window.setTimeout(() => {
    nextQuestionTimeout = null;
    const currentScene = scenesData[currentSceneIdx];
    currentQuestionIdx++;

    if (currentQuestionIdx < currentScene.questions.length) {
      loadQuestion();
      return;
    }

    currentSceneIdx++;
    currentQuestionIdx = 0;
    if (currentSceneIdx < scenesData.length) {
      loadQuestion();
    } else {
      showCompletionModal();
    }
  }, 1800);
}

function resetGame() {
  initGame();
}

function showCompletionModal() {
  const maxScore = scenesData.reduce((total, scene) => total + scene.questions.length * 10, 0);
  document.getElementById('modalScoreText').innerText =
    `คะแนนรวมทั้งหมด: ${score} / ${maxScore} คะแนน`;
  document.getElementById('modalStars').innerText =
    score === maxScore ? '⭐⭐⭐' : score >= maxScore * 0.6 ? '⭐⭐' : '⭐';
  document.getElementById('modalDesc').innerText =
    `ตอบถูก ${score / 10} จาก ${maxScore / 10} ข้อ`;
  document.getElementById('resultModal').classList.add('active');
}

function goToNextPage() {
  const maxScore = scenesData.reduce((total, scene) => total + scene.questions.length * 10, 0);
  if (window.parent && window.parent !== window) {
    window.parent.postMessage({
      type: 'LESSON_COMPLETE',
      action: 'NEXT_LESSON',
      lessonId: 'english-p2-conversation-reading',
      status: 'PASS',
      score,
      maxScore
    }, '*');
  }

  window.location.href = NEXT_PAGE_URL;
}

window.onload = initGame;
