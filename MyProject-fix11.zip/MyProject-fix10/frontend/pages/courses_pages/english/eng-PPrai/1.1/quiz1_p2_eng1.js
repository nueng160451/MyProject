const questions = [
    {
        question: "Which word is a noun (คำนาม)?",
        options: ["Cat", "Run", "Beautiful"],
        answer: 0
    },
    {
        question: "What does 'Book' mean?",
        options: ["โรงเรียน", "หนังสือ", "แมว"],
        answer: 1
    },
    {
        question: "Which word names a place?",
        options: ["School", "Sleep", "Red"],
        answer: 0
    },
    {
        question: "A noun can name a ____.",
        options: ["person, animal, thing, or place", "color only", "an action only"],
        answer: 0
    },
    {
        question: "Which group contains only nouns?",
        options: ["Cat, Book, School", "Run, Sleep, Eat", "Big, Red, Beautiful"],
        answer: 0
    },
    {
        question: "Which word is a verb (คำกริยา)?",
        options: ["Book", "Run", "Big"],
        answer: 1
    },
    {
        question: "What does 'Sleep' mean?",
        options: ["นอนหลับ", "วิ่ง", "กิน"],
        answer: 0
    },
    {
        question: "Which word means 'กิน'?",
        options: ["School", "Eat", "Beautiful"],
        answer: 1
    },
    {
        question: "A verb usually tells us about ____.",
        options: ["an action", "a color", "a place"],
        answer: 0
    },
    {
        question: "Which group contains only verbs?",
        options: ["Cat, Book, School", "Run, Sleep, Eat", "Red, Big, Beautiful"],
        answer: 1
    },
    {
        question: "Which word is an adjective (คำคุณศัพท์)?",
        options: ["Eat", "School", "Beautiful"],
        answer: 2
    },
    {
        question: "What does 'Big' mean?",
        options: ["ใหญ่", "สวย", "สีแดง"],
        answer: 0
    },
    {
        question: "Which word describes a color?",
        options: ["Red", "Run", "Cat"],
        answer: 0
    },
    {
        question: "An adjective can describe a noun's ____.",
        options: ["action only", "quality, color, or size", "place only"],
        answer: 1
    },
    {
        question: "In 'a big cat', which word is the adjective?",
        options: ["a", "big", "cat"],
        answer: 1
    }
];

let currentQuestion = 0;
let score = 0;
let canAnswer = true;

const questionNumberEl = document.getElementById('question-number');
const scoreCountEl = document.getElementById('score-count');
const questionTextEl = document.getElementById('question-text');
const optionsContainerEl = document.getElementById('options-container');
const quizBox = document.getElementById('quiz-box');
const resultBox = document.getElementById('result-box');
const finalScoreEl = document.getElementById('final-score');

loadQuestion();

function loadQuestion() {
    canAnswer = true;
    const question = questions[currentQuestion];
    questionNumberEl.innerText = `ข้อที่ ${currentQuestion + 1} / ${questions.length}`;
    scoreCountEl.innerText = `คะแนน: ${score}`;
    questionTextEl.innerText = question.question;
    optionsContainerEl.innerHTML = '';

    question.options.forEach((option, index) => {
        const button = document.createElement('button');
        button.classList.add('option-btn');
        button.type = 'button';
        button.innerText = option;
        button.addEventListener('click', () => selectOption(index, button));
        optionsContainerEl.appendChild(button);
    });
}

function selectOption(selectedIndex, selectedButton) {
    if (!canAnswer) return;
    canAnswer = false;

    const correctIndex = questions[currentQuestion].answer;
    const optionButtons = optionsContainerEl.querySelectorAll('.option-btn');

    if (selectedIndex === correctIndex) {
        selectedButton.classList.add('correct');
        score++;
        scoreCountEl.innerText = `คะแนน: ${score}`;
    } else {
        selectedButton.classList.add('incorrect');
        optionButtons[correctIndex].classList.add('correct');
    }

    optionButtons.forEach(button => {
        button.disabled = true;
    });

    window.setTimeout(() => {
        currentQuestion++;
        if (currentQuestion < questions.length) {
            loadQuestion();
        } else {
            showResult();
        }
    }, 1000);
}

function showResult() {
    quizBox.classList.add('hidden');
    resultBox.classList.remove('hidden');
    finalScoreEl.innerText = `คุณได้คะแนน ${score} จาก ${questions.length} คะแนน`;
}

function restartQuiz() {
    currentQuestion = 0;
    score = 0;
    resultBox.classList.add('hidden');
    quizBox.classList.remove('hidden');
    loadQuestion();
}
