// =============================================================
// ⚙️ การตั้งค่า URL ลิงก์ไปหน้าถัดไปเมื่อทำครบ
// =============================================================
const NEXT_PAGE_URL = "quiz1_p2_eng1.html";

// Database of word questions and hints
const wordDataset = [
  // Nouns
  { word: "Cat", category: "Noun", hint: "💡 'Cat' (แมว) เป็นสัตว์ จัดเป็นคำนาม (Noun) ครับ!" },
  { word: "Book", category: "Noun", hint: "💡 'Book' (หนังสือ) เป็นสิ่งของ จัดเป็นคำนาม (Noun) ครับ!" },
  { word: "School", category: "Noun", hint: "💡 'School' (โรงเรียน) เป็นสถานที่ จัดเป็นคำนาม (Noun) ครับ!" },

  // Verbs
  { word: "Run", category: "Verb", hint: "💡 'Run' (วิ่ง) เป็นการกระทำ จัดเป็นคำกริยา (Verb) ครับ!" },
  { word: "Sleep", category: "Verb", hint: "💡 'Sleep' (นอนหลับ) เป็นการกระทำ จัดเป็นคำกริยา (Verb) ครับ!" },
  { word: "Eat", category: "Verb", hint: "💡 'Eat' (กิน) เป็นการกระทำ จัดเป็นคำกริยา (Verb) ครับ!" },

  // Adjectives
  { word: "Beautiful", category: "Adjective", hint: "💡 'Beautiful' (สวย) เป็นคำบอกลักษณะ จัดเป็นคำคุณศัพท์ (Adjective) ครับ!" },
  { word: "Red", category: "Adjective", hint: "💡 'Red' (สีแดง) เป็นคำบอกสี จัดเป็นคำคุณศัพท์ (Adjective) ครับ!" },
  { word: "Big", category: "Adjective", hint: "💡 'Big' (ใหญ่) เป็นคำบอกขนาด จัดเป็นคำคุณศัพท์ (Adjective) ครับ!" }
];

// Game State Variables
let remainingWords = [];
let selectedWordCard = null;
let starCount = 0;
let totalWordsCount = 0;

// Initialize Game
function initGame() {
  const wordPool = document.getElementById('wordPool');
  const hintBanner = document.getElementById('hintBanner');

  // Clear Zones
  wordPool.innerHTML = '';
  document.getElementById('zoneNoun').innerHTML = '';
  document.getElementById('zoneVerb').innerHTML = '';
  document.getElementById('zoneAdj').innerHTML = '';
  hintBanner.classList.remove('active');

  selectedWordCard = null;
  starCount = 0;

  // Shuffle dataset
  remainingWords = shuffleArray([...wordDataset]);
  totalWordsCount = remainingWords.length;
  updateStats();

  // Render Word Cards into Pool
  remainingWords.forEach(item => {
    const card = createWordCard(item);
    wordPool.appendChild(card);
  });

  // Setup Bin Drag & Drop Listeners
  setupBinsEvents();
}

// Create Word Card Element
function createWordCard(item) {
  const card = document.createElement('div');
  card.className = 'word-card';
  card.innerText = item.word;
  card.dataset.word = item.word;
  card.dataset.category = item.category;
  card.dataset.hint = item.hint;
  card.draggable = true;

  // Click Selection Logic (For mobile & touch)
  card.addEventListener('click', (e) => {
    e.stopPropagation();
    document.querySelectorAll('.word-card').forEach(c => c.classList.remove('selected'));
    
    if (selectedWordCard !== card) {
      selectedWordCard = card;
      card.classList.add('selected');
    } else {
      selectedWordCard = null;
    }
  });

  // Drag Start & End Logic
  card.addEventListener('dragstart', (e) => {
    selectedWordCard = card;
    card.classList.add('dragging');
    e.dataTransfer.setData('text/plain', item.word);
  });

  card.addEventListener('dragend', () => {
    card.classList.remove('dragging');
  });

  return card;
}

// Setup Bin Drop Events
function setupBinsEvents() {
  const bins = document.querySelectorAll('.category-bin');

  bins.forEach(bin => {
    // Click on Bin to drop selected word
    bin.addEventListener('click', () => {
      if (selectedWordCard) {
        attemptDrop(selectedWordCard, bin.dataset.category);
      }
    });

    // Drag Over
    bin.addEventListener('dragover', (e) => {
      e.preventDefault();
      bin.classList.add('drag-over');
    });

    // Drag Leave
    bin.addEventListener('dragleave', () => {
      bin.classList.remove('drag-over');
    });

    // Drop
    bin.addEventListener('drop', (e) => {
      e.preventDefault();
      bin.classList.remove('drag-over');
      if (selectedWordCard) {
        attemptDrop(selectedWordCard, bin.dataset.category);
      }
    });
  });
}

// Attempt to Drop Word into Category Bin
function attemptDrop(cardEl, targetCategory) {
  const correctCategory = cardEl.dataset.category;
  const hintText = cardEl.dataset.hint;
  const hintBanner = document.getElementById('hintBanner');

  if (correctCategory === targetCategory) {
    // Correct sort
    starCount++;
    hintBanner.classList.remove('active');

    // Move Card to corresponding zone
    const targetZone = document.getElementById(`zone${targetCategory === 'Adjective' ? 'Adj' : targetCategory}`);
    cardEl.draggable = false;
    cardEl.classList.remove('selected', 'dragging');
    targetZone.appendChild(cardEl);

    // Remove from remaining pool list
    remainingWords = remainingWords.filter(w => w.word !== cardEl.dataset.word);
    selectedWordCard = null;

    updateStats();

    // Check Win Condition
    if (remainingWords.length === 0) {
      setTimeout(showCompletionModal, 500);
    }
  } else {
    // Incorrect sort: show a hint
    hintBanner.innerText = hintText;
    hintBanner.classList.add('active');

    // Visual Shake Effect
    cardEl.style.transform = 'shake 0.3s';
    setTimeout(() => { cardEl.style.transform = ''; }, 300);
  }
}

// Update Stats Counter
function updateStats() {
  document.getElementById('remainingCount').innerText = `${remainingWords.length} / ${totalWordsCount}`;
  document.getElementById('starCount').innerText = starCount;
}

// Shuffle Utility
function shuffleArray(arr) {
  const array = [...arr];
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

// Reset Game
function resetGame() {
  document.getElementById('resultModal').classList.remove('active');
  initGame();
}

// Show End Game Modal
function showCompletionModal() {
  document.getElementById('modalScoreText').innerText = `ดาวสะสมที่ได้: ${starCount} / ${totalWordsCount} ดวง`;
  document.getElementById('resultModal').classList.add('active');
}

// =============================================================
// 🚀 ระบบลิงก์ไปยังหน้าถัดไปเมื่อทำครบ
// =============================================================
function goToNextPage() {
  // 1. ส่งสัญญาณ postMessage ไปยังเว็บแม่ (กรณีนำไปฝังใน iframe/LMS)
  if (window.parent && window.parent !== window) {
    window.parent.postMessage({
      type: 'LESSON_COMPLETE',
      action: 'NEXT_LESSON',
      lessonId: 'word-sorting-parts-of-speech',
      status: 'PASS',
      score: starCount
    }, '*');
  }

  // 2. สั่งเปลี่ยนหน้าไปยัง URL หน้าถัดไป
  if (NEXT_PAGE_URL && NEXT_PAGE_URL.trim() !== "") {
    window.location.href = NEXT_PAGE_URL;
  } else {
    alert('🎉 ยินดีด้วย! คุณแยกประเภทคำศัพท์ครบเรียบร้อยแล้ว');
  }
}

// Start Game on Page Load
window.onload = initGame;