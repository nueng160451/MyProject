const NEXT_PAGE_URL = "quiz1_p2_eng2.html";

const questions = [
  { sentence: "I play football every Saturday.", tense: "Present" },
  { sentence: "She visited her grandmother yesterday.", tense: "Past" },
  { sentence: "We will go to school tomorrow.", tense: "Future" },
  { sentence: "He eats breakfast every morning.", tense: "Present" },
  { sentence: "They watched a movie last night.", tense: "Past" },
  { sentence: "I will help my friend next week.", tense: "Future" }
];

let currentQuestion = 0;
let score = 0;
let canChooseDoor = true;
let nextQuestionTimeout = null;

const sentenceDisplay = document.getElementById('sentenceDisplay');
const questionProgress = document.getElementById('questionProgress');
const scoreText = document.getElementById('scoreText');
const feedbackBanner = document.getElementById('feedbackBanner');
const resultModal = document.getElementById('resultModal');
const doorCards = {
  Present: document.getElementById('doorPresent'),
  Past: document.getElementById('doorPast'),
  Future: document.getElementById('doorFuture')
};

function loadQuestion() {
  const question = questions[currentQuestion];
  canChooseDoor = true;
  sentenceDisplay.innerText = question.sentence;
  questionProgress.innerText = `${currentQuestion + 1} / ${questions.length}`;
  scoreText.innerText = `${score} คะแนน`;
  feedbackBanner.innerText = '';
  feedbackBanner.className = 'feedback-banner';

  Object.values(doorCards).forEach(door => {
    door.classList.remove('open');
    door.removeAttribute('aria-disabled');
    door.tabIndex = 0;
  });
}

function chooseDoor(selectedTense) {
  if (!canChooseDoor) return;
  canChooseDoor = false;

  const isCorrect = selectedTense === questions[currentQuestion].tense;
  const chosenDoor = doorCards[selectedTense];
  chosenDoor.classList.add('open');

  if (isCorrect) {
    score += 10;
    scoreText.innerText = `${score} คะแนน`;
    feedbackBanner.innerText = '✅ ถูกต้อง! เลือก Tense ได้ตรงกับประโยค';
    feedbackBanner.className = 'feedback-banner correct';
  } else {
    feedbackBanner.innerText = `❌ ยังไม่ถูกต้อง ประโยคนี้เป็น ${questions[currentQuestion].tense} Tense`;
    feedbackBanner.className = 'feedback-banner wrong';
  }

  Object.values(doorCards).forEach(door => {
    door.setAttribute('aria-disabled', 'true');
    door.tabIndex = -1;
  });

  nextQuestionTimeout = window.setTimeout(() => {
    nextQuestionTimeout = null;
    currentQuestion++;
    if (currentQuestion < questions.length) {
      loadQuestion();
    } else {
      showCompletionModal();
    }
  }, 900);
}

function showCompletionModal() {
  document.getElementById('modalScoreText').innerText =
    `คะแนนทั้งหมด: ${score} / ${questions.length * 10} คะแนน`;
  document.getElementById('modalStars').innerText =
    score === questions.length * 10 ? '⭐⭐⭐' : score >= 40 ? '⭐⭐' : '⭐';
  document.getElementById('modalDesc').innerText =
    `ตอบถูก ${score / 10} จาก ${questions.length} ข้อ`;
  resultModal.classList.add('active');
}

function resetGame() {
  if (nextQuestionTimeout !== null) {
    window.clearTimeout(nextQuestionTimeout);
    nextQuestionTimeout = null;
  }
  currentQuestion = 0;
  score = 0;
  resultModal.classList.remove('active');
  loadQuestion();
}

function goToNextPage() {
  if (window.parent && window.parent !== window) {
    window.parent.postMessage({
      type: 'LESSON_COMPLETE',
      action: 'NEXT_LESSON',
      lessonId: 'english-p2-tenses',
      status: 'PASS',
      score,
      maxScore: questions.length * 10
    }, '*');
  }

  window.location.href = NEXT_PAGE_URL;
}

loadQuestion();
