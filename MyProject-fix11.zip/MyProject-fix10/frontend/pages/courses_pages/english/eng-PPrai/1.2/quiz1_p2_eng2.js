const questions = [
    {
        question: "Which tense describes routines or things that happen regularly?",
        options: ["Present Tense", "Past Tense", "Future Tense"],
        answer: 0
    },
    {
        question: "Which time phrase often signals the Present Tense?",
        options: ["yesterday", "every morning", "next week"],
        answer: 1
    },
    {
        question: "Choose the correct sentence.",
        options: [
            "He eat breakfast every morning.",
            "He eats breakfast every morning.",
            "He will eats breakfast every morning."
        ],
        answer: 1
    },
    {
        question: "Which tense describes a completed event in the past?",
        options: ["Present Tense", "Past Tense", "Future Tense"],
        answer: 1
    },
    {
        question: "The word 'yesterday' usually points to which tense?",
        options: ["Present", "Past", "Future"],
        answer: 1
    },
    {
        question: "Complete: She ___ her grandmother yesterday.",
        options: ["visit", "visits", "visited"],
        answer: 2
    },
    {
        question: "What is the past form of 'watch'?",
        options: ["watching", "watched", "watches"],
        answer: 1
    },
    {
        question: "Which tense talks about something that will happen later?",
        options: ["Present Tense", "Past Tense", "Future Tense"],
        answer: 2
    },
    {
        question: "Which time phrase often signals the Future Tense?",
        options: ["last night", "every Saturday", "tomorrow"],
        answer: 2
    },
    {
        question: "Complete: We ___ go to school tomorrow.",
        options: ["will", "did", "are"],
        answer: 0
    },
    {
        question: "Choose the correct form after 'will'.",
        options: ["will went", "will goes", "will go"],
        answer: 2
    },
    {
        question: "What does 'next week' mean?",
        options: ["สัปดาห์ที่แล้ว", "สัปดาห์หน้า", "ทุกสัปดาห์"],
        answer: 1
    },
    {
        question: "Which sentence is in the Past Tense?",
        options: [
            "I play football every Saturday.",
            "They watched a movie last night.",
            "I will help my friend next week."
        ],
        answer: 1
    },
    {
        question: "Which sentence is in the Future Tense?",
        options: [
            "She visited her grandmother yesterday.",
            "He eats breakfast every morning.",
            "I will help my friend next week."
        ],
        answer: 2
    },
    {
        question: "Which sentence is in the Present Tense?",
        options: [
            "I play football every Saturday.",
            "We will go to school tomorrow.",
            "They watched a movie last night."
        ],
        answer: 0
    }
];

let currentQuestion = 0;
let score = 0;
let canAnswer = true;

const questionNumberEl = document.getElementById('question-number');
const scoreCountEl = document.getElementById('score-count');
const questionTextEl = document.getElementById('question-text');
const optionsContainerEl = document.getElementById('options-container');
const quizBox = document.getElementById('quiz-box');
const resultBox = document.getElementById('result-box');
const finalScoreEl = document.getElementById('final-score');

loadQuestion();

function loadQuestion() {
    canAnswer = true;
    const question = questions[currentQuestion];
    questionNumberEl.innerText = `ข้อที่ ${currentQuestion + 1} / ${questions.length}`;
    scoreCountEl.innerText = `คะแนน: ${score}`;
    questionTextEl.innerText = question.question;
    optionsContainerEl.innerHTML = '';

    question.options.forEach((option, index) => {
        const button = document.createElement('button');
        button.classList.add('option-btn');
        button.type = 'button';
        button.innerText = option;
        button.addEventListener('click', () => selectOption(index, button));
        optionsContainerEl.appendChild(button);
    });
}

function selectOption(selectedIndex, selectedButton) {
    if (!canAnswer) return;
    canAnswer = false;

    const correctIndex = questions[currentQuestion].answer;
    const optionButtons = optionsContainerEl.querySelectorAll('.option-btn');

    if (selectedIndex === correctIndex) {
        selectedButton.classList.add('correct');
        score++;
        scoreCountEl.innerText = `คะแนน: ${score}`;
    } else {
        selectedButton.classList.add('incorrect');
        optionButtons[correctIndex].classList.add('correct');
    }

    optionButtons.forEach(button => {
        button.disabled = true;
    });

    window.setTimeout(() => {
        currentQuestion++;
        if (currentQuestion < questions.length) {
            loadQuestion();
        } else {
            showResult();
        }
    }, 1000);
}

function showResult() {
    quizBox.classList.add('hidden');
    resultBox.classList.remove('hidden');
    finalScoreEl.innerText = `คุณได้คะแนน ${score} จาก ${questions.length} คะแนน`;
}

function restartQuiz() {
    currentQuestion = 0;
    score = 0;
    resultBox.classList.add('hidden');
    quizBox.classList.remove('hidden');
    loadQuestion();
}
