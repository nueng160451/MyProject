const NEXT_PAGE_URL = "quiz1_p2_eng3.html";

const questionsData = [
  {
    levelText: "ระดับ 1: เปรียบเทียบสัตว์ 2 ตัว",
    question: 'Complete the sentence: "A ___ is taller than a cat."',
    animals: [
      { id: "giraffe", name: "Giraffe", icon: "🦒", scale: "large", isCorrect: true },
      { id: "cat", name: "Cat", icon: "🐱", scale: "small", isCorrect: false }
    ],
    explanation: "A giraffe is taller than a cat. (ยีราฟสูงกว่าแมว)"
  },
  {
    levelText: "ระดับ 1: เปรียบเทียบสัตว์ 2 ตัว",
    question: 'Complete the sentence: "An ___ is bigger than a mouse."',
    animals: [
      { id: "mouse", name: "Mouse", icon: "🐭", scale: "small", isCorrect: false },
      { id: "elephant", name: "Elephant", icon: "🐘", scale: "large", isCorrect: true }
    ],
    explanation: "An elephant is bigger than a mouse. (ช้างตัวใหญ่กว่าหนู)"
  },
  {
    levelText: "ระดับ 1: เปรียบเทียบสัตว์ 2 ตัว",
    question: 'Complete the sentence: "A cheetah is faster than a ___."',
    animals: [
      { id: "cheetah", name: "Cheetah", icon: "🐆", scale: "medium", isCorrect: false },
      { id: "turtle", name: "Turtle", icon: "🐢", scale: "small", isCorrect: true }
    ],
    explanation: "A cheetah is faster than a turtle. (เสือชีตาห์วิ่งเร็วกว่าเต่า)"
  },
  {
    levelText: "ระดับ 2: เปรียบเทียบสัตว์ 3 ตัว",
    question: 'Complete the sentence: "The ___ is the smallest of the three."',
    animals: [
      { id: "dog", name: "Dog", icon: "🐶", scale: "medium", isCorrect: false },
      { id: "rabbit", name: "Rabbit", icon: "🐰", scale: "small", isCorrect: true },
      { id: "hippo", name: "Hippo", icon: "🦛", scale: "large", isCorrect: false }
    ],
    explanation: "The rabbit is the smallest of the three animals. (กระต่ายตัวเล็กที่สุดในสัตว์สามตัว)"
  },
  {
    levelText: "ระดับ 2: เปรียบเทียบสัตว์ 3 ตัว",
    question: 'Complete the sentence: "The ___ is the biggest animal in this group."',
    animals: [
      { id: "fish", name: "Fish", icon: "🐟", scale: "small", isCorrect: false },
      { id: "whale", name: "Blue Whale", icon: "🐋", scale: "large", isCorrect: true },
      { id: "crab", name: "Crab", icon: "🦀", scale: "small", isCorrect: false }
    ],
    explanation: "The blue whale is the biggest animal in this group. (วาฬสีน้ำเงินตัวใหญ่ที่สุดในกลุ่มนี้)"
  },
  {
    levelText: "ระดับ 2: เปรียบเทียบสัตว์ 3 ตัว",
    question: 'Complete the sentence: "The ___ is the fastest animal in this group."',
    animals: [
      { id: "snail", name: "Snail", icon: "🐌", scale: "small", isCorrect: false },
      { id: "horse", name: "Horse", icon: "🐎", scale: "medium", isCorrect: false },
      { id: "cheetah", name: "Cheetah", icon: "🐆", scale: "large", isCorrect: true }
    ],
    explanation: "The cheetah is the fastest animal in this group. (เสือชีตาห์เร็วที่สุดในกลุ่มนี้)"
  }
];

let currentIdx = 0;
let score = 0;
let isAnswerLocked = false;
let nextQuestionTimeout = null;

function initGame() {
  if (nextQuestionTimeout !== null) {
    window.clearTimeout(nextQuestionTimeout);
    nextQuestionTimeout = null;
  }

  currentIdx = 0;
  score = 0;
  isAnswerLocked = false;
  document.getElementById('resultModal').classList.remove('active');
  loadQuestion();
}

function loadQuestion() {
  const question = questionsData[currentIdx];
  const grid = document.getElementById('animalsGrid');
  const feedback = document.getElementById('feedbackBanner');

  document.getElementById('questionProgress').innerText =
    `${currentIdx + 1} / ${questionsData.length}`;
  document.getElementById('scoreText').innerText = `${score} คะแนน`;
  document.getElementById('levelTag').innerText = question.levelText;
  document.getElementById('questionText').innerText = question.question;
  grid.innerHTML = '';
  feedback.innerText = '';
  feedback.className = 'feedback-banner';
  isAnswerLocked = false;

  question.animals.forEach(animal => {
    const card = document.createElement('button');
    card.type = 'button';
    card.className = 'animal-card';
    card.dataset.scale = animal.scale;
    card.dataset.id = animal.id;
    card.setAttribute('aria-label', animal.name);
    card.innerHTML = `
      <div class="animal-avatar">${animal.icon}</div>
      <div class="animal-name">${animal.name}</div>
    `;
    card.addEventListener('click', () => handleSelectAnimal(card, animal, question));
    grid.appendChild(card);
  });
}

function handleSelectAnimal(card, animal, question) {
  if (isAnswerLocked) return;
  isAnswerLocked = true;

  const feedback = document.getElementById('feedbackBanner');
  if (animal.isCorrect) {
    card.classList.add('correct');
    score += 10;
    document.getElementById('scoreText').innerText = `${score} คะแนน`;
    feedback.innerText = `✨ ถูกต้อง! ${question.explanation}`;
    feedback.className = 'feedback-banner correct';
  } else {
    card.classList.add('wrong');
    feedback.innerText = `❌ ยังไม่ถูกต้อง! ${question.explanation}`;
    feedback.className = 'feedback-banner wrong';

    const correctAnimal = question.animals.find(item => item.isCorrect);
    const correctCard = document.querySelector(
      `.animal-card[data-id="${correctAnimal.id}"]`
    );
    if (correctCard) correctCard.classList.add('correct');
  }

  document.querySelectorAll('.animal-card').forEach(item => {
    item.disabled = true;
  });

  nextQuestionTimeout = window.setTimeout(() => {
    nextQuestionTimeout = null;
    currentIdx++;
    if (currentIdx < questionsData.length) {
      loadQuestion();
    } else {
      showCompletionModal();
    }
  }, 1600);
}

function resetGame() {
  initGame();
}

function showCompletionModal() {
  document.getElementById('modalScoreText').innerText =
    `คะแนนทั้งหมด: ${score} / ${questionsData.length * 10} คะแนน`;
  document.getElementById('modalStars').innerText =
    score === questionsData.length * 10 ? '⭐⭐⭐' : score >= 40 ? '⭐⭐' : '⭐';
  document.getElementById('modalDesc').innerText =
    `ตอบถูก ${score / 10} จาก ${questionsData.length} ข้อ`;
  document.getElementById('resultModal').classList.add('active');
}

function goToNextPage() {
  if (window.parent && window.parent !== window) {
    window.parent.postMessage({
      type: 'LESSON_COMPLETE',
      action: 'NEXT_LESSON',
      lessonId: 'english-p2-comparison-adjectives',
      status: 'PASS',
      score,
      maxScore: questionsData.length * 10
    }, '*');
  }

  window.location.href = NEXT_PAGE_URL;
}

window.onload = initGame;
