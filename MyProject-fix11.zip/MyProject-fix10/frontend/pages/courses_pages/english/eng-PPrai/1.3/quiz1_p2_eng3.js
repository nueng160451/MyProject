const questions = [
    {
        question: "Comparative adjectives are used to compare how many things?",
        options: ["Two", "Three or more", "Only one"],
        answer: 0
    },
    {
        question: "Which word completes the phrase: taller ___ a cat?",
        options: ["then", "than", "that"],
        answer: 1
    },
    {
        question: "Choose the correct comparative form of 'big'.",
        options: ["biger", "bigger", "the biggest"],
        answer: 1
    },
    {
        question: "Which animal is taller?",
        options: ["Cat", "Giraffe", "Mouse"],
        answer: 1
    },
    {
        question: "Complete: An elephant is ___ than a mouse.",
        options: ["big", "bigger", "the biggest"],
        answer: 1
    },
    {
        question: "Complete: A cheetah is ___ than a turtle.",
        options: ["fast", "faster", "the fastest"],
        answer: 1
    },
    {
        question: "Which form is used to compare three or more things?",
        options: ["Comparative", "Superlative", "Present tense"],
        answer: 1
    },
    {
        question: "Which word usually comes before a superlative adjective?",
        options: ["a", "the", "than"],
        answer: 1
    },
    {
        question: "Choose the superlative form of 'small'.",
        options: ["smaller", "the smallest", "smallest than"],
        answer: 1
    },
    {
        question: "Which animal is smaller than the dog and the hippo?",
        options: ["Rabbit", "Hippo", "Dog"],
        answer: 0
    },
    {
        question: "Complete: The blue whale is ___ animal.",
        options: ["the biggest", "bigger", "big"],
        answer: 0
    },
    {
        question: "Choose the superlative form of 'fast'.",
        options: ["faster", "the fastest", "fastest than"],
        answer: 1
    },
    {
        question: "Which animal is the fastest in the Animal Battle game?",
        options: ["Snail", "Horse", "Cheetah"],
        answer: 2
    },
    {
        question: "Choose the correct sentence comparing a giraffe and a cat.",
        options: [
            "A giraffe is taller than a cat.",
            "A giraffe is the tallest than a cat.",
            "A giraffe is tall than a cat."
        ],
        answer: 0
    },
    {
        question: "Choose the correct sentence about the blue whale.",
        options: [
            "The blue whale is the biggest animal.",
            "The blue whale is bigger animal.",
            "The blue whale is the bigger than animal."
        ],
        answer: 0
    }
];

let currentQuestion = 0;
let score = 0;
let canAnswer = true;

const questionNumberEl = document.getElementById('question-number');
const scoreCountEl = document.getElementById('score-count');
const questionTextEl = document.getElementById('question-text');
const optionsContainerEl = document.getElementById('options-container');
const quizBox = document.getElementById('quiz-box');
const resultBox = document.getElementById('result-box');
const finalScoreEl = document.getElementById('final-score');

loadQuestion();

function loadQuestion() {
    canAnswer = true;
    const question = questions[currentQuestion];
    questionNumberEl.innerText = `ข้อที่ ${currentQuestion + 1} / ${questions.length}`;
    scoreCountEl.innerText = `คะแนน: ${score}`;
    questionTextEl.innerText = question.question;
    optionsContainerEl.innerHTML = '';

    question.options.forEach((option, index) => {
        const button = document.createElement('button');
        button.classList.add('option-btn');
        button.type = 'button';
        button.innerText = option;
        button.addEventListener('click', () => selectOption(index, button));
        optionsContainerEl.appendChild(button);
    });
}

function selectOption(selectedIndex, selectedButton) {
    if (!canAnswer) return;
    canAnswer = false;

    const correctIndex = questions[currentQuestion].answer;
    const optionButtons = optionsContainerEl.querySelectorAll('.option-btn');

    if (selectedIndex === correctIndex) {
        selectedButton.classList.add('correct');
        score++;
        scoreCountEl.innerText = `คะแนน: ${score}`;
    } else {
        selectedButton.classList.add('incorrect');
        optionButtons[correctIndex].classList.add('correct');
    }

    optionButtons.forEach(button => {
        button.disabled = true;
    });

    window.setTimeout(() => {
        currentQuestion++;
        if (currentQuestion < questions.length) {
            loadQuestion();
        } else {
            showResult();
        }
    }, 1000);
}

function showResult() {
    quizBox.classList.add('hidden');
    resultBox.classList.remove('hidden');
    finalScoreEl.innerText = `คุณได้คะแนน ${score} จาก ${questions.length} คะแนน`;
}

function restartQuiz() {
    currentQuestion = 0;
    score = 0;
    resultBox.classList.add('hidden');
    quizBox.classList.remove('hidden');
    loadQuestion();
}
