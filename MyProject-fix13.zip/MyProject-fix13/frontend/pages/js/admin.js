document.getElementById("loginBtn").addEventListener("click", () => {
      location.href = "login.html";
    });
    // (ปุ่ม startBtn ไม่มีอยู่ในหน้านี้ จึงเช็กก่อนเพื่อไม่ให้เกิด error)
    const startBtn = document.getElementById("startBtn");
    if (startBtn) startBtn.addEventListener("click", () => {
      location.href = (window.Auth && Auth.getToken()) ? "course-select.html" : "login.html";
    });

    /* ============ User Storage (localStorage) ============ */
    const USERS_KEY = "htl_users";
    const SEED_USERS = [
      { id: "USR-1001", name: "กิตติพงษ์ สุขเจริญ", email: "kittipong.s@example.com", password: "Kitti#2026pw", courses: 3, status: "Active" },
      { id: "USR-1002", name: "ณิชารีย์ วงศ์อนันต์", email: "nicharee.dev@gmail.com", password: "Nicha!dev88", courses: 2, status: "Active" },
      { id: "USR-1003", name: "พงศกร พัฒนกุล", email: "pongsakorn.p@tech.co.th", password: "Pong@tech55", courses: 1, status: "Suspended" },
      { id: "USR-1004", name: "ธนกฤต วิริยะภาพ", email: "thanakrit.v@hotmail.com", password: "Thana_9981x", courses: 0, status: "Active" },
      { id: "USR-1005", name: "มณีรัตน์ ศรีสวัสดิ์", email: "maneerat.sri@outlook.com", password: "Manee$Sri77", courses: 4, status: "Active" }
    ];
    const COLORS = ["#3b82f6", "#a21caf", "#10b981", "#f59e0b", "#ef4444", "#6366f1", "#0ea5e9"];

    const Store = {
      load() {
        try {
          const raw = localStorage.getItem(USERS_KEY);
          if (raw === null) { this.save(SEED_USERS); return SEED_USERS.slice(); }
          const arr = JSON.parse(raw);
          return Array.isArray(arr) ? arr : [];
        } catch (e) { return []; }
      },
      save(list) {
        try { localStorage.setItem(USERS_KEY, JSON.stringify(list)); }
        catch (e) { alert("บันทึกลง localStorage ไม่ได้: " + e.message); }
      },
      size() {
        try { return ((localStorage.getItem(USERS_KEY) || "").length * 2 / 1024).toFixed(1); }
        catch (e) { return "0"; }
      }
    };

    let users = Store.load();
    let revealed = new Set();   // id ที่กดดูรหัสผ่านแล้ว
    let revealAll = false;

    const $ = (id) => document.getElementById(id);
    const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

    function nextId() {
      const max = users.reduce((m, u) => Math.max(m, parseInt(String(u.id).replace(/\D/g, ""), 10) || 1000), 1000);
      return "USR-" + (max + 1);
    }

    function filtered() {
      const q = $("searchInput").value.trim().toLowerCase();
      const st = $("statusFilter").value;
      const cf = $("courseFilter").value;
      return users.filter((u) => {
        if (q && !(u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q))) return false;
        if (st !== "all" && u.status !== st) return false;
        if (cf === "3+" && u.courses < 3) return false;
        if (cf !== "all" && cf !== "3+" && u.courses !== Number(cf)) return false;
        return true;
      });
    }

    function renderStats() {
      const total = users.length;
      const active = users.filter((u) => u.status === "Active").length;
      const courses = users.reduce((s, u) => s + (Number(u.courses) || 0), 0);
      $("statTotal").textContent = total;
      $("statActive").textContent = active;
      $("statCourses").textContent = courses;
      $("statAvg").textContent = "เฉลี่ย " + (total ? (courses / total).toFixed(1) : "0.0") + " คอร์ส/คน";
      $("statSize").textContent = "ใช้พื้นที่ " + Store.size() + " KB";
      // การ์ดภาพรวมด้านบน
      if ($("courseCount")) $("courseCount").textContent = courses;
      if ($("studentCount")) $("studentCount").textContent = total;
    }

    function renderTable() {
      const list = filtered();
      const tb = $("userTbody");
      if (!list.length) {
        tb.innerHTML = '<tr class="empty-row"><td colspan="6">ไม่พบข้อมูลผู้ใช้</td></tr>';
        return;
      }
      tb.innerHTML = list.map((u, i) => {
        const show = revealAll || revealed.has(u.id);
        const initial = esc((u.name || "?").trim().charAt(0));
        return `<tr>
          <td><div class="user-cell">
            <div class="avatar" style="background:${COLORS[i % COLORS.length]}">${initial}</div>
            <div><div class="user-name">${esc(u.name)}</div><div class="user-id">${esc(u.id)}</div></div>
          </div></td>
          <td class="mono">${esc(u.email)}</td>
          <td><div class="pw-cell"><span class="mono">${show ? esc(u.password) : "••••••••••••"}</span>
            <button class="pw-toggle" data-act="pw" data-id="${esc(u.id)}">${show ? "ซ่อน" : "ดู"}</button></div></td>
          <td><span class="badge badge-course">${Number(u.courses) || 0} คอร์ส</span></td>
          <td><span class="badge ${u.status === "Active" ? "badge-active" : "badge-suspended"}">${esc(u.status)}</span></td>
          <td><div class="actions">
            <button class="btn-small" data-act="view" data-id="${esc(u.id)}">ดูรายละเอียด</button>
            <button class="btn-danger" data-act="del" data-id="${esc(u.id)}" title="ลบ">ลบ</button>
          </div></td>
        </tr>`;
      }).join("");
    }

    function render() { renderStats(); renderTable(); }

    // ---- เหตุการณ์ในตาราง ----
    $("userTbody").addEventListener("click", (e) => {
      const btn = e.target.closest("button[data-act]");
      if (!btn) return;
      const id = btn.dataset.id;
      const u = users.find((x) => x.id === id);
      if (!u) return;
      if (btn.dataset.act === "pw") {
        revealed.has(id) ? revealed.delete(id) : revealed.add(id);
        renderTable();
      } else if (btn.dataset.act === "view") {
        $("detailList").innerHTML = [
          ["รหัสผู้ใช้", u.id], ["ชื่อ", u.name], ["อีเมล", u.email],
          ["รหัสผ่าน", u.password], ["จำนวนคอร์ส", u.courses + " คอร์ส"], ["สถานะ", u.status]
        ].map((r) => `<li><span>${r[0]}</span><span class="mono">${esc(r[1])}</span></li>`).join("");
        $("detailModal").classList.add("open");
      } else if (btn.dataset.act === "del") {
        if (confirm("ต้องการลบผู้ใช้ \"" + u.name + "\" ใช่หรือไม่?")) {
          users = users.filter((x) => x.id !== id);
          Store.save(users);
          render();
        }
      }
    });

    // ---- ตัวกรอง / ค้นหา ----
    ["searchInput", "statusFilter", "courseFilter"].forEach((id) => {
      $(id).addEventListener(id === "searchInput" ? "input" : "change", renderTable);
    });

    $("toggleAllPw").addEventListener("click", () => {
      revealAll = !revealAll;
      $("toggleAllPw").textContent = revealAll ? "ซ่อนรหัสผ่านทั้งหมด" : "แสดงรหัสผ่านทั้งหมด";
      renderTable();
    });

    // ---- ส่งออก JSON ----
    $("exportBtn").addEventListener("click", () => {
      const blob = new Blob([JSON.stringify(users, null, 2)], { type: "application/json" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "users.json";
      a.click();
      URL.revokeObjectURL(a.href);
    });

    // ---- รีเซ็ตข้อมูลกลับเป็นค่าตัวอย่าง ----
    $("resetBtn").addEventListener("click", () => {
      if (confirm("รีเซ็ตข้อมูลผู้ใช้กลับเป็นค่าตัวอย่างเริ่มต้น?")) {
        users = SEED_USERS.slice();
        Store.save(users);
        revealed.clear();
        render();
      }
    });

    // ---- เพิ่มผู้ใช้ ----
    $("addUserBtn").addEventListener("click", () => {
      ["fName", "fEmail", "fPass"].forEach((id) => ($(id).value = ""));
      $("fCourses").value = 0;
      $("fStatus").value = "Active";
      $("addModal").classList.add("open");
    });
    $("addCancel").addEventListener("click", () => $("addModal").classList.remove("open"));
    $("detailClose").addEventListener("click", () => $("detailModal").classList.remove("open"));
    [$("addModal"), $("detailModal")].forEach((m) =>
      m.addEventListener("click", (e) => { if (e.target === m) m.classList.remove("open"); }));

    $("addSave").addEventListener("click", () => {
      const name = $("fName").value.trim();
      const email = $("fEmail").value.trim();
      const password = $("fPass").value;
      const courses = Math.max(0, parseInt($("fCourses").value, 10) || 0);
      if (!name || !email || !password) return alert("กรุณากรอกชื่อ อีเมล และรหัสผ่านให้ครบ");
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return alert("รูปแบบอีเมลไม่ถูกต้อง");
      if (password.length < 8) return alert("รหัสผ่านต้องมีอย่างน้อย 8 ตัวอักษร");
      if (users.some((u) => u.email.toLowerCase() === email.toLowerCase())) return alert("อีเมลนี้มีอยู่ในระบบแล้ว");
      users.push({ id: nextId(), name, email, password, courses, status: $("fStatus").value });
      Store.save(users);
      $("addModal").classList.remove("open");
      render();
    });

    render();